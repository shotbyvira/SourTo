import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, Send, Users, BarChart, CheckCircle, Shield } from 'lucide-react';

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="flex flex-col items-center text-center py-12 md:py-20">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-slate-900 mb-6">
          Smart Outreach Automation
        </h1>
        <p className="text-xl text-slate-600 max-w-3xl mb-8">
          Personalize and automate your outreach campaigns with intelligent name parsing
          and seamless Google Sheets integration.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link href="/dashboard">
            <span className="inline-block cursor-pointer">
              <Button size="lg" className="px-8">
                <Send className="mr-2 h-5 w-5" />
                Get Started
              </Button>
            </span>
          </Link>
          <Link href="#features">
            <span className="inline-block cursor-pointer">
              <Button variant="outline" size="lg" className="px-8">
                Learn More
              </Button>
            </span>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-12">
        <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">
          Powerful Features
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <Mail className="h-8 w-8 text-primary-600 mr-3" />
                <h3 className="text-xl font-semibold">Email Automation</h3>
              </div>
              <p className="text-slate-600">
                Create personalized email templates with custom tags and automate sending with
                configurable delays to prevent triggering spam filters.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <Users className="h-8 w-8 text-primary-600 mr-3" />
                <h3 className="text-xl font-semibold">Name Parsing</h3>
              </div>
              <p className="text-slate-600">
                Intelligently parse full names into honorific, first, middle, and last names
                for truly personalized communication.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <BarChart className="h-8 w-8 text-primary-600 mr-3" />
                <h3 className="text-xl font-semibold">Detailed Analytics</h3>
              </div>
              <p className="text-slate-600">
                Track email delivery status, monitor reply rates, and gain insights 
                into your outreach campaign performance.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <Shield className="h-8 w-8 text-primary-600 mr-3" />
                <h3 className="text-xl font-semibold">Duplicate Prevention</h3>
              </div>
              <p className="text-slate-600">
                Automatically detect and skip duplicate contacts to prevent sending 
                multiple messages to the same recipient.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <CheckCircle className="h-8 w-8 text-primary-600 mr-3" />
                <h3 className="text-xl font-semibold">Google Sheets Integration</h3>
              </div>
              <p className="text-slate-600">
                Connect directly to your Google Sheets data or upload CSV files 
                for seamless contact management and status tracking.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <Send className="h-8 w-8 text-primary-600 mr-3" />
                <h3 className="text-xl font-semibold">WhatsApp Messaging</h3>
              </div>
              <p className="text-slate-600">
                Create WhatsApp message templates with personalization tags for 
                multi-channel outreach campaigns.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-12">
        <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">
          How It Works
        </h2>
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="p-8">
              <ol className="relative border-l border-slate-200">
                <li className="mb-10 ml-6">
                  <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-100 rounded-full -left-4 ring-4 ring-white">
                    <span className="font-semibold text-primary-800">1</span>
                  </span>
                  <h3 className="flex items-center mb-1 text-lg font-semibold text-slate-900">
                    Connect Your Data Source
                  </h3>
                  <p className="mb-4 text-slate-600">
                    Link your Google Sheet or upload a CSV file with your contacts' information.
                  </p>
                </li>
                <li className="mb-10 ml-6">
                  <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-100 rounded-full -left-4 ring-4 ring-white">
                    <span className="font-semibold text-primary-800">2</span>
                  </span>
                  <h3 className="flex items-center mb-1 text-lg font-semibold text-slate-900">
                    Create Personalized Templates
                  </h3>
                  <p className="mb-4 text-slate-600">
                    Design email or WhatsApp message templates with personalization tags.
                  </p>
                </li>
                <li className="mb-10 ml-6">
                  <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-100 rounded-full -left-4 ring-4 ring-white">
                    <span className="font-semibold text-primary-800">3</span>
                  </span>
                  <h3 className="flex items-center mb-1 text-lg font-semibold text-slate-900">
                    Configure Automation Settings
                  </h3>
                  <p className="mb-4 text-slate-600">
                    Set sending delays, batch sizes, and other parameters for your campaign.
                  </p>
                </li>
                <li className="ml-6">
                  <span className="absolute flex items-center justify-center w-8 h-8 bg-primary-100 rounded-full -left-4 ring-4 ring-white">
                    <span className="font-semibold text-primary-800">4</span>
                  </span>
                  <h3 className="flex items-center mb-1 text-lg font-semibold text-slate-900">
                    Run Your Campaign & Track Results
                  </h3>
                  <p className="text-slate-600">
                    Start the automation process and monitor delivery status, replies, and campaign metrics.
                  </p>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-gradient-to-r from-primary-500/10 to-accent-500/10 rounded-lg px-8 mt-12">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">
            Ready to Streamline Your Outreach?
          </h2>
          <p className="text-xl text-slate-700 mb-8 max-w-2xl mx-auto">
            Start personalizing your email campaigns and save hours of manual work.
          </p>
          <Link href="/dashboard">
            <span className="inline-block cursor-pointer">
              <Button size="lg" className="px-8">
                Get Started Now
              </Button>
            </span>
          </Link>
        </div>
      </section>
    </div>
  );
}
