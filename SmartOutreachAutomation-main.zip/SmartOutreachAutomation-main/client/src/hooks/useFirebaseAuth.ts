import { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { 
  signInWithGoogle, 
  signOut, 
  onAuthStateChange, 
  getUserProfile,
  FirebaseUser,
  UserTier 
} from '@/lib/firebase';

interface AuthState {
  user: User | null;
  userProfile: FirebaseUser | null;
  loading: boolean;
  error: string | null;
}

export function useFirebaseAuth() {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    userProfile: null,
    loading: true,
    error: null
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChange(async (user) => {
      setAuthState(prev => ({ ...prev, loading: true, error: null }));
      
      if (user) {
        try {
          const userProfile = await getUserProfile(user.uid);
          setAuthState({
            user,
            userProfile,
            loading: false,
            error: null
          });
        } catch (error) {
          console.error('Error fetching user profile:', error);
          setAuthState({
            user,
            userProfile: null,
            loading: false,
            error: 'Failed to load user profile'
          });
        }
      } else {
        setAuthState({
          user: null,
          userProfile: null,
          loading: false,
          error: null
        });
      }
    });

    return unsubscribe;
  }, []);

  const login = async () => {
    try {
      setAuthState(prev => ({ ...prev, loading: true, error: null }));
      await signInWithGoogle();
    } catch (error: any) {
      setAuthState(prev => ({ 
        ...prev, 
        loading: false, 
        error: error.message || 'Failed to sign in' 
      }));
    }
  };

  const logout = async () => {
    try {
      setAuthState(prev => ({ ...prev, loading: true, error: null }));
      await signOut();
    } catch (error: any) {
      setAuthState(prev => ({ 
        ...prev, 
        loading: false, 
        error: error.message || 'Failed to sign out' 
      }));
    }
  };

  const hasPermission = (permission: keyof FirebaseUser['permissions']): boolean => {
    return authState.userProfile?.permissions[permission] || false;
  };

  const isTier = (tier: UserTier): boolean => {
    return authState.userProfile?.tier === tier;
  };

  const canManageUser = (targetUserTier: UserTier): boolean => {
    const currentTier = authState.userProfile?.tier;
    if (!currentTier) return false;

    // T3 can manage T2 and T1
    if (currentTier === UserTier.T3) return true;
    
    // T2 can manage T1
    if (currentTier === UserTier.T2 && targetUserTier === UserTier.T1) return true;
    
    return false;
  };

  return {
    user: authState.user,
    userProfile: authState.userProfile,
    loading: authState.loading,
    error: authState.error,
    isAuthenticated: !!authState.user,
    login,
    logout,
    hasPermission,
    isTier,
    canManageUser
  };
}