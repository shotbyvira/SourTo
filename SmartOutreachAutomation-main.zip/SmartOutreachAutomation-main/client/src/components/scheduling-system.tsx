import React, { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Calendar, Clock, Users, Mail, 
  Plus, Edit, Trash2, AlertCircle, CheckCircle
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

interface SchedulingSystemProps {
  campaignId: number;
}

interface ScheduledMessage {
  id: number;
  contactId: number;
  contactName: string;
  contactEmail: string;
  subject: string;
  message: string;
  messageType: 'email' | 'whatsapp';
  scheduledAt: string;
  status: 'scheduled' | 'sent' | 'failed' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  recurrence?: {
    type: 'none' | 'daily' | 'weekly' | 'monthly';
    interval: number;
    endDate?: string;
  };
}

export function SchedulingSystem({ campaignId }: SchedulingSystemProps) {
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<ScheduledMessage | null>(null);
  const [selectedTimeZone, setSelectedTimeZone] = useState('UTC');
  const [newSchedule, setNewSchedule] = useState({
    contactId: '',
    subject: '',
    message: '',
    messageType: 'email' as 'email' | 'whatsapp',
    scheduledAt: '',
    priority: 'medium' as 'low' | 'medium' | 'high',
    recurrence: {
      type: 'none' as 'none' | 'daily' | 'weekly' | 'monthly',
      interval: 1,
      endDate: ''
    }
  });

  // Fetch scheduled messages
  const { data: scheduledMessages = [], isLoading } = useQuery({
    queryKey: [`/api/scheduled-messages/${campaignId}`],
    enabled: !!campaignId
  });

  // Fetch contacts for selection
  const { data: contacts = [] } = useQuery({
    queryKey: [`/api/contacts/campaign/${campaignId}`],
    enabled: !!campaignId
  });

  // Create scheduled message
  const createScheduleMutation = useMutation({
    mutationFn: async (scheduleData: any) => {
      return apiRequest('POST', '/api/scheduled-messages', {
        campaignId,
        ...scheduleData
      });
    },
    onSuccess: () => {
      toast({
        title: "Message Scheduled",
        description: "Your message has been successfully scheduled",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/scheduled-messages/${campaignId}`] });
      setIsCreating(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Scheduling Failed",
        description: error.message || "Failed to schedule message",
        variant: "destructive",
      });
    }
  });

  // Update scheduled message
  const updateScheduleMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      return apiRequest('PATCH', `/api/scheduled-messages/${id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Schedule Updated",
        description: "Scheduled message has been updated",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/scheduled-messages/${campaignId}`] });
      setEditingSchedule(null);
    }
  });

  // Cancel scheduled message
  const cancelScheduleMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest('PATCH', `/api/scheduled-messages/${id}/cancel`);
    },
    onSuccess: () => {
      toast({
        title: "Message Cancelled",
        description: "Scheduled message has been cancelled",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/scheduled-messages/${campaignId}`] });
    }
  });

  // Get user's timezone
  useEffect(() => {
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    setSelectedTimeZone(timezone);
  }, []);

  const resetForm = () => {
    setNewSchedule({
      contactId: '',
      subject: '',
      message: '',
      messageType: 'email',
      scheduledAt: '',
      priority: 'medium',
      recurrence: {
        type: 'none',
        interval: 1,
        endDate: ''
      }
    });
  };

  const handleCreateSchedule = () => {
    if (!newSchedule.contactId || !newSchedule.message || !newSchedule.scheduledAt) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const scheduledDate = new Date(newSchedule.scheduledAt);
    if (scheduledDate <= new Date()) {
      toast({
        title: "Invalid Date",
        description: "Scheduled date must be in the future",
        variant: "destructive",
      });
      return;
    }

    createScheduleMutation.mutate(newSchedule);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'scheduled': return <Clock className="h-4 w-4 text-blue-600" />;
      case 'sent': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'failed': return <AlertCircle className="h-4 w-4 text-red-600" />;
      case 'cancelled': return <Trash2 className="h-4 w-4 text-slate-600" />;
      default: return <Clock className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'sent': return 'bg-green-100 text-green-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-slate-100 text-slate-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const formatDateTime = (dateTime: string) => {
    return new Date(dateTime).toLocaleString('en-US', {
      timeZone: selectedTimeZone,
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const groupedMessages = {
    upcoming: scheduledMessages.filter((msg: ScheduledMessage) => 
      msg.status === 'scheduled' && new Date(msg.scheduledAt) > new Date()
    ),
    overdue: scheduledMessages.filter((msg: ScheduledMessage) => 
      msg.status === 'scheduled' && new Date(msg.scheduledAt) <= new Date()
    ),
    sent: scheduledMessages.filter((msg: ScheduledMessage) => msg.status === 'sent'),
    failed: scheduledMessages.filter((msg: ScheduledMessage) => msg.status === 'failed')
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Message Scheduling
            </CardTitle>
            
            <Dialog open={isCreating} onOpenChange={setIsCreating}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-1" />
                  Schedule Message
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Schedule New Message</DialogTitle>
                  <DialogDescription>
                    Schedule a personalized message to be sent at a specific time
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Contact</label>
                      <Select onValueChange={(value) => setNewSchedule(prev => ({ ...prev, contactId: value }))}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select a contact" />
                        </SelectTrigger>
                        <SelectContent>
                          {contacts.map((contact: any) => (
                            <SelectItem key={contact.id} value={contact.id.toString()}>
                              {contact.fullName} ({contact.email})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Message Type</label>
                      <Select 
                        value={newSchedule.messageType} 
                        onValueChange={(value: 'email' | 'whatsapp') => 
                          setNewSchedule(prev => ({ ...prev, messageType: value }))
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="email">Email</SelectItem>
                          <SelectItem value="whatsapp">WhatsApp</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  {newSchedule.messageType === 'email' && (
                    <div>
                      <label className="text-sm font-medium">Subject</label>
                      <Input
                        value={newSchedule.subject}
                        onChange={(e) => setNewSchedule(prev => ({ ...prev, subject: e.target.value }))}
                        placeholder="Enter email subject..."
                        className="mt-1"
                      />
                    </div>
                  )}
                  
                  <div>
                    <label className="text-sm font-medium">Message</label>
                    <Textarea
                      value={newSchedule.message}
                      onChange={(e) => setNewSchedule(prev => ({ ...prev, message: e.target.value }))}
                      placeholder="Enter your message..."
                      className="mt-1 min-h-[120px]"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-sm font-medium">Scheduled Date & Time</label>
                      <Input
                        type="datetime-local"
                        value={newSchedule.scheduledAt}
                        onChange={(e) => setNewSchedule(prev => ({ ...prev, scheduledAt: e.target.value }))}
                        className="mt-1"
                        min={new Date().toISOString().slice(0, 16)}
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Priority</label>
                      <Select 
                        value={newSchedule.priority} 
                        onValueChange={(value: 'low' | 'medium' | 'high') => 
                          setNewSchedule(prev => ({ ...prev, priority: value }))
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Recurrence</label>
                      <Select 
                        value={newSchedule.recurrence.type} 
                        onValueChange={(value: 'none' | 'daily' | 'weekly' | 'monthly') => 
                          setNewSchedule(prev => ({ 
                            ...prev, 
                            recurrence: { ...prev.recurrence, type: value }
                          }))
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  {newSchedule.recurrence.type !== 'none' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Interval</label>
                        <Input
                          type="number"
                          min="1"
                          value={newSchedule.recurrence.interval}
                          onChange={(e) => setNewSchedule(prev => ({ 
                            ...prev, 
                            recurrence: { ...prev.recurrence, interval: parseInt(e.target.value) }
                          }))}
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">End Date (Optional)</label>
                        <Input
                          type="date"
                          value={newSchedule.recurrence.endDate}
                          onChange={(e) => setNewSchedule(prev => ({ 
                            ...prev, 
                            recurrence: { ...prev.recurrence, endDate: e.target.value }
                          }))}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  )}
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="text-sm text-blue-800">
                      <strong>Timezone:</strong> {selectedTimeZone} • Messages will be sent according to this timezone
                    </div>
                  </div>
                  
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button variant="outline" onClick={() => setIsCreating(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleCreateSchedule}
                      disabled={createScheduleMutation.isPending}
                    >
                      {createScheduleMutation.isPending ? 'Scheduling...' : 'Schedule Message'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{groupedMessages.upcoming.length}</div>
              <div className="text-xs text-slate-500">Upcoming</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{groupedMessages.sent.length}</div>
              <div className="text-xs text-slate-500">Sent</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{groupedMessages.overdue.length}</div>
              <div className="text-xs text-slate-500">Overdue</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-slate-600">{groupedMessages.failed.length}</div>
              <div className="text-xs text-slate-500">Failed</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Scheduled Messages */}
      <div className="space-y-4">
        {/* Upcoming Messages */}
        {groupedMessages.upcoming.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Upcoming Messages</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {groupedMessages.upcoming.map((message: ScheduledMessage) => (
                  <div key={message.id} className="border rounded-lg p-4 bg-blue-50">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2">
                          {message.messageType === 'email' ? (
                            <Mail className="h-4 w-4 text-blue-600" />
                          ) : (
                            <Users className="h-4 w-4 text-green-600" />
                          )}
                          <span className="font-medium">{message.contactName}</span>
                        </div>
                        <Badge className={getPriorityColor(message.priority)}>
                          {message.priority}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Badge className={getStatusColor(message.status)}>
                          {getStatusIcon(message.status)}
                          <span className="ml-1 capitalize">{message.status}</span>
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingSchedule(message)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => cancelScheduleMutation.mutate(message.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      {message.subject && (
                        <div>
                          <span className="text-xs font-medium text-slate-600">Subject:</span>
                          <div className="text-sm">{message.subject}</div>
                        </div>
                      )}
                      <div>
                        <span className="text-xs font-medium text-slate-600">Message:</span>
                        <div className="text-sm text-slate-600 truncate">{message.message}</div>
                      </div>
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span>Scheduled: {formatDateTime(message.scheduledAt)}</span>
                        {message.recurrence?.type !== 'none' && (
                          <span>Repeats {message.recurrence.type}</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Sent Messages */}
        {groupedMessages.sent.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recently Sent</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {groupedMessages.sent.slice(0, 5).map((message: ScheduledMessage) => (
                  <div key={message.id} className="border rounded-lg p-4 bg-green-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2">
                          {message.messageType === 'email' ? (
                            <Mail className="h-4 w-4 text-green-600" />
                          ) : (
                            <Users className="h-4 w-4 text-green-600" />
                          )}
                          <span className="font-medium">{message.contactName}</span>
                        </div>
                        <Badge className={getStatusColor(message.status)}>
                          {getStatusIcon(message.status)}
                          <span className="ml-1">Sent</span>
                        </Badge>
                      </div>
                      <span className="text-xs text-slate-500">
                        {formatDateTime(message.scheduledAt)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {scheduledMessages.length === 0 && !isLoading && (
          <Card>
            <CardContent className="p-6 text-center">
              <Calendar className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No Scheduled Messages</h3>
              <p className="text-slate-500 mb-4">Create your first scheduled message to automate your outreach</p>
              <Button onClick={() => setIsCreating(true)}>
                <Plus className="h-4 w-4 mr-1" />
                Schedule Your First Message
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}