import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Home, Calendar, MessageCircle, BarChart3, 
  Users, Settings, Menu, X, Bell, Plus
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { useFirebaseAuth } from '@/hooks/useFirebaseAuth';

export function MobileNav() {
  const [location, setLocation] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const { userProfile, logout } = useFirebaseAuth();

  const navItems = [
    { 
      icon: Home, 
      label: 'Dashboard', 
      path: '/dashboard',
      active: location === '/dashboard' || location === '/'
    },
    { 
      icon: Calendar, 
      label: 'Schedule', 
      path: '/schedule',
      active: location === '/schedule'
    },
    { 
      icon: MessageCircle, 
      label: 'Messages', 
      path: '/messages',
      active: location === '/messages'
    },
    { 
      icon: BarChart3, 
      label: 'Analytics', 
      path: '/analytics',
      active: location === '/analytics'
    },
    { 
      icon: Users, 
      label: 'Team', 
      path: '/team',
      active: location === '/team'
    },
    { 
      icon: Settings, 
      label: 'Settings', 
      path: '/settings',
      active: location === '/settings'
    }
  ];

  const handleNavigation = (path: string) => {
    setLocation(path);
    setIsOpen(false);
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'T3': return 'bg-purple-100 text-purple-800';
      case 'T2': return 'bg-blue-100 text-blue-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  return (
    <>
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center space-x-3">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <SheetHeader>
                <SheetTitle className="text-left">Smart Outreach</SheetTitle>
              </SheetHeader>
              
              <div className="mt-6 space-y-1">
                {/* User Profile Section */}
                <div className="bg-slate-50 rounded-lg p-4 mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium">
                      {userProfile?.displayName?.charAt(0) || userProfile?.email?.charAt(0) || 'U'}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-sm">
                        {userProfile?.displayName || 'User'}
                      </div>
                      <div className="text-xs text-slate-500">
                        {userProfile?.email}
                      </div>
                    </div>
                    <Badge className={getTierColor(userProfile?.tier || 'T1')}>
                      {userProfile?.tier || 'T1'}
                    </Badge>
                  </div>
                </div>

                {/* Navigation Items */}
                {navItems.map((item) => (
                  <Button
                    key={item.path}
                    variant={item.active ? "default" : "ghost"}
                    className={`w-full justify-start ${item.active ? 'bg-blue-600 text-white' : ''}`}
                    onClick={() => handleNavigation(item.path)}
                  >
                    <item.icon className="h-4 w-4 mr-3" />
                    {item.label}
                  </Button>
                ))}

                {/* Logout Button */}
                <div className="pt-4 mt-4 border-t">
                  <Button
                    variant="outline"
                    className="w-full justify-start text-red-600 border-red-200"
                    onClick={logout}
                  >
                    <X className="h-4 w-4 mr-3" />
                    Sign Out
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          <h1 className="text-lg font-semibold text-slate-900">Smart Outreach</h1>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm">
            <Bell className="h-5 w-5" />
          </Button>
          <Button size="sm">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-2 py-2 z-50">
        <div className="flex justify-around">
          {navItems.slice(0, 5).map((item) => (
            <Button
              key={item.path}
              variant="ghost"
              size="sm"
              className={`flex flex-col items-center space-y-1 h-auto py-2 px-3 ${
                item.active ? 'text-blue-600' : 'text-slate-600'
              }`}
              onClick={() => handleNavigation(item.path)}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs">{item.label}</span>
            </Button>
          ))}
        </div>
      </div>
    </>
  );
}