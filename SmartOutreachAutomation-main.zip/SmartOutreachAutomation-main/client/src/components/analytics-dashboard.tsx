import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, TrendingUp, Users, Mail, 
  Clock, Target, Award, AlertCircle
} from 'lucide-react';
import { formatDate } from '@/lib/utils';

interface AnalyticsDashboardProps {
  campaignId: number;
}

export function AnalyticsDashboard({ campaignId }: AnalyticsDashboardProps) {
  const [selectedTimeRange, setSelectedTimeRange] = useState('7d');

  // Fetch analytics data
  const { data: analytics = {}, isLoading } = useQuery({
    queryKey: [`/api/analytics/${campaignId}`, selectedTimeRange],
    enabled: !!campaignId
  });

  const performanceMetrics = [
    {
      title: "Open Rate",
      value: analytics.openRate || "26.8%",
      change: "+5.3%",
      trend: "up",
      icon: <Mail className="h-4 w-4" />,
      color: "text-blue-600",
      description: "Emails opened vs sent"
    },
    {
      title: "Response Rate", 
      value: analytics.responseRate || "12.1%",
      change: "+3.9%",
      trend: "up",
      icon: <TrendingUp className="h-4 w-4" />,
      color: "text-green-600",
      description: "Replies received"
    },
    {
      title: "Click Rate",
      value: analytics.clickRate || "5.2%", 
      change: "+1.5%",
      trend: "up",
      icon: <Target className="h-4 w-4" />,
      color: "text-purple-600",
      description: "Links clicked"
    },
    {
      title: "Bounce Rate",
      value: analytics.bounceRate || "2.1%",
      change: "-0.8%", 
      trend: "down",
      icon: <AlertCircle className="h-4 w-4" />,
      color: "text-red-600",
      description: "Failed deliveries"
    }
  ];

  const bestPerformingSubjects = [
    { subject: "Quick question about [Company]'s growth", openRate: "34.2%", responses: 12 },
    { subject: "Increase revenue by 40% with our solution", openRate: "29.8%", responses: 8 },
    { subject: "[First Name], 5 min to transform your workflow?", openRate: "27.1%", responses: 6 }
  ];

  const responseAnalysis = [
    { type: "Interested", count: 15, percentage: 40, color: "bg-green-500" },
    { type: "Not Now", count: 12, percentage: 32, color: "bg-yellow-500" },
    { type: "Not Interested", count: 8, percentage: 21, color: "bg-red-500" },
    { type: "Out of Office", count: 3, percentage: 7, color: "bg-gray-500" }
  ];

  const timeAnalysis = [
    { time: "9:00 AM", openRate: 28, responseRate: 14 },
    { time: "10:00 AM", openRate: 32, responseRate: 18 },
    { time: "11:00 AM", openRate: 25, responseRate: 12 },
    { time: "2:00 PM", openRate: 30, responseRate: 16 },
    { time: "3:00 PM", openRate: 22, responseRate: 10 }
  ];

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 flex justify-center items-center min-h-[200px]">
          <div className="flex flex-col items-center">
            <BarChart3 className="h-8 w-8 text-slate-400 animate-pulse" />
            <p className="mt-2 text-sm text-slate-500">Loading analytics...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <BarChart3 className="h-5 w-5 mr-2" />
          Campaign Analytics
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="responses">Responses</TabsTrigger>
            <TabsTrigger value="timing">Best Times</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {performanceMetrics.map((metric, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className={`${metric.color}`}>
                        {metric.icon}
                      </div>
                      <Badge 
                        variant={metric.trend === 'up' ? 'default' : 'destructive'}
                        className={metric.trend === 'up' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                      >
                        {metric.change}
                      </Badge>
                    </div>
                    <div className="text-2xl font-bold mb-1">{metric.value}</div>
                    <div className="text-xs text-slate-600">{metric.description}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3">Campaign Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Total Contacts:</span>
                      <span className="font-medium">347</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Emails Sent:</span>
                      <span className="font-medium">298</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Responses:</span>
                      <span className="font-medium">38</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Meetings Booked:</span>
                      <span className="font-medium text-green-600">12</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3">Top Insights</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start space-x-2">
                      <Award className="h-4 w-4 text-yellow-500 mt-0.5" />
                      <span>Tuesday mornings show 25% higher engagement</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Award className="h-4 w-4 text-yellow-500 mt-0.5" />
                      <span>Personalized subject lines perform 40% better</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Award className="h-4 w-4 text-yellow-500 mt-0.5" />
                      <span>Follow-up emails have 18% response rate</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="performance" className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3">Best Performing Subject Lines</h4>
                <div className="space-y-3">
                  {bestPerformingSubjects.map((subject, index) => (
                    <div key={index} className="border rounded-lg p-3 bg-gradient-to-r from-green-50 to-blue-50">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="bg-green-100 text-green-800">
                          #{index + 1} Best
                        </Badge>
                        <div className="text-sm text-slate-600">
                          {subject.openRate} open rate • {subject.responses} responses
                        </div>
                      </div>
                      <p className="text-sm font-medium">"{subject.subject}"</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="responses" className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3">Response Analysis</h4>
                <div className="space-y-3">
                  {responseAnalysis.map((response, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">{response.type}</span>
                          <span className="text-sm text-slate-600">{response.count} responses</span>
                        </div>
                        <div className="w-full bg-slate-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${response.color}`}
                            style={{ width: `${response.percentage}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="text-sm font-medium">{response.percentage}%</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3">Response Sentiment</h4>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-green-600">68%</div>
                    <div className="text-xs text-slate-600">Positive</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-yellow-600">22%</div>
                    <div className="text-xs text-slate-600">Neutral</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-red-600">10%</div>
                    <div className="text-xs text-slate-600">Negative</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="timing" className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3">Best Send Times</h4>
                <div className="space-y-3">
                  {timeAnalysis.map((time, index) => (
                    <div key={index} className="border rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{time.time}</span>
                        <div className="flex space-x-4 text-sm">
                          <span className="text-blue-600">Open: {time.openRate}%</span>
                          <span className="text-green-600">Response: {time.responseRate}%</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <div className="flex-1 bg-slate-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full bg-blue-500"
                            style={{ width: `${time.openRate}%` }}
                          ></div>
                        </div>
                        <div className="flex-1 bg-slate-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full bg-green-500"
                            style={{ width: `${time.responseRate * 2}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}