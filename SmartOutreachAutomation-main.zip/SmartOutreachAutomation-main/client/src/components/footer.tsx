import React from 'react';
import { Link } from 'wouter';
import { FileText, HelpCircle, Github } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-white border-t border-slate-200 mt-12">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex justify-center md:justify-start space-x-6">
            <Link href="/docs">
              <span className="text-slate-400 hover:text-slate-500 cursor-pointer">
                <span className="sr-only">Documentation</span>
                <FileText className="h-5 w-5" />
              </span>
            </Link>
            <Link href="/support">
              <span className="text-slate-400 hover:text-slate-500 cursor-pointer">
                <span className="sr-only">Support</span>
                <HelpCircle className="h-5 w-5" />
              </span>
            </Link>
            <Link href="https://github.com">
              <span className="text-slate-400 hover:text-slate-500 cursor-pointer">
                <span className="sr-only">GitHub</span>
                <Github className="h-5 w-5" />
              </span>
            </Link>
          </div>
          <p className="mt-8 text-center md:mt-0 text-xs text-slate-500">
            &copy; {new Date().getFullYear()} Smart Outreach Automation. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
