import React, { useState, useEffect } from 'react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, Clock, AlertCircle, 
  Loader2, Zap, TrendingUp 
} from 'lucide-react';

interface AnimatedProgressProps {
  value: number;
  max?: number;
  status?: 'idle' | 'loading' | 'success' | 'error';
  showPercentage?: boolean;
  animated?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'success' | 'warning' | 'error';
  label?: string;
  sublabel?: string;
  steps?: Array<{
    label: string;
    completed: boolean;
    current?: boolean;
  }>;
}

export function AnimatedProgress({
  value,
  max = 100,
  status = 'idle',
  showPercentage = true,
  animated = true,
  size = 'md',
  variant = 'default',
  label,
  sublabel,
  steps
}: AnimatedProgressProps) {
  const [displayValue, setDisplayValue] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const percentage = Math.min((value / max) * 100, 100);

  // Animate progress bar
  useEffect(() => {
    if (animated && value !== displayValue) {
      setIsAnimating(true);
      const startValue = displayValue;
      const endValue = percentage;
      const duration = 1000; // 1 second animation
      const startTime = Date.now();

      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for smooth animation
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const currentValue = startValue + (endValue - startValue) * easeOut;
        
        setDisplayValue(currentValue);

        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setIsAnimating(false);
        }
      };

      requestAnimationFrame(animate);
    } else {
      setDisplayValue(percentage);
    }
  }, [value, percentage, animated, displayValue]);

  const getVariantColors = () => {
    switch (variant) {
      case 'success':
        return 'bg-green-500';
      case 'warning':
        return 'bg-yellow-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-blue-500';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'loading':
        return <Loader2 className="h-4 w-4 animate-spin text-blue-600" />;
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      default:
        return isAnimating ? <TrendingUp className="h-4 w-4 text-blue-600" /> : <Clock className="h-4 w-4 text-slate-400" />;
    }
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'h-2';
      case 'lg':
        return 'h-4';
      default:
        return 'h-3';
    }
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      {(label || showPercentage) && (
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            {label && (
              <span className="text-sm font-medium text-slate-900">{label}</span>
            )}
          </div>
          {showPercentage && (
            <Badge variant="outline" className="text-xs">
              {Math.round(displayValue)}%
            </Badge>
          )}
        </div>
      )}

      {/* Progress Bar */}
      <div className="relative">
        <div className={`w-full ${getSizeClasses()} bg-slate-200 rounded-full overflow-hidden`}>
          <div
            className={`h-full ${getVariantColors()} rounded-full transition-all duration-300 ease-out relative`}
            style={{ width: `${displayValue}%` }}
          >
            {/* Animated shine effect */}
            {animated && isAnimating && (
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30 animate-pulse" />
            )}
            
            {/* Pulse effect for active progress */}
            {status === 'loading' && (
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-20 animate-ping" />
            )}
          </div>
        </div>

        {/* Glowing effect for high progress */}
        {displayValue > 80 && variant === 'success' && (
          <div className="absolute inset-0 bg-green-400 rounded-full animate-pulse opacity-20" />
        )}
      </div>

      {/* Sublabel */}
      {sublabel && (
        <p className="text-xs text-slate-500">{sublabel}</p>
      )}

      {/* Step indicators */}
      {steps && (
        <div className="grid grid-cols-1 gap-2">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`flex items-center space-x-2 p-2 rounded-lg transition-colors ${
                step.current 
                  ? 'bg-blue-50 border border-blue-200' 
                  : step.completed 
                    ? 'bg-green-50 border border-green-200' 
                    : 'bg-slate-50 border border-slate-200'
              }`}
            >
              <div className="flex-shrink-0">
                {step.completed ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : step.current ? (
                  <Loader2 className="h-4 w-4 text-blue-600 animate-spin" />
                ) : (
                  <Clock className="h-4 w-4 text-slate-400" />
                )}
              </div>
              <span className={`text-sm ${
                step.current 
                  ? 'text-blue-900 font-medium' 
                  : step.completed 
                    ? 'text-green-900' 
                    : 'text-slate-600'
              }`}>
                {step.label}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Specialized progress components
export function CampaignProgress({ 
  sent, 
  total, 
  status 
}: { 
  sent: number; 
  total: number; 
  status: 'idle' | 'running' | 'completed' | 'paused' 
}) {
  const steps = [
    { label: 'Preparing contacts', completed: true },
    { label: 'Drafting messages', completed: sent > 0, current: status === 'running' && sent === 0 },
    { label: 'Sending messages', completed: sent === total, current: status === 'running' && sent > 0 },
    { label: 'Campaign completed', completed: sent === total && status === 'completed' }
  ];

  return (
    <AnimatedProgress
      value={sent}
      max={total}
      status={status === 'running' ? 'loading' : status === 'completed' ? 'success' : 'idle'}
      label="Campaign Progress"
      sublabel={`${sent} of ${total} messages sent`}
      variant={status === 'completed' ? 'success' : 'default'}
      steps={steps}
      animated={true}
    />
  );
}

export function UploadProgress({ 
  uploaded, 
  total, 
  fileName 
}: { 
  uploaded: number; 
  total: number; 
  fileName: string 
}) {
  return (
    <AnimatedProgress
      value={uploaded}
      max={total}
      status={uploaded === total ? 'success' : 'loading'}
      label={`Uploading ${fileName}`}
      sublabel={`${(uploaded / 1024 / 1024).toFixed(1)} MB of ${(total / 1024 / 1024).toFixed(1)} MB`}
      variant={uploaded === total ? 'success' : 'default'}
      animated={true}
    />
  );
}

export function AnalyticsProgress({ 
  openRate, 
  responseRate, 
  targetOpenRate = 25, 
  targetResponseRate = 10 
}: { 
  openRate: number; 
  responseRate: number; 
  targetOpenRate?: number; 
  targetResponseRate?: number 
}) {
  return (
    <div className="space-y-4">
      <AnimatedProgress
        value={openRate}
        max={100}
        status={openRate >= targetOpenRate ? 'success' : 'idle'}
        label="Open Rate"
        sublabel={`Target: ${targetOpenRate}%`}
        variant={openRate >= targetOpenRate ? 'success' : openRate >= targetOpenRate * 0.8 ? 'warning' : 'default'}
        animated={true}
      />
      
      <AnimatedProgress
        value={responseRate}
        max={100}
        status={responseRate >= targetResponseRate ? 'success' : 'idle'}
        label="Response Rate"
        sublabel={`Target: ${targetResponseRate}%`}
        variant={responseRate >= targetResponseRate ? 'success' : responseRate >= targetResponseRate * 0.8 ? 'warning' : 'default'}
        animated={true}
      />
    </div>
  );
}

export function TeamProgress({ 
  activeMembers, 
  totalMembers, 
  tasksCompleted, 
  totalTasks 
}: { 
  activeMembers: number; 
  totalMembers: number; 
  tasksCompleted: number; 
  totalTasks: number 
}) {
  return (
    <div className="space-y-4">
      <AnimatedProgress
        value={activeMembers}
        max={totalMembers}
        status="idle"
        label="Active Team Members"
        sublabel={`${activeMembers} of ${totalMembers} members active today`}
        variant="default"
        animated={true}
      />
      
      <AnimatedProgress
        value={tasksCompleted}
        max={totalTasks}
        status={tasksCompleted === totalTasks ? 'success' : 'loading'}
        label="Tasks Completed"
        sublabel={`${tasksCompleted} of ${totalTasks} tasks done`}
        variant={tasksCompleted === totalTasks ? 'success' : 'default'}
        animated={true}
      />
    </div>
  );
}