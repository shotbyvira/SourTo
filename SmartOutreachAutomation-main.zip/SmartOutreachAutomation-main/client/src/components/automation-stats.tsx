import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Activity, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { formatRelativeTime } from '@/lib/utils';

interface AutomationStatsProps {
  campaignId: number;
}

export function AutomationStats({ campaignId }: AutomationStatsProps) {
  // Get contact stats
  const { data: stats = { total: 0, processed: 0, sent: 0, drafted: 0, failed: 0, pending: 0 }, isLoading: isLoadingStats } = useQuery({
    queryKey: [`/api/stats/campaign/${campaignId}`],
    enabled: !!campaignId
  });

  // Get recent activity logs
  const { data: logs = [], isLoading: isLoadingLogs } = useQuery({
    queryKey: [`/api/logs/campaign/${campaignId}?limit=4`],
    enabled: !!campaignId
  });

  // Calculate success rate
  const successRate = stats.total > 0 
    ? Math.round((stats.sent / (stats.total - stats.pending)) * 100) 
    : 0;

  const getActivityIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-500 flex-shrink-0" />;
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Automation Stats</h2>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-500">Total Contacts</p>
            <p className="text-2xl font-semibold text-slate-700">
              {isLoadingStats ? '-' : stats.total}
            </p>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-500">Processed</p>
            <p className="text-2xl font-semibold text-slate-700">
              {isLoadingStats ? '-' : (stats.sent + stats.drafted + stats.failed)}
            </p>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-500">Success Rate</p>
            <p className="text-2xl font-semibold text-green-600">
              {isLoadingStats ? '-' : `${isNaN(successRate) ? 0 : successRate}%`}
            </p>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-500">Errors</p>
            <p className="text-2xl font-semibold text-red-600">
              {isLoadingStats ? '-' : stats.failed}
            </p>
          </div>
        </div>
        
        <div className="mt-4 pt-4 border-t border-slate-200">
          <h3 className="font-medium text-slate-700 mb-2">Recent Activity</h3>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {isLoadingLogs ? (
              <div className="text-sm text-slate-500">Loading activity...</div>
            ) : logs.length === 0 ? (
              <div className="text-sm text-slate-500">No activity yet</div>
            ) : (
              logs.map((log: any) => (
                <div key={log.id} className="flex items-start space-x-2 text-sm">
                  {getActivityIcon(log.status)}
                  <div>
                    <p className="text-slate-700">{log.message}</p>
                    <p className="text-slate-400">{formatRelativeTime(new Date(log.createdAt))}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
