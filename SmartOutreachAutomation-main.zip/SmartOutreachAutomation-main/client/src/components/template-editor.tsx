import React, { useState, useRef, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Mail, MessageSquare, HelpCircle, Save, Eye } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AVAILABLE_TAGS } from '@/lib/placeholderReplacer';

interface TemplateEditorProps {
  campaignId: number;
  initialTemplate?: {
    id?: number;
    subject?: string;
    body?: string;
    type?: string;
  };
  onSave?: (templateId: number) => void;
}

export function TemplateEditor({ 
  campaignId, 
  initialTemplate = { subject: '', body: '', type: 'email' },
  onSave 
}: TemplateEditorProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>(initialTemplate.type || 'email');
  const [emailSubject, setEmailSubject] = useState<string>(initialTemplate.subject || '');
  const [emailBody, setEmailBody] = useState<string>(initialTemplate.body || DEFAULT_EMAIL_TEMPLATE);
  const [whatsappBody, setWhatsappBody] = useState<string>('');
  const emailBodyRef = useRef<HTMLTextAreaElement>(null);
  const whatsappBodyRef = useRef<HTMLTextAreaElement>(null);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const endpoint = initialTemplate.id 
        ? `/api/templates/${initialTemplate.id}`
        : '/api/templates';
      
      const method = initialTemplate.id ? 'PATCH' : 'POST';
      
      const body = activeTab === 'email'
        ? { campaignId, subject: emailSubject, body: emailBody, type: 'email' }
        : { campaignId, body: whatsappBody, type: 'whatsapp' };
      
      return apiRequest(method, endpoint, body);
    },
    onSuccess: async (response) => {
      const savedTemplate = await response.json();
      toast({
        title: "Template Saved",
        description: "Your template has been saved successfully.",
      });
      
      if (onSave && savedTemplate.id) {
        onSave(savedTemplate.id);
      }
    },
    onError: (error) => {
      toast({
        title: "Save Failed",
        description: error.message || "Failed to save template",
        variant: "destructive",
      });
    }
  });

  const handleSaveTemplate = () => {
    if (activeTab === 'email' && !emailSubject) {
      toast({
        title: "Subject Required",
        description: "Please enter an email subject before saving.",
        variant: "destructive",
      });
      return;
    }
    
    if ((activeTab === 'email' && !emailBody) || (activeTab === 'whatsapp' && !whatsappBody)) {
      toast({
        title: "Message Required",
        description: "Please enter a message body before saving.",
        variant: "destructive",
      });
      return;
    }
    
    saveMutation.mutate();
  };

  const insertPlaceholderTag = (tag: string) => {
    if (activeTab === 'email') {
      const textarea = emailBodyRef.current;
      if (textarea) {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = textarea.value;
        const before = text.substring(0, start);
        const after = text.substring(end);
        
        setEmailBody(before + tag + after);
        
        // Set cursor position after the inserted tag
        setTimeout(() => {
          textarea.focus();
          textarea.selectionStart = start + tag.length;
          textarea.selectionEnd = start + tag.length;
        }, 0);
      }
    } else {
      const textarea = whatsappBodyRef.current;
      if (textarea) {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = textarea.value;
        const before = text.substring(0, start);
        const after = text.substring(end);
        
        setWhatsappBody(before + tag + after);
        
        // Set cursor position after the inserted tag
        setTimeout(() => {
          textarea.focus();
          textarea.selectionStart = start + tag.length;
          textarea.selectionEnd = start + tag.length;
        }, 0);
      }
    }
  };

  const handlePreview = () => {
    toast({
      title: "Template Preview",
      description: "Preview functionality coming soon",
    });
  };

  return (
    <Card className="shadow overflow-hidden">
      <div className="px-6 py-4 bg-slate-50 border-b border-slate-200">
        <h2 className="text-lg font-semibold text-slate-900">Message Templates</h2>
        <p className="text-slate-500 text-sm">
          Create personalized templates using 
          <span className="inline-block mx-1 py-0.5 px-1.5 bg-purple-100 text-purple-600 rounded font-mono text-xs">&lt;tags&gt;</span>
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} defaultValue="email">
        <div className="border-b border-slate-200">
          <TabsList className="bg-transparent border-b h-auto p-0">
            <TabsTrigger 
              value="email" 
              className="data-[state=active]:border-primary-500 data-[state=active]:text-primary-600 border-b-2 border-transparent px-6 py-3 rounded-none"
            >
              <Mail className="mr-2 h-4 w-4" />
              Email Template
            </TabsTrigger>
            <TabsTrigger 
              value="whatsapp"
              className="data-[state=active]:border-primary-500 data-[state=active]:text-primary-600 border-b-2 border-transparent px-6 py-3 rounded-none"
            >
              <MessageSquare className="mr-2 h-4 w-4" />
              WhatsApp Template
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="email" className="p-6">
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="email-subject" className="block text-sm font-medium text-slate-700">
                  Email Subject
                </label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <HelpCircle className="h-4 w-4 text-slate-400" />
                        <span className="sr-only">Help</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs">
                        Use tags like &lt;First Name&gt;, &lt;Company&gt; to personalize your subject line.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Input
                id="email-subject"
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
                className="mt-1"
                placeholder="Enter email subject"
              />
            </div>
            
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="email-body" className="block text-sm font-medium text-slate-700">
                  Email Body
                </label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <HelpCircle className="h-4 w-4 text-slate-400" />
                        <span className="sr-only">Help</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs">
                        Available tags: &lt;Honorific&gt;, &lt;First Name&gt;, &lt;Middle Name&gt;, &lt;Last Name&gt;, &lt;Company&gt;
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Textarea
                id="email-body"
                ref={emailBodyRef}
                value={emailBody}
                onChange={(e) => setEmailBody(e.target.value)}
                className="mt-1 font-sans"
                rows={12}
                placeholder="Enter email body"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700">Available Tags</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {AVAILABLE_TAGS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    className="py-0.5 px-1.5 rounded bg-purple-100 text-purple-600 font-mono text-xs hover:bg-purple-200 transition-colors"
                    onClick={() => insertPlaceholderTag(tag)}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="whatsapp" className="p-6">
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="whatsapp-body" className="block text-sm font-medium text-slate-700">
                  WhatsApp Message
                </label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <HelpCircle className="h-4 w-4 text-slate-400" />
                        <span className="sr-only">Help</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs">
                        Available tags: &lt;Honorific&gt;, &lt;First Name&gt;, &lt;Middle Name&gt;, &lt;Last Name&gt;, &lt;Company&gt;
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Textarea
                id="whatsapp-body"
                ref={whatsappBodyRef}
                value={whatsappBody}
                onChange={(e) => setWhatsappBody(e.target.value)}
                className="mt-1"
                rows={12}
                placeholder="Enter WhatsApp message"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700">Available Tags</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {AVAILABLE_TAGS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    className="py-0.5 px-1.5 rounded bg-purple-100 text-purple-600 font-mono text-xs hover:bg-purple-200 transition-colors"
                    onClick={() => insertPlaceholderTag(tag)}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
      
      <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex justify-start space-x-3">
        <Button 
          onClick={handleSaveTemplate}
          disabled={saveMutation.isPending}
        >
          <Save className="mr-1.5 h-4 w-4" />
          {saveMutation.isPending ? "Saving..." : "Save Template"}
        </Button>
        <Button 
          variant="outline"
          onClick={handlePreview}
        >
          <Eye className="mr-1.5 h-4 w-4" />
          Preview
        </Button>
      </div>
    </Card>
  );
}

// Default email template with placeholders
const DEFAULT_EMAIL_TEMPLATE = `Dear <Honorific> <Last Name>,

I hope this email finds you well. My name is Jane Smith from MarketBoost, and I recently came across <Company> while researching innovative companies in the industry.

I'd love to schedule a quick 15-minute call to discuss how MarketBoost's automation solutions could help <Company> streamline your outreach processes.

Would you be available for a brief call next week?

Best regards,
Jane Smith
Marketing Director
MarketBoost
jane@marketboost.com
+1 (555) 123-4567`;
