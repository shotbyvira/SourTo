import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';

interface ProgressTrackingProps {
  campaignId: number;
}

export function ProgressTracking({ campaignId }: ProgressTrackingProps) {
  // Get contact stats
  const { data: stats = { total: 0, sent: 0, drafted: 0, failed: 0, pending: 0 }, isLoading } = useQuery({
    queryKey: [`/api/stats/campaign/${campaignId}`],
    enabled: !!campaignId
  });

  // Calculate progress percentage
  const progressPercentage = stats.total > 0 
    ? Math.round(((stats.sent + stats.drafted + stats.failed) / stats.total) * 100) 
    : 0;

  const handleExportReport = () => {
    // In a real implementation, this would call an API endpoint to generate a report
    alert('Export functionality will be implemented in a future update.');
  };

  const progressCount = stats.sent + stats.drafted + stats.failed;
  const totalCount = stats.total;

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-slate-900">Outreach Progress</h2>
          
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={handleExportReport}>
              <FileText className="h-4 w-4 mr-1" />
              Export Report
            </Button>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium text-slate-700">Progress</span>
            <span className="text-sm font-medium text-slate-700">
              {isLoading ? '-' : `${progressCount}/${totalCount}`}
            </span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2.5">
            <div 
              className="bg-primary-600 h-2.5 rounded-full" 
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="p-3 bg-slate-50 rounded border border-slate-200">
            <span className="text-xs font-medium text-slate-500 block">Sent</span>
            <span className="text-lg font-semibold text-green-600">{isLoading ? '-' : stats.sent}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded border border-slate-200">
            <span className="text-xs font-medium text-slate-500 block">Drafted</span>
            <span className="text-lg font-semibold text-yellow-600">{isLoading ? '-' : stats.drafted}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded border border-slate-200">
            <span className="text-xs font-medium text-slate-500 block">Failed</span>
            <span className="text-lg font-semibold text-red-600">{isLoading ? '-' : stats.failed}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded border border-slate-200">
            <span className="text-xs font-medium text-slate-500 block">Pending</span>
            <span className="text-lg font-semibold text-primary-600">{isLoading ? '-' : stats.pending}</span>
          </div>
        </div>
        
        {/* Email marketing image */}
        <div className="mt-6 rounded-lg overflow-hidden border border-slate-200">
          <div className="h-40 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 p-6 flex items-center justify-center">
            <div className="text-center">
              <h3 className="text-lg font-medium text-slate-800">Smart Email Outreach</h3>
              <p className="text-sm text-slate-600 mt-2">
                Personalized communication at scale
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
