import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  MessageCircle, Phone, Send, 
  CheckCircle, Clock, AlertCircle, Settings
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

interface WhatsAppIntegrationProps {
  campaignId: number;
}

export function WhatsAppIntegration({ campaignId }: WhatsAppIntegrationProps) {
  const { toast } = useToast();
  const [isSetupOpen, setIsSetupOpen] = useState(false);
  const [isSendingBulk, setIsSendingBulk] = useState(false);
  const [whatsappConfig, setWhatsappConfig] = useState({
    accessToken: '',
    phoneNumberId: '',
    verifyToken: '',
    businessAccountId: ''
  });
  const [bulkMessage, setBulkMessage] = useState({
    templateName: '',
    message: '',
    includeMedia: false,
    mediaUrl: '',
    scheduledAt: ''
  });

  // Fetch WhatsApp integration status
  const { data: integration, isLoading } = useQuery({
    queryKey: [`/api/whatsapp-integration/${campaignId}`],
    enabled: !!campaignId
  });

  // Fetch message templates
  const { data: templates = [] } = useQuery({
    queryKey: [`/api/whatsapp-templates/${campaignId}`],
    enabled: !!campaignId && integration?.isConnected
  });

  // Setup WhatsApp Business API
  const setupMutation = useMutation({
    mutationFn: async (config: any) => {
      return apiRequest('POST', '/api/whatsapp-integration/setup', {
        campaignId,
        ...config
      });
    },
    onSuccess: () => {
      toast({
        title: "WhatsApp Connected",
        description: "WhatsApp Business API has been successfully configured",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/whatsapp-integration/${campaignId}`] });
      setIsSetupOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Setup Failed",
        description: error.message || "Failed to setup WhatsApp Business API",
        variant: "destructive",
      });
    }
  });

  // Send bulk WhatsApp messages
  const sendBulkMutation = useMutation({
    mutationFn: async (messageData: any) => {
      return apiRequest('POST', '/api/whatsapp/send-bulk', {
        campaignId,
        ...messageData
      });
    },
    onSuccess: (response) => {
      const data = response;
      toast({
        title: "Messages Sent",
        description: `Bulk WhatsApp messages sent successfully to ${data.sentCount} contacts`,
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/whatsapp-messages/${campaignId}`] });
      setIsSendingBulk(false);
    },
    onError: (error) => {
      toast({
        title: "Send Failed", 
        description: error.message || "Failed to send WhatsApp messages",
        variant: "destructive",
      });
    }
  });

  // Test WhatsApp connection
  const testConnectionMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', `/api/whatsapp-integration/${campaignId}/test`);
    },
    onSuccess: () => {
      toast({
        title: "Connection Successful",
        description: "WhatsApp Business API connection verified",
        variant: "default",
      });
    }
  });

  const handleSetup = () => {
    if (!whatsappConfig.accessToken || !whatsappConfig.phoneNumberId) {
      toast({
        title: "Missing Configuration",
        description: "Please provide access token and phone number ID",
        variant: "destructive",
      });
      return;
    }
    setupMutation.mutate(whatsappConfig);
  };

  const handleSendBulk = () => {
    if (!bulkMessage.message) {
      toast({
        title: "Message Required",
        description: "Please enter a message to send",
        variant: "destructive",
      });
      return;
    }
    sendBulkMutation.mutate(bulkMessage);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-600" />;
      default: return <MessageCircle className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'error': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const predefinedTemplates = [
    {
      name: "Welcome Message",
      content: "Hi {contact_name}! 👋 Welcome to {company_name}. We're excited to have you on board!"
    },
    {
      name: "Follow-up Reminder",
      content: "Hi {contact_name}, just following up on our previous conversation about {topic}. Are you available for a quick call?"
    },
    {
      name: "Product Demo Invite",
      content: "Hi {contact_name}! Would you like to see a personalized demo of our solution? It only takes 15 minutes and could save {company_name} significant time and resources."
    },
    {
      name: "Meeting Confirmation",
      content: "Hi {contact_name}, confirming our meeting scheduled for {meeting_time}. Looking forward to discussing how we can help {company_name}!"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Integration Status */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <MessageCircle className="h-5 w-5 mr-2" />
              WhatsApp Business Integration
            </CardTitle>
            
            {!integration?.isConnected ? (
              <Dialog open={isSetupOpen} onOpenChange={setIsSetupOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Phone className="h-4 w-4 mr-1" />
                    Setup WhatsApp
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>WhatsApp Business API Setup</DialogTitle>
                    <DialogDescription>
                      Connect your WhatsApp Business account to send automated messages
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 mt-4">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="font-medium text-blue-900 mb-2">Setup Instructions</h4>
                      <ol className="text-sm text-blue-800 space-y-1">
                        <li>1. Create a WhatsApp Business App in Meta Business</li>
                        <li>2. Generate an access token with messaging permissions</li>
                        <li>3. Configure webhook URL for message delivery status</li>
                        <li>4. Add your phone number to the WhatsApp Business account</li>
                      </ol>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Access Token</label>
                        <Input
                          type="password"
                          value={whatsappConfig.accessToken}
                          onChange={(e) => setWhatsappConfig(prev => ({
                            ...prev,
                            accessToken: e.target.value
                          }))}
                          placeholder="Enter your access token..."
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Phone Number ID</label>
                        <Input
                          value={whatsappConfig.phoneNumberId}
                          onChange={(e) => setWhatsappConfig(prev => ({
                            ...prev,
                            phoneNumberId: e.target.value
                          }))}
                          placeholder="WhatsApp phone number ID..."
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Verify Token</label>
                        <Input
                          value={whatsappConfig.verifyToken}
                          onChange={(e) => setWhatsappConfig(prev => ({
                            ...prev,
                            verifyToken: e.target.value
                          }))}
                          placeholder="Webhook verify token..."
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Business Account ID</label>
                        <Input
                          value={whatsappConfig.businessAccountId}
                          onChange={(e) => setWhatsappConfig(prev => ({
                            ...prev,
                            businessAccountId: e.target.value
                          }))}
                          placeholder="Business account ID..."
                          className="mt-1"
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button variant="outline" onClick={() => setIsSetupOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleSetup}
                        disabled={setupMutation.isPending}
                      >
                        {setupMutation.isPending ? 'Connecting...' : 'Connect WhatsApp'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            ) : (
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testConnectionMutation.mutate()}
                  disabled={testConnectionMutation.isPending}
                >
                  <Settings className="h-3 w-3 mr-1" />
                  Test Connection
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-slate-500">Loading integration status...</div>
          ) : !integration?.isConnected ? (
            <div className="text-center py-8">
              <MessageCircle className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">WhatsApp Not Connected</h3>
              <p className="text-slate-500 mb-4">Connect your WhatsApp Business account to send automated messages</p>
              <Button onClick={() => setIsSetupOpen(true)}>
                <Phone className="h-4 w-4 mr-1" />
                Setup WhatsApp Integration
              </Button>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <MessageCircle className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <div className="font-medium">WhatsApp Business Connected</div>
                    <div className="text-sm text-slate-500">Phone: {integration.phoneNumber}</div>
                  </div>
                </div>
                <Badge className={getStatusColor(integration.status)}>
                  {getStatusIcon(integration.status)}
                  <span className="ml-1 capitalize">{integration.status}</span>
                </Badge>
              </div>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-slate-900">{integration.messagesSent || 0}</div>
                  <div className="text-xs text-slate-500">Messages Sent</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{integration.messagesDelivered || 0}</div>
                  <div className="text-xs text-slate-500">Delivered</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{integration.messagesRead || 0}</div>
                  <div className="text-xs text-slate-500">Read</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{integration.messagesReplied || 0}</div>
                  <div className="text-xs text-slate-500">Replied</div>
                </div>
              </div>
              
              {/* Bulk Messaging */}
              <Dialog open={isSendingBulk} onOpenChange={setIsSendingBulk}>
                <DialogTrigger asChild>
                  <Button className="w-full">
                    <Send className="h-4 w-4 mr-1" />
                    Send Bulk WhatsApp Messages
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Send Bulk WhatsApp Messages</DialogTitle>
                    <DialogDescription>
                      Send personalized WhatsApp messages to all contacts in this campaign
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 mt-4">
                    <div>
                      <label className="text-sm font-medium">Message Template</label>
                      <Select onValueChange={(value) => {
                        const template = predefinedTemplates.find(t => t.name === value);
                        if (template) {
                          setBulkMessage(prev => ({ ...prev, message: template.content }));
                        }
                      }}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Choose a template or write custom message" />
                        </SelectTrigger>
                        <SelectContent>
                          {predefinedTemplates.map((template) => (
                            <SelectItem key={template.name} value={template.name}>
                              {template.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Message Content</label>
                      <Textarea
                        value={bulkMessage.message}
                        onChange={(e) => setBulkMessage(prev => ({ ...prev, message: e.target.value }))}
                        placeholder="Enter your WhatsApp message... Use {contact_name}, {company_name} for personalization"
                        className="mt-1 min-h-[120px]"
                      />
                      <div className="text-xs text-slate-500 mt-1">
                        Available placeholders: {'{contact_name}'}, {'{company_name}'}, {'{phone_number}'}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Media URL (Optional)</label>
                        <Input
                          value={bulkMessage.mediaUrl}
                          onChange={(e) => setBulkMessage(prev => ({ ...prev, mediaUrl: e.target.value }))}
                          placeholder="https://example.com/image.jpg"
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Schedule For (Optional)</label>
                        <Input
                          type="datetime-local"
                          value={bulkMessage.scheduledAt}
                          onChange={(e) => setBulkMessage(prev => ({ ...prev, scheduledAt: e.target.value }))}
                          className="mt-1"
                        />
                      </div>
                    </div>
                    
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <h4 className="font-medium text-yellow-900 mb-1">WhatsApp Business Policy</h4>
                      <p className="text-sm text-yellow-800">
                        Ensure compliance with WhatsApp Business Policy. Only send messages to contacts who have opted in to receive WhatsApp communications.
                      </p>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button variant="outline" onClick={() => setIsSendingBulk(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleSendBulk}
                        disabled={sendBulkMutation.isPending}
                      >
                        {sendBulkMutation.isPending ? 'Sending...' : 'Send Messages'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}