import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, Activity, Download, Calendar, Filter,
  ExternalLink, FileSpreadsheet, Eye, Clock
} from 'lucide-react';
import { 
  Select,
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { formatRelativeTime, formatDate } from '@/lib/utils';

interface TeamActivityDashboardProps {
  campaignId: number;
  currentUserId: number;
}

export function TeamActivityDashboard({ campaignId, currentUserId }: TeamActivityDashboardProps) {
  const { toast } = useToast();
  const [selectedTimeRange, setSelectedTimeRange] = useState('7d');
  const [selectedMember, setSelectedMember] = useState<string>('all');
  const [exportType, setExportType] = useState<'csv' | 'sheets'>('csv');

  // Fetch team members and their activity
  const { data: teamActivity = [], isLoading } = useQuery({
    queryKey: [`/api/team-activity/${campaignId}`, selectedTimeRange, selectedMember],
    enabled: !!campaignId
  });

  // Fetch team members list
  const { data: teamMembers = [] } = useQuery({
    queryKey: [`/api/team-members/${campaignId}`],
    enabled: !!campaignId
  });

  // Export to Google Sheets mutation
  const exportToSheetsMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/export-to-sheets', {
        campaignId,
        timeRange: selectedTimeRange,
        teamMember: selectedMember
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "Export Successful",
        description: `Team activity exported to Google Sheets: ${data.sheetsUrl}`,
        variant: "default",
      });
      
      // Open the Google Sheets URL in a new tab
      if (data.sheetsUrl) {
        window.open(data.sheetsUrl, '_blank');
      }
    },
    onError: (error) => {
      toast({
        title: "Export Failed",
        description: error.message || "Failed to export to Google Sheets",
        variant: "destructive",
      });
    }
  });

  const handleExportCSV = () => {
    if (!teamActivity || teamActivity.length === 0) {
      toast({
        title: "No Data",
        description: "No team activity data to export",
        variant: "destructive",
      });
      return;
    }

    // Create CSV data
    const csvHeader = [
      'Date', 'Team Member', 'Action', 'Contact', 'Company', 
      'Status', 'Campaign', 'Details'
    ];
    
    const csvData = teamActivity.map((activity: any) => [
      formatDate(new Date(activity.createdAt)),
      activity.userName || 'Unknown User',
      activity.action,
      activity.contactName || '-',
      activity.companyName || '-',
      activity.status,
      activity.campaignName || '-',
      activity.message
    ]);

    const csvContent = [
      csvHeader.join(','),
      ...csvData.map((row: any) => row.map((cell: any) => `"${cell}"`).join(','))
    ].join('\n');

    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `team-activity-${campaignId}-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "CSV Downloaded",
      description: "Team activity report has been downloaded",
      variant: "default",
    });
  };

  const handleExportToSheets = () => {
    exportToSheetsMutation.mutate();
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'email_sent':
        return <Activity className="h-4 w-4 text-green-600" />;
      case 'email_drafted':
        return <Eye className="h-4 w-4 text-blue-600" />;
      case 'contact_imported':
        return <Users className="h-4 w-4 text-purple-600" />;
      case 'automation_started':
        return <Clock className="h-4 w-4 text-orange-600" />;
      default:
        return <Activity className="h-4 w-4 text-slate-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge variant="default" className="bg-green-100 text-green-800">Success</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      case 'info':
        return <Badge variant="secondary">Info</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Group activities by team member
  const activitiesByMember = teamActivity.reduce((acc: any, activity: any) => {
    const memberKey = activity.userId || 'unknown';
    if (!acc[memberKey]) {
      acc[memberKey] = {
        user: activity.userName || 'Unknown User',
        activities: [],
        stats: {
          totalActions: 0,
          emailsSent: 0,
          contactsImported: 0,
          draftsCreated: 0
        }
      };
    }
    
    acc[memberKey].activities.push(activity);
    acc[memberKey].stats.totalActions++;
    
    if (activity.action === 'email_sent') acc[memberKey].stats.emailsSent++;
    if (activity.action === 'contact_imported') acc[memberKey].stats.contactsImported++;
    if (activity.action === 'email_drafted') acc[memberKey].stats.draftsCreated++;
    
    return acc;
  }, {});

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Team Activity Dashboard
          </CardTitle>
          <div className="flex space-x-2">
            <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1d">Today</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 3 months</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedMember} onValueChange={setSelectedMember}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Members</SelectItem>
                {teamMembers.map((member: any) => (
                  <SelectItem key={member.id} value={member.id.toString()}>
                    {member.fullName || member.username}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="activity">Activity Log</TabsTrigger>
            <TabsTrigger value="reports">Reports & Export</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {Object.entries(activitiesByMember).map(([userId, memberData]: [string, any]) => (
                <Card key={userId}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-sm">{memberData.user}</h4>
                      <Badge variant="outline">{memberData.stats.totalActions} actions</Badge>
                    </div>
                    <div className="space-y-1 text-xs text-slate-600">
                      <div>📧 {memberData.stats.emailsSent} emails sent</div>
                      <div>📝 {memberData.stats.draftsCreated} drafts created</div>
                      <div>👥 {memberData.stats.contactsImported} contacts imported</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="activity" className="space-y-4">
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {isLoading ? (
                <div className="text-center py-8 text-slate-500">Loading team activity...</div>
              ) : teamActivity.length === 0 ? (
                <div className="text-center py-8 text-slate-500">No team activity found</div>
              ) : (
                teamActivity.map((activity: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg bg-white">
                    <div className="flex items-center space-x-3">
                      {getActionIcon(activity.action)}
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-sm">{activity.userName || 'Unknown User'}</span>
                          {getStatusBadge(activity.status)}
                        </div>
                        <p className="text-xs text-slate-600 mt-1">{activity.message}</p>
                        {activity.contactName && (
                          <p className="text-xs text-slate-500">
                            Contact: {activity.contactName} {activity.companyName && `(${activity.companyName})`}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="text-xs text-slate-500">
                      {formatRelativeTime(new Date(activity.createdAt))}
                    </div>
                  </div>
                ))
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="reports" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3">Export Options</h4>
                  <div className="space-y-3">
                    <div>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={handleExportCSV}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download CSV Report
                      </Button>
                    </div>
                    <div>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={handleExportToSheets}
                        disabled={exportToSheetsMutation.isPending}
                      >
                        <FileSpreadsheet className="h-4 w-4 mr-2" />
                        {exportToSheetsMutation.isPending ? 'Exporting...' : 'Export to Google Sheets'}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3">Documentation</h4>
                  <div className="space-y-2 text-sm text-slate-600">
                    <p>• Team members can view who sent messages to which contacts</p>
                    <p>• Activity logs show all actions with timestamps</p>
                    <p>• Export data to Google Sheets for team collaboration</p>
                    <p>• Filter by time range and team member</p>
                    <p>• Real-time activity tracking and reporting</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}