import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { PlayCircle, StopCircle } from 'lucide-react';

interface AutomationControlsProps {
  campaignId: number;
  templateId?: number;
  onAutomationStart?: () => void;
  onAutomationStop?: () => void;
}

interface AutomationSettings {
  sendDelay: number;
  batchSize: number;
  draftOnly: boolean;
  skipDuplicates: boolean;
  updateSheet: boolean;
}

export function AutomationControls({ 
  campaignId, 
  templateId,
  onAutomationStart,
  onAutomationStop
}: AutomationControlsProps) {
  const { toast } = useToast();
  const [settings, setSettings] = useState<AutomationSettings>({
    sendDelay: 180,
    batchSize: 50,
    draftOnly: false,
    skipDuplicates: true,
    updateSheet: true
  });
  const [status, setStatus] = useState<string>("ready");

  // Fetch existing settings if available
  const { data: existingSettings, isLoading: isLoadingSettings } = useQuery({
    queryKey: [`/api/automation-settings/campaign/${campaignId}`],
    enabled: !!campaignId,
    onSuccess: (data) => {
      setSettings(data);
    }
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/automation-settings', {
        ...settings,
        campaignId
      });
    },
    onSuccess: () => {
      toast({
        title: "Settings Saved",
        description: "Automation settings have been saved successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Save Settings",
        description: error.message || "An error occurred while saving settings",
        variant: "destructive",
      });
    }
  });

  const startAutomationMutation = useMutation({
    mutationFn: async () => {
      // First save the settings
      await saveSettingsMutation.mutateAsync();
      
      // Then start the automation
      return apiRequest('POST', '/api/automation/start', {
        campaignId,
        templateId
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      setStatus("running");
      toast({
        title: "Automation Started",
        description: `Processing ${data.contactCount} contacts`,
      });
      
      if (onAutomationStart) {
        onAutomationStart();
      }
    },
    onError: (error) => {
      setStatus("failed");
      toast({
        title: "Failed to Start Automation",
        description: error.message || "An error occurred while starting automation",
        variant: "destructive",
      });
    }
  });

  const stopAutomationMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/automation/stop', {
        campaignId
      });
    },
    onSuccess: () => {
      setStatus("stopped");
      toast({
        title: "Automation Stopped",
        description: "The automation process has been stopped",
      });
      
      if (onAutomationStop) {
        onAutomationStop();
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to Stop Automation",
        description: error.message || "An error occurred while stopping automation",
        variant: "destructive",
      });
    }
  });

  const handleStartAutomation = () => {
    if (!templateId) {
      toast({
        title: "No Template Selected",
        description: "Please save a template before starting automation",
        variant: "destructive",
      });
      return;
    }
    
    startAutomationMutation.mutate();
  };

  const handleStopAutomation = () => {
    stopAutomationMutation.mutate();
  };

  const handleInputChange = (field: keyof AutomationSettings, value: any) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // When draftOnly is checked, disable send delay
  useEffect(() => {
    if (settings.draftOnly) {
      setSettings(prev => ({
        ...prev,
        sendDelay: 0
      }));
    } else if (settings.sendDelay === 0) {
      setSettings(prev => ({
        ...prev,
        sendDelay: 180
      }));
    }
  }, [settings.draftOnly]);

  return (
    <Card className="shadow">
      <div className="px-6 py-4 border-b border-slate-200">
        <h2 className="text-lg font-semibold text-slate-900">Automation Controls</h2>
        <p className="text-slate-500 text-sm">Configure and run your outreach automation</p>
      </div>
      
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Settings */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <Label htmlFor="send-delay" className="text-sm font-medium text-slate-700">
                Send Delay (seconds)
              </Label>
              <Input
                id="send-delay"
                type="number"
                value={settings.sendDelay}
                onChange={(e) => handleInputChange('sendDelay', parseInt(e.target.value))}
                min={30}
                className="mt-1"
                disabled={settings.draftOnly}
              />
              <p className="mt-1 text-xs text-slate-500">Time between each message (min: 30s)</p>
            </div>
            
            <div>
              <Label htmlFor="batch-size" className="text-sm font-medium text-slate-700">
                Batch Size
              </Label>
              <Input
                id="batch-size"
                type="number"
                value={settings.batchSize}
                onChange={(e) => handleInputChange('batchSize', parseInt(e.target.value))}
                min={1}
                max={100}
                className="mt-1"
              />
              <p className="mt-1 text-xs text-slate-500">Maximum messages per batch</p>
            </div>
          </div>
          
          {/* Options */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="draft-only" 
                checked={settings.draftOnly}
                onCheckedChange={(checked) => handleInputChange('draftOnly', checked === true)}
              />
              <Label htmlFor="draft-only" className="text-sm text-slate-700">
                Draft emails only (don't send)
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="skip-duplicates" 
                checked={settings.skipDuplicates}
                onCheckedChange={(checked) => handleInputChange('skipDuplicates', checked === true)}
              />
              <Label htmlFor="skip-duplicates" className="text-sm text-slate-700">
                Skip duplicate contacts
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="update-sheet" 
                checked={settings.updateSheet}
                onCheckedChange={(checked) => handleInputChange('updateSheet', checked === true)}
              />
              <Label htmlFor="update-sheet" className="text-sm text-slate-700">
                Update sheet with status
              </Label>
            </div>
          </div>
          
          {/* Workflow visualization */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="h-32 bg-gradient-to-r from-blue-50 to-indigo-50 p-3 flex items-center justify-center">
              <div className="w-full max-w-lg">
                <h3 className="text-sm font-medium text-slate-700 mb-2">Automation Workflow</h3>
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center">
                    <span className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">1</span>
                    <span className="ml-1">Extract Data</span>
                  </div>
                  <span className="text-slate-400">→</span>
                  <div className="flex items-center">
                    <span className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">2</span>
                    <span className="ml-1">Parse Names</span>
                  </div>
                  <span className="text-slate-400">→</span>
                  <div className="flex items-center">
                    <span className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">3</span>
                    <span className="ml-1">Create Messages</span>
                  </div>
                  <span className="text-slate-400">→</span>
                  <div className="flex items-center">
                    <span className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">4</span>
                    <span className="ml-1">Send</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Start/Stop Controls */}
          <div className="flex items-center space-x-4">
            <Button
              onClick={handleStartAutomation}
              disabled={status === "running" || startAutomationMutation.isPending}
            >
              <PlayCircle className="mr-1.5 h-4 w-4" />
              {startAutomationMutation.isPending ? "Starting..." : "Start Automation"}
            </Button>
            
            <Button
              variant="outline"
              onClick={handleStopAutomation}
              disabled={status !== "running" || stopAutomationMutation.isPending}
            >
              <StopCircle className="mr-1.5 h-4 w-4" />
              Stop
            </Button>
            
            <span className="text-sm text-slate-500">
              Status: <span className="font-medium text-slate-700">{status.charAt(0).toUpperCase() + status.slice(1)}</span>
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
