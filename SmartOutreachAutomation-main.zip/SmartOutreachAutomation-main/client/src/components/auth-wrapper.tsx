import React from 'react';
import { useFirebaseAuth } from '@/hooks/useFirebaseAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, Users, Crown, 
  CheckCircle, Mail, Zap 
} from 'lucide-react';

interface AuthWrapperProps {
  children: React.ReactNode;
}

export function AuthWrapper({ children }: AuthWrapperProps) {
  const { user, userProfile, loading, error, isAuthenticated, login } = useFirebaseAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        {/* Navigation */}
        <nav className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-2">
                <Zap className="h-8 w-8 text-blue-600" />
                <span className="text-xl font-bold text-slate-900">Smart Outreach</span>
              </div>
              <Button onClick={login} disabled={loading}>
                Sign In with Google
              </Button>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-slate-900 mb-6">
              Enterprise-Grade 
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {" "}Outreach Automation
              </span>
            </h1>
            <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
              AI-powered email automation with team collaboration, CRM integrations, 
              and hierarchical account management for growing businesses.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button size="lg" className="text-lg px-8 py-3" onClick={login}>
                <Mail className="h-5 w-5 mr-2" />
                Start Free Trial
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 py-3">
                Watch Demo
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center justify-center space-x-6 text-sm text-slate-500">
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
                Enterprise Security
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
                2FA Authentication
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
                CRM Integration
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Team Collaboration</h3>
                <p className="text-slate-600">
                  Hierarchical account system with T1 members, T2 admins, and T3 supervisors
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3">AI Optimization</h3>
                <p className="text-slate-600">
                  Smart subject line generation and content optimization for higher response rates
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Enterprise Security</h3>
                <p className="text-slate-600">
                  Firebase authentication with 2FA, audit logs, and enterprise-grade security
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Pricing Tiers */}
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-8">Choose Your Plan</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {/* T1 - Free */}
              <Card className="relative">
                <CardHeader className="text-center pb-4">
                  <div className="flex items-center justify-center mb-2">
                    <Users className="h-6 w-6 text-green-600 mr-2" />
                    <CardTitle>Member (T1)</CardTitle>
                  </div>
                  <div className="text-3xl font-bold text-green-600">Free</div>
                  <p className="text-slate-500">Perfect for individual contributors</p>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-3 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Create unlimited campaigns
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Basic analytics & reporting
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Google Sheets integration
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Email templates & automation
                    </li>
                  </ul>
                </CardContent>
              </Card>

              {/* T2 - Admin */}
              <Card className="relative border-blue-500 shadow-lg scale-105">
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500">
                  Most Popular
                </Badge>
                <CardHeader className="text-center pb-4">
                  <div className="flex items-center justify-center mb-2">
                    <Shield className="h-6 w-6 text-blue-600 mr-2" />
                    <CardTitle>Admin (T2)</CardTitle>
                  </div>
                  <div className="text-3xl font-bold text-blue-600">$49/mo</div>
                  <p className="text-slate-500">For team leaders and managers</p>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-3 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Everything in Member plan
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Manage up to 5 team members
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Advanced analytics & AI optimization
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      CRM integrations (Salesforce, HubSpot)
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Export capabilities & custom reports
                    </li>
                  </ul>
                </CardContent>
              </Card>

              {/* T3 - Supervisor */}
              <Card className="relative">
                <CardHeader className="text-center pb-4">
                  <div className="flex items-center justify-center mb-2">
                    <Crown className="h-6 w-6 text-purple-600 mr-2" />
                    <CardTitle>Supervisor (T3)</CardTitle>
                  </div>
                  <div className="text-3xl font-bold text-purple-600">$99/mo</div>
                  <p className="text-slate-500">For enterprise organizations</p>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-3 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Everything in Admin plan
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Unlimited team members
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Manage multiple admin accounts
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      White-label capabilities
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Priority support & custom integrations
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center">
            <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-4">Ready to Transform Your Outreach?</h3>
                <p className="text-lg mb-6 opacity-90">
                  Join thousands of teams using Smart Outreach to automate their sales process
                </p>
                <Button 
                  size="lg" 
                  variant="secondary" 
                  className="text-lg px-8 py-3"
                  onClick={login}
                >
                  <Mail className="h-5 w-5 mr-2" />
                  Get Started Free
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Footer */}
        <footer className="bg-white border-t py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Zap className="h-6 w-6 text-blue-600" />
              <span className="text-lg font-semibold text-slate-900">Smart Outreach</span>
            </div>
            <p className="text-slate-500">
              Enterprise-grade outreach automation platform
            </p>
          </div>
        </footer>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-pink-50">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="text-red-600 mb-4">
              <Shield className="h-12 w-12 mx-auto" />
            </div>
            <h2 className="text-xl font-semibold text-slate-900 mb-2">Authentication Error</h2>
            <p className="text-slate-600 mb-4">{error}</p>
            <Button onClick={login} variant="outline">
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}