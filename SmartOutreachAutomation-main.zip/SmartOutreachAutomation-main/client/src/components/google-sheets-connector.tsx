import React, { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation } from '@tanstack/react-query';
import { Link2, Upload, CheckCircle, TableProperties, Info, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface GoogleSheetsConnectorProps {
  campaignId: number;
  onImportSuccess: (contacts: any[]) => void;
  isConnected?: boolean;
  connectedSheetName?: string;
}

interface ColumnMapping {
  fullNameColumn: string;
  emailColumn: string;
  phoneNumberColumn?: string;
  companyNameColumn?: string;
}

interface SheetHeader {
  column: string;
  label: string;
}

export function GoogleSheetsConnector({
  campaignId,
  onImportSuccess,
  isConnected = false,
  connectedSheetName = ''
}: GoogleSheetsConnectorProps) {
  const { toast } = useToast();
  const [selectedSheet, setSelectedSheet] = useState<string>(connectedSheetName);
  const [sheetId, setSheetId] = useState<string>('');
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    fullNameColumn: 'A',
    emailColumn: 'B',
    phoneNumberColumn: 'C',
    companyNameColumn: 'D'
  });
  const [availableColumns, setAvailableColumns] = useState<string[]>(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
  const [headers, setHeaders] = useState<SheetHeader[]>([]);
  const [skipDuplicates, setSkipDuplicates] = useState<boolean>(true);
  const [columnMappingDetected, setColumnMappingDetected] = useState<boolean>(false);

  // Function to detect header names and map columns automatically
  const detectHeadersAndMap = (headers: SheetHeader[]) => {
    // These are common header patterns that might appear in spreadsheets
    const namePatterns = [/name/i, /full\s*name/i, /contact/i, /person/i];
    const emailPatterns = [/email/i, /e-mail/i, /mail/i];
    const phonePatterns = [/phone/i, /mobile/i, /cell/i, /tel/i];
    const companyPatterns = [/company/i, /organization/i, /org/i, /business/i, /employer/i];
    
    const mapping: Partial<ColumnMapping> = {};
    
    // Find the best match for each type of column
    for (const header of headers) {
      // Check for name column
      if (!mapping.fullNameColumn && namePatterns.some(pattern => pattern.test(header.label))) {
        mapping.fullNameColumn = header.column;
      }
      // Check for email column
      if (!mapping.emailColumn && emailPatterns.some(pattern => pattern.test(header.label))) {
        mapping.emailColumn = header.column;
      }
      // Check for phone column
      if (!mapping.phoneNumberColumn && phonePatterns.some(pattern => pattern.test(header.label))) {
        mapping.phoneNumberColumn = header.column;
      }
      // Check for company column
      if (!mapping.companyNameColumn && companyPatterns.some(pattern => pattern.test(header.label))) {
        mapping.companyNameColumn = header.column;
      }
    }

    // Only update if we found matches
    if (mapping.fullNameColumn || mapping.emailColumn || mapping.phoneNumberColumn || mapping.companyNameColumn) {
      setColumnMapping(prev => ({
        ...prev,
        ...mapping
      }));
      setColumnMappingDetected(true);
      return true;
    }
    
    return false;
  };

  const fetchHeadersMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/sheet-headers', {
        sheetId: sheetId || selectedSheet
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      if (data.headers && data.headers.length > 0) {
        setHeaders(data.headers);
        setAvailableColumns(data.headers.map((h: SheetHeader) => h.column));
        
        // Try to automatically map columns
        const mappingSuccess = detectHeadersAndMap(data.headers);
        
        if (mappingSuccess) {
          toast({
            title: "Headers Detected",
            description: "Column mapping has been automatically set based on the headers",
            variant: "default",
          });
        }
      }
    },
    onError: (error) => {
      toast({
        title: "Failed to Fetch Headers",
        description: error.message || "Could not retrieve headers from the sheet",
        variant: "destructive",
      });
    }
  });

  const handleConnectSheet = () => {
    // In a real implementation, this would open Google OAuth flow
    // For demo purposes, we'll simulate a successful connection
    setSelectedSheet('Outreach Contacts');
    toast({
      title: "Sheet Connected",
      description: "Successfully connected to Google Sheet",
      variant: "default",
    });
    
    // Simulate fetching headers
    setTimeout(() => {
      const mockHeaders: SheetHeader[] = [
        { column: 'A', label: 'Full Name' },
        { column: 'B', label: 'Email Address' },
        { column: 'C', label: 'Phone Number' },
        { column: 'D', label: 'Company' },
        { column: 'E', label: 'Position' },
        { column: 'F', label: 'Location' }
      ];
      
      setHeaders(mockHeaders);
      setAvailableColumns(mockHeaders.map(h => h.column));
      detectHeadersAndMap(mockHeaders);
    }, 500);
  };

  const handleUploadCSV = () => {
    // In a real implementation, this would open a file picker
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedSheet(file.name);
        toast({
          title: "CSV Uploaded",
          description: `Successfully uploaded ${file.name}`,
          variant: "default",
        });
        
        // Simulate fetching headers
        setTimeout(() => {
          const mockHeaders: SheetHeader[] = [
            { column: 'A', label: 'Full Name' },
            { column: 'B', label: 'Email Address' },
            { column: 'C', label: 'Phone Number' },
            { column: 'D', label: 'Company' },
            { column: 'E', label: 'Position' },
            { column: 'F', label: 'Location' }
          ];
          
          setHeaders(mockHeaders);
          setAvailableColumns(mockHeaders.map(h => h.column));
          detectHeadersAndMap(mockHeaders);
        }, 500);
      }
    };
    input.click();
  };

  const importMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/import/google-sheets', {
        sheetId: sheetId || selectedSheet,
        mapping: columnMapping,
        campaignId,
        skipDuplicates
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "Import Successful",
        description: `Imported ${data.count} contacts from Google Sheets${data.duplicatesSkipped ? ` (${data.duplicatesSkipped} duplicates skipped)` : ''}`,
        variant: "default",
      });
      onImportSuccess(data.contacts);
    },
    onError: (error) => {
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import contacts",
        variant: "destructive",
      });
    }
  });

  const handleColumnChange = (columnType: keyof ColumnMapping, value: string) => {
    setColumnMapping(prev => ({
      ...prev,
      [columnType]: value
    }));
  };

  const handleImportContacts = () => {
    if (!selectedSheet && !sheetId) {
      toast({
        title: "Sheet Required",
        description: "Please connect a Google Sheet or upload a CSV first",
        variant: "destructive",
      });
      return;
    }
    
    importMutation.mutate();
  };

  const getColumnLabel = (column: string): string => {
    const header = headers.find(h => h.column === column);
    return header ? `${column}: ${header.label}` : `Column ${column}`;
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-slate-900">Data Source</h2>
          {isConnected && <CheckCircle className="h-5 w-5 text-green-500" />}
        </div>
        
        <div className="mb-6">
          {selectedSheet ? (
            <div className="flex items-center p-4 bg-slate-50 rounded-lg mb-4">
              <TableProperties className="h-5 w-5 text-slate-400 mr-3" />
              <div>
                <h3 className="font-medium text-slate-700">Connected Sheet</h3>
                <p className="text-sm text-slate-500">{selectedSheet}</p>
              </div>
            </div>
          ) : (
            <div className="mb-4">
              <Label htmlFor="sheet-id">Google Sheet ID or URL (optional)</Label>
              <Input 
                id="sheet-id" 
                value={sheetId} 
                onChange={(e) => setSheetId(e.target.value)} 
                placeholder="Enter Sheet ID or paste URL"
                className="mt-1"
              />
            </div>
          )}
          
          <div className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full border-primary-600 text-primary-600 hover:bg-primary-50"
              onClick={handleConnectSheet}
            >
              <Link2 className="mr-1.5 h-4 w-4" />
              Connect Google Sheet
            </Button>
            
            <Button 
              variant="outline"
              className="w-full"
              onClick={handleUploadCSV}
            >
              <Upload className="mr-1.5 h-4 w-4" />
              Upload CSV File
            </Button>
          </div>
        </div>
        
        <Separator className="mb-4" />
        
        <div>
          {columnMappingDetected && (
            <Alert className="mb-4 bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-800">Column mapping detected</AlertTitle>
              <AlertDescription className="text-green-700">
                We've automatically mapped the columns based on the sheet headers. You can adjust if needed.
              </AlertDescription>
            </Alert>
          )}
          
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-slate-700">Column Mapping</h3>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="h-4 w-4 text-slate-400" />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs">Map your spreadsheet columns to the correct data fields. We've tried to detect them automatically.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm text-slate-600">Full Name</Label>
              <Select 
                value={columnMapping.fullNameColumn}
                onValueChange={(value) => handleColumnChange('fullNameColumn', value)}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Column" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Columns</SelectLabel>
                    {availableColumns.map(col => (
                      <SelectItem key={col} value={col}>
                        {getColumnLabel(col)}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm text-slate-600">Email</Label>
              <Select 
                value={columnMapping.emailColumn}
                onValueChange={(value) => handleColumnChange('emailColumn', value)}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Column" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Columns</SelectLabel>
                    {availableColumns.map(col => (
                      <SelectItem key={col} value={col}>
                        {getColumnLabel(col)}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm text-slate-600">Phone Number</Label>
              <Select 
                value={columnMapping.phoneNumberColumn || ''}
                onValueChange={(value) => handleColumnChange('phoneNumberColumn', value)}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Column" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Columns</SelectLabel>
                    {availableColumns.map(col => (
                      <SelectItem key={col} value={col}>
                        {getColumnLabel(col)}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm text-slate-600">Company Name</Label>
              <Select 
                value={columnMapping.companyNameColumn || ''}
                onValueChange={(value) => handleColumnChange('companyNameColumn', value)}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Column" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Columns</SelectLabel>
                    {availableColumns.map(col => (
                      <SelectItem key={col} value={col}>
                        {getColumnLabel(col)}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="mt-4 space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="skip-duplicates"
                checked={skipDuplicates}
                onCheckedChange={(checked) => setSkipDuplicates(checked === true)}
              />
              <Label htmlFor="skip-duplicates" className="text-sm text-slate-600">
                Skip duplicate emails to prevent sending multiple messages
              </Label>
            </div>
          </div>
          
          <Button 
            className="w-full mt-4" 
            onClick={handleImportContacts}
            disabled={importMutation.isPending}
          >
            {importMutation.isPending ? "Importing..." : "Import Contacts"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
