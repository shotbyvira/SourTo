import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

interface CampaignHeaderProps {
  campaignId: number;
  initialName?: string;
}

export function CampaignHeader({ campaignId, initialName = "New Campaign" }: CampaignHeaderProps) {
  const { toast } = useToast();
  const [campaignName, setCampaignName] = useState<string>(initialName);

  const updateCampaignMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('PATCH', `/api/campaigns/${campaignId}`, {
        name: campaignName
      });
    },
    onSuccess: () => {
      toast({
        title: "Campaign Updated",
        description: "Campaign name has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update campaign name",
        variant: "destructive",
      });
    }
  });

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCampaignName(e.target.value);
  };

  const handleNameBlur = () => {
    if (campaignName.trim() !== initialName && campaignName.trim() !== '') {
      updateCampaignMutation.mutate();
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">Campaign Setup</h2>
            <p className="text-slate-500">Configure your outreach campaign</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Input
              placeholder="Campaign Name"
              value={campaignName}
              onChange={handleNameChange}
              onBlur={handleNameBlur}
              className="max-w-xs"
            />
          </div>
        </div>
        
        {/* Campaign visualization */}
        <div className="mt-6 rounded-lg overflow-hidden border border-slate-200">
          <div className="h-32 bg-gradient-to-r from-primary-500/10 to-accent-500/10 flex items-center justify-center">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-slate-800">Your Outreach Campaign</h3>
              <p className="text-sm text-slate-600 mt-1">
                Create personalized messages for your contacts
              </p>
            </div>
          </div>
          <div className="bg-slate-50 px-6 py-4">
            <h3 className="font-medium text-slate-800">{campaignName}</h3>
            <p className="text-sm text-slate-600 mt-1">
              Personalized messages ready to be delivered to your contacts.
            </p>
            <div className="flex mt-3 space-x-2">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                Email
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                WhatsApp
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
