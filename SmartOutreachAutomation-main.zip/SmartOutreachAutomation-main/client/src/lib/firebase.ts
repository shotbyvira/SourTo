import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  signInWithPopup, 
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider, 
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User,
  multiFactor,
  PhoneAuthProvider,
  PhoneMultiFactorGenerator,
  getMultiFactorResolver
} from "firebase/auth";
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebasestorage.app`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Google Auth Provider
const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('email');
googleProvider.addScope('profile');

// User tiers
export enum UserTier {
  T1 = 'T1', // Member
  T2 = 'T2', // Admin  
  T3 = 'T3'  // Supervisor
}

export interface FirebaseUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  tier: UserTier;
  parentAccountId?: string; // For T1 users under T2/T3
  teamMembers?: string[];   // UIDs of team members
  maxTeamSize: number;
  createdAt: Date;
  lastLoginAt: Date;
  isActive: boolean;
  subscription: {
    plan: 'free' | 'admin' | 'supervisor' | 'enterprise';
    status: 'active' | 'inactive' | 'cancelled';
    expiresAt?: Date;
  };
  permissions: {
    canCreateCampaigns: boolean;
    canManageTeam: boolean;
    canViewAnalytics: boolean;
    canExportData: boolean;
    canIntegrateCRM: boolean;
  };
  mfaEnabled: boolean;
}

// Authentication functions
export const signInWithGoogle = async (): Promise<User | null> => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    
    // Create or update user profile in Firestore
    await createOrUpdateUserProfile(result.user);
    
    return result.user;
  } catch (error: any) {
    if (error.code === 'auth/popup-blocked') {
      // Fallback to redirect
      await signInWithRedirect(auth, googleProvider);
      return null;
    }
    throw error;
  }
};

export const handleRedirectResult = async (): Promise<User | null> => {
  try {
    const result = await getRedirectResult(auth);
    if (result?.user) {
      await createOrUpdateUserProfile(result.user);
      return result.user;
    }
    return null;
  } catch (error) {
    console.error('Redirect result error:', error);
    throw error;
  }
};

export const signOut = async (): Promise<void> => {
  await firebaseSignOut(auth);
};

// User profile management
export const createOrUpdateUserProfile = async (user: User): Promise<void> => {
  const userRef = doc(db, 'users', user.uid);
  const userSnap = await getDoc(userRef);
  
  const defaultPermissions = {
    canCreateCampaigns: true,
    canManageTeam: false,
    canViewAnalytics: true,
    canExportData: false,
    canIntegrateCRM: false
  };
  
  if (!userSnap.exists()) {
    // New user - create with T1 tier by default
    const newUser: Partial<FirebaseUser> = {
      uid: user.uid,
      email: user.email || '',
      displayName: user.displayName || '',
      photoURL: user.photoURL || '',
      tier: UserTier.T1,
      maxTeamSize: 0,
      createdAt: new Date(),
      lastLoginAt: new Date(),
      isActive: true,
      subscription: {
        plan: 'free',
        status: 'active'
      },
      permissions: defaultPermissions,
      mfaEnabled: false
    };
    
    await setDoc(userRef, {
      ...newUser,
      createdAt: serverTimestamp(),
      lastLoginAt: serverTimestamp()
    });
  } else {
    // Existing user - update last login
    await updateDoc(userRef, {
      lastLoginAt: serverTimestamp()
    });
  }
};

export const getUserProfile = async (uid: string): Promise<FirebaseUser | null> => {
  try {
    const userRef = doc(db, 'users', uid);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      const data = userSnap.data();
      return {
        ...data,
        createdAt: data.createdAt?.toDate(),
        lastLoginAt: data.lastLoginAt?.toDate()
      } as FirebaseUser;
    }
    return null;
  } catch (error) {
    console.error('Error fetching user profile:', error);
    return null;
  }
};

// Team management functions
export const upgradeUserTier = async (
  uid: string, 
  newTier: UserTier,
  maxTeamSize: number = 0
): Promise<void> => {
  const userRef = doc(db, 'users', uid);
  
  const permissions = {
    [UserTier.T1]: {
      canCreateCampaigns: true,
      canManageTeam: false,
      canViewAnalytics: true,
      canExportData: false,
      canIntegrateCRM: false
    },
    [UserTier.T2]: {
      canCreateCampaigns: true,
      canManageTeam: true,
      canViewAnalytics: true,
      canExportData: true,
      canIntegrateCRM: true
    },
    [UserTier.T3]: {
      canCreateCampaigns: true,
      canManageTeam: true,
      canViewAnalytics: true,
      canExportData: true,
      canIntegrateCRM: true
    }
  };
  
  const subscriptionPlan = {
    [UserTier.T1]: 'free',
    [UserTier.T2]: 'admin',
    [UserTier.T3]: 'supervisor'
  } as const;
  
  await updateDoc(userRef, {
    tier: newTier,
    maxTeamSize,
    permissions: permissions[newTier],
    subscription: {
      plan: subscriptionPlan[newTier],
      status: 'active'
    }
  });
};

export const addTeamMember = async (adminUid: string, memberEmail: string): Promise<void> => {
  // Find user by email
  const usersRef = collection(db, 'users');
  const q = query(usersRef, where('email', '==', memberEmail));
  const querySnapshot = await getDocs(q);
  
  if (querySnapshot.empty) {
    throw new Error('User not found with this email address');
  }
  
  const memberDoc = querySnapshot.docs[0];
  const memberUid = memberDoc.id;
  const memberData = memberDoc.data();
  
  // Check if admin has capacity
  const adminRef = doc(db, 'users', adminUid);
  const adminSnap = await getDoc(adminRef);
  const adminData = adminSnap.data();
  
  if (!adminData || adminData.tier === UserTier.T1) {
    throw new Error('Only T2/T3 users can add team members');
  }
  
  const currentTeamSize = adminData.teamMembers?.length || 0;
  if (currentTeamSize >= adminData.maxTeamSize) {
    throw new Error('Team size limit reached');
  }
  
  // Add member to admin's team
  const updatedTeamMembers = [...(adminData.teamMembers || []), memberUid];
  await updateDoc(adminRef, {
    teamMembers: updatedTeamMembers
  });
  
  // Update member's parent account
  const memberRef = doc(db, 'users', memberUid);
  await updateDoc(memberRef, {
    parentAccountId: adminUid
  });
};

// 2FA functions
export const enableMFA = async (user: User, phoneNumber: string): Promise<string> => {
  const multiFactorSession = await multiFactor(user).getSession();
  const phoneAuthCredential = PhoneAuthProvider.credential(phoneNumber, '');
  const multiFactorAssertion = PhoneMultiFactorGenerator.assertion(phoneAuthCredential);
  
  await multiFactor(user).enroll(multiFactorAssertion, multiFactorSession);
  
  // Update user profile
  const userRef = doc(db, 'users', user.uid);
  await updateDoc(userRef, {
    mfaEnabled: true
  });
  
  return 'MFA enabled successfully';
};

// Auth state observer
export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// Initialize redirect result handler
export const initializeAuth = async (): Promise<User | null> => {
  // Handle redirect result on app load
  return await handleRedirectResult();
};