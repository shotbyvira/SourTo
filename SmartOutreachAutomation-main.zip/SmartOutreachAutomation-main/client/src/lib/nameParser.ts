/**
 * Name Parser - Client-side utility for parsing full names into components
 */

export interface ParsedName {
  honorific?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
}

// Common honorifics to check for
const HONORIFICS = [
  "Mr", "Mr.", "Mrs", "Mrs.", "Ms", "Ms.", "Miss", "Dr", "Dr.",
  "Prof", "Prof.", "Sir", "Madam", "Lady", "Lord", "Rev", "Rev.",
  "Capt", "Capt.", "Major", "Col", "Col.", "Gen", "Gen."
];

export function parseName(fullName: string): ParsedName {
  if (!fullName || typeof fullName !== 'string') {
    return {};
  }

  // Trim extra whitespace and normalize multiple spaces
  const normalizedName = fullName.trim().replace(/\s+/g, ' ');
  
  // Initialize result
  const result: ParsedName = {};
  
  // Extract honorific
  const nameParts = normalizedName.split(' ');
  let startIndex = 0;
  
  // Check if the first part is an honorific
  if (nameParts.length > 0 && HONORIFICS.includes(nameParts[0])) {
    result.honorific = nameParts[0];
    startIndex = 1;
  }
  
  const remainingParts = nameParts.slice(startIndex);
  
  // If no parts left after honorific extraction, return
  if (remainingParts.length === 0) {
    return result;
  }
  
  // Extract first name
  result.firstName = remainingParts[0];
  
  // Handle different name patterns
  if (remainingParts.length === 1) {
    // Only a single name
    return result;
  } else if (remainingParts.length === 2) {
    // Likely first and last name
    result.lastName = remainingParts[1];
  } else {
    // Has middle name(s)
    result.lastName = remainingParts[remainingParts.length - 1];
    
    // Everything between first and last name is considered middle name
    const middleNames = remainingParts.slice(1, -1);
    if (middleNames.length > 0) {
      result.middleName = middleNames.join(' ');
    }
  }
  
  return result;
}

// Function to validate if a name has all required components
export function validateParsedName(parsedName: ParsedName): boolean {
  return !!(parsedName.firstName && parsedName.lastName);
}

// Function to format a name (with or without honorific)
export function formatName(parsedName: ParsedName, includeHonorific: boolean = true): string {
  const parts = [];
  
  if (includeHonorific && parsedName.honorific) {
    parts.push(parsedName.honorific);
  }
  
  if (parsedName.firstName) {
    parts.push(parsedName.firstName);
  }
  
  if (parsedName.middleName) {
    parts.push(parsedName.middleName);
  }
  
  if (parsedName.lastName) {
    parts.push(parsedName.lastName);
  }
  
  return parts.join(' ');
}

// Function to get the informal name (first name only)
export function getInformalName(parsedName: ParsedName): string {
  return parsedName.firstName || '';
}

// Function to get the formal name (honorific + last name)
export function getFormalName(parsedName: ParsedName): string {
  const parts = [];
  
  if (parsedName.honorific) {
    parts.push(parsedName.honorific);
  }
  
  if (parsedName.lastName) {
    parts.push(parsedName.lastName);
  }
  
  return parts.join(' ');
}
