/**
 * Placeholder Replacer - Client-side utility for replacing template placeholders
 */

export interface ContactInfo {
  honorific?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  companyName?: string;
  email?: string;
  phoneNumber?: string;
  [key: string]: string | undefined;
}

// Available placeholder tags that can be used in templates
export const AVAILABLE_TAGS = [
  '<Honorific>',
  '<First Name>',
  '<Middle Name>',
  '<Last Name>',
  '<Company>'
];

// Function to replace placeholders in a template with actual values
export function replacePlaceholders(template: string, contactInfo: ContactInfo): string {
  if (!template) return '';

  let result = template;

  // Replace each placeholder with its corresponding value, or empty string if undefined
  result = result.replace(/<Honorific>/g, contactInfo.honorific || '');
  result = result.replace(/<First Name>/g, contactInfo.firstName || '');
  result = result.replace(/<Middle Name>/g, contactInfo.middleName || '');
  result = result.replace(/<Last Name>/g, contactInfo.lastName || '');
  result = result.replace(/<Company>/g, contactInfo.companyName || '');

  return result;
}

// Function to identify placeholders used in a template
export function identifyPlaceholders(template: string): string[] {
  if (!template) return [];

  const usedTags: string[] = [];

  AVAILABLE_TAGS.forEach(tag => {
    if (template.includes(tag)) {
      usedTags.push(tag);
    }
  });

  return usedTags;
}

// Function to validate if a template has valid placeholders
export function validateTemplate(template: string): { 
  isValid: boolean; 
  missingFields: string[];
} {
  const usedTags = identifyPlaceholders(template);
  const requiredFields: string[] = [];

  usedTags.forEach(tag => {
    const fieldName = tag.replace(/[<>]/g, '').trim();
    requiredFields.push(fieldName);
  });

  // Return true if all required fields are available
  return {
    isValid: true, // Always true for now, since placeholders can be optional
    missingFields: [] // Track missing fields if needed for more advanced validation
  };
}

// Function to highlight template placeholders for UI display
export function highlightPlaceholders(template: string): string {
  if (!template) return '';

  let result = template;

  AVAILABLE_TAGS.forEach(tag => {
    const tagRegex = new RegExp(tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    result = result.replace(tagRegex, `<span class="placeholder-tag">${tag}</span>`);
  });

  return result;
}

// Function to insert a placeholder tag at cursor position
export function insertPlaceholderAtCursor(
  text: string, 
  cursorPosition: number, 
  placeholder: string
): { text: string; newCursorPosition: number } {
  if (cursorPosition < 0) {
    cursorPosition = 0;
  }

  const textBefore = text.substring(0, cursorPosition);
  const textAfter = text.substring(cursorPosition);
  
  // Insert the placeholder at the cursor position
  const newText = textBefore + placeholder + textAfter;
  const newCursorPosition = cursorPosition + placeholder.length;
  
  return { 
    text: newText,
    newCursorPosition
  };
}
