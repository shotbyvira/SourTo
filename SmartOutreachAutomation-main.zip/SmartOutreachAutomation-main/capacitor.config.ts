import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.smartoutreach.app',
  appName: 'Smart Outreach',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#3B82F6",
      showSpinner: true,
      spinnerColor: "#FFFFFF"
    },
    StatusBar: {
      style: "dark",
      backgroundColor: "#FFFFFF"
    },
    PushNotifications: {
      presentationOptions: ["badge", "sound", "alert"]
    },
    LocalNotifications: {
      smallIcon: "ic_notification",
      iconColor: "#3B82F6"
    },
    Camera: {
      permissions: {
        camera: "To take photos for contact profiles and media attachments"
      }
    },
    Filesystem: {
      permissions: {
        storage: "To store and access exported reports and attachments"
      }
    }
  },
  android: {
    buildOptions: {
      keystorePath: undefined,
      keystoreAlias: undefined,
      releaseType: "AAB"
    }
  }
};

export default config;
