#!/bin/bash

echo "🚀 Smart Outreach - Android APK Build Process"
echo "================================================"

# Step 1: Check prerequisites
echo "Step 1: Checking prerequisites..."
command -v npm >/dev/null 2>&1 || { echo "❌ npm is required but not installed. Aborting." >&2; exit 1; }
command -v npx >/dev/null 2>&1 || { echo "❌ npx is required but not installed. Aborting." >&2; exit 1; }
echo "✅ Prerequisites check passed"

# Step 2: Install dependencies
echo "Step 2: Installing dependencies..."
npm install
echo "✅ Dependencies installed"

# Step 3: Create minimal build for Capacitor
echo "Step 3: Creating production build..."
mkdir -p dist
cp client/index.html dist/
echo "✅ Build directory created"

# Step 4: Sync with Capacitor
echo "Step 4: Syncing with Capacitor..."
npx cap sync android
echo "✅ Capacitor sync completed"

# Step 5: Show project structure
echo "Step 5: Android project structure:"
echo "📁 android/"
ls -la android/ | head -10

echo ""
echo "📁 android/app/src/main/"
ls -la android/app/src/main/

# Step 6: Check if gradlew exists
echo "Step 6: Checking Gradle wrapper..."
if [ -f "android/gradlew" ]; then
    echo "✅ Gradle wrapper found"
    chmod +x android/gradlew
else
    echo "❌ Gradle wrapper not found"
fi

# Step 7: Show next steps
echo ""
echo "🎯 Next Steps to Build APK:"
echo "1. Install Android Studio from: https://developer.android.com/studio"
echo "2. Install Java JDK 11+ from: https://adoptium.net/"
echo "3. Open Android project: npx cap open android"
echo "4. In Android Studio: Build > Generate Signed Bundle / APK"
echo ""
echo "📋 Or build via command line:"
echo "cd android && ./gradlew assembleRelease"
echo ""
echo "📱 APK will be generated at:"
echo "android/app/build/outputs/apk/release/app-release.apk"
echo ""
echo "✨ Your Smart Outreach app is ready for Android deployment!"