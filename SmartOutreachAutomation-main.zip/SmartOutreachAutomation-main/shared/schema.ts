import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firebaseUid: text("firebase_uid").unique(),
  username: text("username").unique(),
  password: text("password"), // Optional for Firebase users
  email: text("email").notNull(),
  fullName: text("full_name"),
  photoURL: text("photo_url"),
  
  // Hierarchical system
  tier: text("tier").notNull().default("T1"), // T1, T2, T3
  parentAccountId: integer("parent_account_id"),
  maxTeamSize: integer("max_team_size").notNull().default(0),
  
  // Subscription and billing
  subscriptionPlan: text("subscription_plan").notNull().default("free"), // free, admin, supervisor, enterprise
  subscriptionStatus: text("subscription_status").notNull().default("active"),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  
  // Permissions
  canCreateCampaigns: boolean("can_create_campaigns").notNull().default(true),
  canManageTeam: boolean("can_manage_team").notNull().default(false),
  canViewAnalytics: boolean("can_view_analytics").notNull().default(true),
  canExportData: boolean("can_export_data").notNull().default(false),
  canIntegrateCRM: boolean("can_integrate_crm").notNull().default(false),
  
  // Security
  mfaEnabled: boolean("mfa_enabled").notNull().default(false),
  mfaSecret: text("mfa_secret"),
  
  // Legacy fields
  role: text("role").notNull().default("member"),
  teamId: integer("team_id"),
  isActive: boolean("is_active").notNull().default(true),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  firebaseUid: true,
  username: true,
  password: true,
  email: true,
  fullName: true,
  photoURL: true,
  tier: true,
  parentAccountId: true,
  maxTeamSize: true,
  subscriptionPlan: true,
  subscriptionStatus: true,
  canCreateCampaigns: true,
  canManageTeam: true,
  canViewAnalytics: true,
  canExportData: true,
  canIntegrateCRM: true,
  mfaEnabled: true,
  role: true,
  teamId: true,
});

// Teams table for organization
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTeamSchema = createInsertSchema(teams).pick({
  name: true,
  description: true,
});

// Campaigns table
export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCampaignSchema = createInsertSchema(campaigns).pick({
  name: true,
  userId: true,
});

// Templates table
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull(),
  subject: text("subject"),
  body: text("body").notNull(),
  type: text("type").notNull(), // email, whatsapp
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTemplateSchema = createInsertSchema(templates).pick({
  campaignId: true,
  subject: true,
  body: true,
  type: true,
});

// Contacts table
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull(),
  fullName: text("full_name").notNull(),
  honorific: text("honorific"),
  firstName: text("first_name"),
  middleName: text("middle_name"),
  lastName: text("last_name"),
  email: text("email"),
  phoneNumber: text("phone_number"),
  companyName: text("company_name"),
  status: text("status").default("pending").notNull(), // pending, sent, drafted, failed
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertContactSchema = createInsertSchema(contacts).pick({
  campaignId: true,
  fullName: true,
  honorific: true,
  firstName: true,
  middleName: true,
  lastName: true,
  email: true,
  phoneNumber: true,
  companyName: true,
  status: true,
});

// Settings for automation
export const automationSettings = pgTable("automation_settings", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull(),
  sendDelay: integer("send_delay").default(180).notNull(),
  batchSize: integer("batch_size").default(50).notNull(),
  draftOnly: boolean("draft_only").default(false).notNull(),
  skipDuplicates: boolean("skip_duplicates").default(true).notNull(),
  updateSheet: boolean("update_sheet").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAutomationSettingsSchema = createInsertSchema(automationSettings).pick({
  campaignId: true,
  sendDelay: true,
  batchSize: true,
  draftOnly: true,
  skipDuplicates: true,
  updateSheet: true,
});

// Activity logs with user tracking
export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull(),
  contactId: integer("contact_id"),
  userId: integer("user_id"), // Track which team member performed the action
  action: text("action").notNull(),
  status: text("status").notNull(), // success, error, info
  message: text("message").notNull(),
  details: json("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertLogSchema = createInsertSchema(logs).pick({
  campaignId: true,
  contactId: true,
  userId: true,
  action: true,
  status: true,
  message: true,
  details: true,
});

// Team activity reports table
export const teamReports = pgTable("team_reports", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull(),
  campaignId: integer("campaign_id").notNull(),
  generatedBy: integer("generated_by").notNull(), // userId who generated the report
  reportType: text("report_type").notNull(), // daily, weekly, monthly, custom
  reportData: json("report_data").notNull(),
  exportedToSheets: boolean("exported_to_sheets").default(false),
  sheetsUrl: text("sheets_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTeamReportSchema = createInsertSchema(teamReports).pick({
  teamId: true,
  campaignId: true,
  generatedBy: true,
  reportType: true,
  reportData: true,
  exportedToSheets: true,
  sheetsUrl: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;

export type Template = typeof templates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;

export type AutomationSetting = typeof automationSettings.$inferSelect;
export type InsertAutomationSetting = z.infer<typeof insertAutomationSettingsSchema>;

export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;

export type TeamReport = typeof teamReports.$inferSelect;
export type InsertTeamReport = z.infer<typeof insertTeamReportSchema>;

// Google Sheet data mapping schema
export const sheetMappingSchema = z.object({
  fullNameColumn: z.string(),
  emailColumn: z.string(),
  phoneNumberColumn: z.string().optional(),
  companyNameColumn: z.string().optional(),
});

export type SheetMapping = z.infer<typeof sheetMappingSchema>;

// CRM Integrations table
export const crmIntegrations = pgTable("crm_integrations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  crmType: text("crm_type").notNull(), // salesforce, hubspot, pipedrive, etc.
  crmAccountId: text("crm_account_id"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiresAt: timestamp("token_expires_at"),
  isActive: boolean("is_active").notNull().default(true),
  lastSyncAt: timestamp("last_sync_at"),
  syncSettings: json("sync_settings"), // Custom sync preferences
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCrmIntegrationSchema = createInsertSchema(crmIntegrations).pick({
  userId: true,
  crmType: true,
  crmAccountId: true,
  accessToken: true,
  refreshToken: true,
  isActive: true,
  syncSettings: true,
});

// Database connections table for multi-DB support
export const databaseConnections = pgTable("database_connections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  dbType: text("db_type").notNull(), // postgresql, mysql, mongodb, etc.
  connectionString: text("connection_string").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  lastTestedAt: timestamp("last_tested_at"),
  testStatus: text("test_status"), // success, failed
  encryptionKey: text("encryption_key"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDatabaseConnectionSchema = createInsertSchema(databaseConnections).pick({
  userId: true,
  name: true,
  dbType: true,
  connectionString: true,
  isActive: true,
});

// User sessions table for enhanced security
export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  sessionToken: text("session_token").notNull().unique(),
  firebaseToken: text("firebase_token"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  isActive: boolean("is_active").notNull().default(true),
  expiresAt: timestamp("expires_at").notNull(),
  lastActivityAt: timestamp("last_activity_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Audit logs for compliance and security
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(), // login, logout, create_campaign, etc.
  resourceType: text("resource_type"), // campaign, contact, template, etc.
  resourceId: integer("resource_id"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  metadata: json("metadata"), // Additional context
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).pick({
  userId: true,
  action: true,
  resourceType: true,
  resourceId: true,
  ipAddress: true,
  userAgent: true,
  metadata: true,
});

// Advanced reporting table
export const customReports = pgTable("custom_reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  reportConfig: json("report_config").notNull(), // Chart configs, filters, etc.
  isPublic: boolean("is_public").notNull().default(false),
  scheduledDelivery: json("scheduled_delivery"), // Email schedule config
  lastGeneratedAt: timestamp("last_generated_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCustomReportSchema = createInsertSchema(customReports).pick({
  userId: true,
  name: true,
  description: true,
  reportConfig: true,
  isPublic: true,
  scheduledDelivery: true,
});

// API usage tracking for rate limiting
export const apiUsage = pgTable("api_usage", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  endpoint: text("endpoint").notNull(),
  method: text("method").notNull(),
  requestCount: integer("request_count").notNull().default(1),
  lastRequestAt: timestamp("last_request_at").defaultNow().notNull(),
  resetAt: timestamp("reset_at").notNull(),
});

// Type exports for all new tables
export type CrmIntegration = typeof crmIntegrations.$inferSelect;
export type InsertCrmIntegration = z.infer<typeof insertCrmIntegrationSchema>;

export type DatabaseConnection = typeof databaseConnections.$inferSelect;
export type InsertDatabaseConnection = z.infer<typeof insertDatabaseConnectionSchema>;

export type UserSession = typeof userSessions.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;

export type CustomReport = typeof customReports.$inferSelect;
export type InsertCustomReport = z.infer<typeof insertCustomReportSchema>;

export type ApiUsage = typeof apiUsage.$inferSelect;
