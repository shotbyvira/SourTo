import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { GoogleSheetsService } from "./services/googleSheetsService";
import { EmailService } from "./services/emailService";
import { parseName } from "./services/nameParserService";
import {
  insertCampaignSchema,
  insertTemplateSchema,
  insertAutomationSettingsSchema,
  sheetMappingSchema,
  type Contact
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create a new campaign
  app.post("/api/campaigns", async (req: Request, res: Response) => {
    try {
      const validation = insertCampaignSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid campaign data", details: validation.error });
      }
      
      const campaign = await storage.createCampaign(validation.data);
      return res.status(201).json(campaign);
    } catch (error) {
      console.error("Error creating campaign:", error);
      return res.status(500).json({ message: "Failed to create campaign" });
    }
  });

  // Get campaigns by user ID
  app.get("/api/campaigns/user/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const campaigns = await storage.getCampaignsByUserId(userId);
      return res.json(campaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      return res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  // Get a campaign by ID
  app.get("/api/campaigns/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      const campaign = await storage.getCampaignById(id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      return res.json(campaign);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      return res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  // Update campaign name
  app.patch("/api/campaigns/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      const { name } = req.body;
      if (!name || typeof name !== "string") {
        return res.status(400).json({ message: "Name is required" });
      }
      
      const updatedCampaign = await storage.updateCampaignName(id, name);
      if (!updatedCampaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      return res.json(updatedCampaign);
    } catch (error) {
      console.error("Error updating campaign:", error);
      return res.status(500).json({ message: "Failed to update campaign" });
    }
  });

  // Create a template
  app.post("/api/templates", async (req: Request, res: Response) => {
    try {
      const validation = insertTemplateSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid template data", details: validation.error });
      }
      
      const template = await storage.createTemplate(validation.data);
      return res.status(201).json(template);
    } catch (error) {
      console.error("Error creating template:", error);
      return res.status(500).json({ message: "Failed to create template" });
    }
  });

  // Get templates by campaign ID
  app.get("/api/templates/campaign/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      const templates = await storage.getTemplatesByCampaignId(campaignId);
      return res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      return res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  // Update a template
  app.patch("/api/templates/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid template ID" });
      }
      
      const { subject, body, type } = req.body;
      if ((!subject && !body && !type) || 
          (subject && typeof subject !== "string") || 
          (body && typeof body !== "string") || 
          (type && typeof type !== "string")) {
        return res.status(400).json({ message: "Invalid update data" });
      }
      
      const updateData: Partial<any> = {};
      if (subject) updateData.subject = subject;
      if (body) updateData.body = body;
      if (type) updateData.type = type;
      
      const updatedTemplate = await storage.updateTemplate(id, updateData);
      if (!updatedTemplate) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      return res.json(updatedTemplate);
    } catch (error) {
      console.error("Error updating template:", error);
      return res.status(500).json({ message: "Failed to update template" });
    }
  });

  // Parse a name
  app.post("/api/name-parser", (req: Request, res: Response) => {
    try {
      const { fullName } = req.body;
      if (!fullName || typeof fullName !== "string") {
        return res.status(400).json({ message: "Full name is required" });
      }
      
      const parsedName = parseName(fullName);
      return res.json(parsedName);
    } catch (error) {
      console.error("Error parsing name:", error);
      return res.status(500).json({ message: "Failed to parse name" });
    }
  });

  // Get sheet headers for automatic column mapping
  app.post("/api/sheet-headers", async (req: Request, res: Response) => {
    try {
      const { sheetId } = req.body;
      
      if (!sheetId || typeof sheetId !== "string") {
        return res.status(400).json({ message: "Sheet ID is required" });
      }
      
      // In a real implementation, this would fetch the headers from the Google Sheets API
      // For demo purposes, we're returning mock headers
      const mockHeaders = [
        { column: 'A', label: 'Full Name' },
        { column: 'B', label: 'Email Address' },
        { column: 'C', label: 'Phone Number' },
        { column: 'D', label: 'Company' },
        { column: 'E', label: 'Position' },
        { column: 'F', label: 'Location' }
      ];
      
      return res.status(200).json({
        headers: mockHeaders
      });
    } catch (error) {
      console.error("Error fetching headers:", error);
      return res.status(500).json({ message: "Failed to fetch sheet headers" });
    }
  });

  // Import contacts from Google Sheets (simulated)
  app.post("/api/import/google-sheets", async (req: Request, res: Response) => {
    try {
      const { sheetId, mapping, campaignId, skipDuplicates = true } = req.body;
      
      // Validate required fields
      if (!sheetId || typeof sheetId !== "string") {
        return res.status(400).json({ message: "Sheet ID is required" });
      }
      
      if (!campaignId || isNaN(parseInt(campaignId))) {
        return res.status(400).json({ message: "Campaign ID is required" });
      }
      
      // Validate mapping
      const mappingValidation = sheetMappingSchema.safeParse(mapping);
      if (!mappingValidation.success) {
        return res.status(400).json({ 
          error: "Invalid column mapping", 
          details: mappingValidation.error 
        });
      }
      
      console.log(`Fetching sheet data for sheetId: ${sheetId} with mapping:`, mapping);
      
      // Fetch data from sheets (simulated)
      const rawData = await GoogleSheetsService.fetchSheetData(sheetId, mappingValidation.data);
      
      // Process contacts
      const contacts = GoogleSheetsService.processContacts(rawData, parseInt(campaignId));
      
      let savedContacts = [];
      let duplicatesSkipped = 0;
      
      // Check for duplicates if skipDuplicates is true
      if (skipDuplicates) {
        // Get existing contacts for this campaign
        const existingContacts = await storage.getContactsByCampaignId(parseInt(campaignId));
        
        // Extract existing emails for quick lookup
        const existingEmails = new Set(
          existingContacts
            .filter(c => c.email)
            .map(c => c.email?.toLowerCase())
        );
        
        // Filter out contacts with duplicate emails
        const filteredContacts = contacts.filter(contact => {
          if (!contact.email || existingEmails.has(contact.email.toLowerCase())) {
            duplicatesSkipped++;
            return false;
          }
          return true;
        });
        
        // Store filtered contacts
        savedContacts = await storage.bulkCreateContacts(filteredContacts);
      } else {
        // Store all contacts if not checking for duplicates
        savedContacts = await storage.bulkCreateContacts(contacts);
      }
      
      // Create a log for this import
      await storage.createLog({
        campaignId: parseInt(campaignId),
        action: "import_contacts",
        status: "success",
        message: `Imported ${savedContacts.length} contacts from Google Sheets${duplicatesSkipped > 0 ? ` (${duplicatesSkipped} duplicates skipped)` : ''}`,
        details: { 
          count: savedContacts.length,
          duplicatesSkipped
        }
      });
      
      return res.status(201).json({ 
        message: "Contacts imported successfully", 
        count: savedContacts.length,
        duplicatesSkipped,
        contacts: savedContacts
      });
    } catch (error) {
      console.error("Error importing contacts:", error);
      return res.status(500).json({ message: "Failed to import contacts" });
    }
  });

  // Get contacts by campaign ID
  app.get("/api/contacts/campaign/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      const contacts = await storage.getContactsByCampaignId(campaignId);
      return res.json(contacts);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      return res.status(500).json({ message: "Failed to fetch contacts" });
    }
  });

  // Get contact stats by campaign ID
  app.get("/api/stats/campaign/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      const stats = await storage.getContactStatsByCampaignId(campaignId);
      return res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      return res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Get recent logs by campaign ID
  app.get("/api/logs/campaign/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      const logs = await storage.getRecentLogsByCampaignId(campaignId, limit);
      return res.json(logs);
    } catch (error) {
      console.error("Error fetching logs:", error);
      return res.status(500).json({ message: "Failed to fetch logs" });
    }
  });

  // Create or update automation settings
  app.post("/api/automation-settings", async (req: Request, res: Response) => {
    try {
      const validation = insertAutomationSettingsSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid settings data", details: validation.error });
      }
      
      // Check if settings already exist for this campaign
      const existingSettings = await storage.getAutomationSettingsByCampaignId(validation.data.campaignId);
      
      let settings;
      if (existingSettings) {
        // Update existing settings
        settings = await storage.updateAutomationSettings(existingSettings.id, validation.data);
      } else {
        // Create new settings
        settings = await storage.createAutomationSettings(validation.data);
      }
      
      return res.status(201).json(settings);
    } catch (error) {
      console.error("Error saving automation settings:", error);
      return res.status(500).json({ message: "Failed to save automation settings" });
    }
  });

  // Get automation settings by campaign ID
  app.get("/api/automation-settings/campaign/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      const settings = await storage.getAutomationSettingsByCampaignId(campaignId);
      if (!settings) {
        // Return default settings if none exist
        return res.json({
          campaignId,
          sendDelay: 180,
          batchSize: 50,
          draftOnly: false,
          skipDuplicates: true,
          updateSheet: true
        });
      }
      
      return res.json(settings);
    } catch (error) {
      console.error("Error fetching automation settings:", error);
      return res.status(500).json({ message: "Failed to fetch automation settings" });
    }
  });

  // Send verified emails that were previously drafted
  app.post("/api/automation/send-verified", async (req: Request, res: Response) => {
    try {
      const { campaignId, templateId } = req.body;
      
      if (!campaignId || isNaN(parseInt(campaignId))) {
        return res.status(400).json({ message: "Campaign ID is required" });
      }
      
      if (!templateId || isNaN(parseInt(templateId))) {
        return res.status(400).json({ message: "Template ID is required" });
      }
      
      // Get the campaign, template, and drafted contacts
      const campaign = await storage.getCampaignById(parseInt(campaignId));
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      const template = await storage.getTemplateById(parseInt(templateId));
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      // Only get contacts that have been drafted but not sent
      const contacts = await storage.getContactsByCampaignId(parseInt(campaignId));
      const draftedContacts = contacts.filter(c => c.status === 'drafted');
      
      if (draftedContacts.length === 0) {
        return res.status(400).json({ message: "No drafted contacts found to send" });
      }
      
      // Get automation settings
      const settings = await storage.getAutomationSettingsByCampaignId(parseInt(campaignId));
      if (!settings) {
        return res.status(400).json({ message: "Automation settings not found" });
      }
      
      // Create a log for starting the send
      await storage.createLog({
        campaignId: parseInt(campaignId),
        action: "sending_verified_started",
        status: "success",
        message: `Started sending verified emails to ${draftedContacts.length} contacts`,
        details: { 
          contactCount: draftedContacts.length,
          templateId
        }
      });
      
      // Send initial response (we'll process the sending in the background)
      res.status(200).json({ 
        message: "Sending verified emails", 
        contactCount: draftedContacts.length 
      });
      
      // Process sending in the background
      sendVerifiedEmails(
        parseInt(campaignId),
        draftedContacts,
        template,
        settings
      ).catch(error => {
        console.error("Error sending verified emails:", error);
      });
      
    } catch (error) {
      console.error("Error starting verified email send:", error);
      return res.status(500).json({ message: "Failed to start sending verified emails" });
    }
  });

  // Start automation process
  app.post("/api/automation/start", async (req: Request, res: Response) => {
    try {
      const { campaignId, templateId } = req.body;
      
      if (!campaignId || isNaN(parseInt(campaignId))) {
        return res.status(400).json({ message: "Campaign ID is required" });
      }
      
      if (!templateId || isNaN(parseInt(templateId))) {
        return res.status(400).json({ message: "Template ID is required" });
      }
      
      // Get campaign, template, contacts, and settings
      const campaign = await storage.getCampaignById(parseInt(campaignId));
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      const template = await storage.getTemplateById(parseInt(templateId));
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      const contacts = await storage.getContactsByCampaignId(parseInt(campaignId));
      if (contacts.length === 0) {
        return res.status(400).json({ message: "No contacts found for this campaign" });
      }
      
      const settings = await storage.getAutomationSettingsByCampaignId(parseInt(campaignId));
      if (!settings) {
        return res.status(400).json({ message: "Automation settings not found" });
      }
      
      // Start a separate process to handle automation
      // In a real implementation, this would be a separate worker process or queue
      // For simplicity, we'll just send a response and continue processing
      
      // Create a log for starting automation
      await storage.createLog({
        campaignId: parseInt(campaignId),
        action: "automation_started",
        status: "success",
        message: `Started automation for ${contacts.length} contacts`,
        details: { 
          contactCount: contacts.length,
          templateId
        }
      });
      
      // Respond with initial status
      res.status(200).json({ 
        message: "Automation started", 
        contactCount: contacts.length 
      });
      
      // Continue processing in the background
      processAutomation(
        parseInt(campaignId), 
        contacts, 
        template, 
        settings
      ).catch(error => {
        console.error("Error in automation process:", error);
      });
      
    } catch (error) {
      console.error("Error starting automation:", error);
      return res.status(500).json({ message: "Failed to start automation" });
    }
  });

  // Get team activity for a campaign
  app.get("/api/team-activity/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      const timeRange = req.query.timeRange as string || '7d';
      const teamMember = req.query.teamMember as string || 'all';
      
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      // Calculate date range
      const now = new Date();
      const days = timeRange === '1d' ? 1 : timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const startDate = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
      
      // For now, return mock team activity data
      const mockTeamActivity = [
        {
          id: 1,
          campaignId,
          userId: 1,
          userName: "Alice Johnson",
          action: "email_sent",
          status: "success",
          message: "Sent email to John Doe",
          contactName: "John Doe",
          companyName: "TechCorp Inc",
          campaignName: "Q3 Lead Generation",
          createdAt: new Date(now.getTime() - (2 * 60 * 60 * 1000)) // 2 hours ago
        },
        {
          id: 2,
          campaignId,
          userId: 2,
          userName: "Bob Smith",
          action: "email_drafted",
          status: "success",
          message: "Drafted email to Jane Smith",
          contactName: "Jane Smith",
          companyName: "StartupXYZ",
          campaignName: "Q3 Lead Generation",
          createdAt: new Date(now.getTime() - (4 * 60 * 60 * 1000)) // 4 hours ago
        },
        {
          id: 3,
          campaignId,
          userId: 1,
          userName: "Alice Johnson",
          action: "contact_imported",
          status: "success",
          message: "Imported 25 contacts from Google Sheets",
          contactName: null,
          companyName: null,
          campaignName: "Q3 Lead Generation",
          createdAt: new Date(now.getTime() - (1 * 24 * 60 * 60 * 1000)) // 1 day ago
        }
      ];
      
      // Filter by team member if specified
      let filteredActivity = mockTeamActivity;
      if (teamMember !== 'all') {
        filteredActivity = mockTeamActivity.filter(activity => 
          activity.userId.toString() === teamMember
        );
      }
      
      return res.json(filteredActivity);
    } catch (error) {
      console.error("Error fetching team activity:", error);
      return res.status(500).json({ message: "Failed to fetch team activity" });
    }
  });

  // Get team members for a campaign
  app.get("/api/team-members/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      // For now, return mock team members
      const mockTeamMembers = [
        {
          id: 1,
          username: "alice.johnson",
          fullName: "Alice Johnson",
          email: "alice@company.com",
          role: "manager",
          isActive: true
        },
        {
          id: 2,
          username: "bob.smith",
          fullName: "Bob Smith",
          email: "bob@company.com",
          role: "member",
          isActive: true
        }
      ];
      
      return res.json(mockTeamMembers);
    } catch (error) {
      console.error("Error fetching team members:", error);
      return res.status(500).json({ message: "Failed to fetch team members" });
    }
  });

  // Export team activity to Google Sheets
  app.post("/api/export-to-sheets", async (req: Request, res: Response) => {
    try {
      const { campaignId, timeRange = '7d', teamMember = 'all' } = req.body;
      
      if (!campaignId || isNaN(parseInt(campaignId))) {
        return res.status(400).json({ message: "Campaign ID is required" });
      }
      
      // In a real implementation, this would:
      // 1. Fetch the actual team activity data
      // 2. Create a new Google Sheet or update an existing one
      // 3. Use Google Sheets API to populate the data
      // 4. Return the sheet URL
      
      // For demo purposes, we'll simulate the process
      const mockSheetUrl = `https://docs.google.com/spreadsheets/d/mock-sheet-id-${campaignId}/edit`;
      
      // Simulate creating the export
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate API delay
      
      // Create a log entry for the export
      await storage.createLog({
        campaignId: parseInt(campaignId),
        userId: 1, // In real implementation, get from authenticated user
        action: "team_report_exported",
        status: "success",
        message: `Team activity report exported to Google Sheets`,
        details: { 
          sheetsUrl: mockSheetUrl,
          timeRange,
          teamMember,
          exportedAt: new Date().toISOString()
        }
      });
      
      return res.status(200).json({
        message: "Successfully exported to Google Sheets",
        sheetsUrl: mockSheetUrl,
        exportedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error exporting to Google Sheets:", error);
      return res.status(500).json({ message: "Failed to export to Google Sheets" });
    }
  });

  // AI optimization endpoint
  app.post("/api/ai-optimize", async (req: Request, res: Response) => {
    try {
      const { campaignId, optimizationType, currentTemplate } = req.body;
      
      if (!campaignId || !optimizationType) {
        return res.status(400).json({ message: "Campaign ID and optimization type are required" });
      }
      
      // Simulate AI optimization processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const optimizations = {
        'subject-lines': [
          { text: "Increase revenue by 40% with our solution", score: 92, reason: "Direct benefit + specific metric" },
          { text: "Quick question about [Company]'s growth", score: 87, reason: "Personal + curiosity gap" },
          { text: "[First Name], 5 min to transform your workflow?", score: 85, reason: "Personalized + time-bound" }
        ],
        'content-optimization': [
          { improvement: "Add social proof", impact: "25% higher response rate", example: "Join 500+ companies like [Similar Company]" },
          { improvement: "Include specific value proposition", impact: "40% more meetings booked", example: "Save 10 hours per week on manual processes" }
        ]
      };
      
      return res.status(200).json({
        optimizationType,
        suggestions: optimizations[optimizationType] || [],
        message: "AI optimization completed successfully"
      });
    } catch (error) {
      console.error("Error in AI optimization:", error);
      return res.status(500).json({ message: "Failed to generate AI optimizations" });
    }
  });

  // Analytics endpoint
  app.get("/api/analytics/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      const timeRange = req.query.timeRange as string || '7d';
      
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      // Mock analytics data
      const mockAnalytics = {
        openRate: "26.8%",
        responseRate: "12.1%",
        clickRate: "5.2%",
        bounceRate: "2.1%",
        totalContacts: 347,
        emailsSent: 298,
        responses: 38,
        meetingsBooked: 12
      };
      
      return res.json(mockAnalytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      return res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Follow-up sequences endpoints
  app.get("/api/follow-up-sequences/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }
      
      // Mock follow-up sequences
      const mockSequences = [
        {
          id: 1,
          delay: 3,
          subject: "Following up on our conversation about [Company]",
          body: "Hi [First Name],\n\nI hope this email finds you well. I wanted to follow up on my previous message...",
          isActive: true
        },
        {
          id: 2,
          delay: 7,
          subject: "Thought this might interest you, [First Name]",
          body: "Hi [First Name],\n\nI came across this article about trends in your industry...",
          isActive: true
        }
      ];
      
      return res.json(mockSequences);
    } catch (error) {
      console.error("Error fetching follow-up sequences:", error);
      return res.status(500).json({ message: "Failed to fetch follow-up sequences" });
    }
  });

  app.post("/api/follow-up-sequences", async (req: Request, res: Response) => {
    try {
      const { campaignId, delay, subject, body, isActive } = req.body;
      
      if (!campaignId || !delay || !subject || !body) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Simulate creating follow-up sequence
      const newSequence = {
        id: Date.now(),
        campaignId: parseInt(campaignId),
        delay,
        subject,
        body,
        isActive: isActive !== false
      };
      
      return res.status(201).json(newSequence);
    } catch (error) {
      console.error("Error creating follow-up sequence:", error);
      return res.status(500).json({ message: "Failed to create follow-up sequence" });
    }
  });

  app.patch("/api/follow-up-sequences/:id/toggle", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid sequence ID" });
      }
      
      return res.status(200).json({ message: "Sequence toggled successfully" });
    } catch (error) {
      console.error("Error toggling sequence:", error);
      return res.status(500).json({ message: "Failed to toggle sequence" });
    }
  });

  // WhatsApp Business API endpoints
  app.get("/api/whatsapp-integration/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      
      // Mock WhatsApp integration status
      const integration = {
        isConnected: true,
        phoneNumber: "+1 (555) 123-4567",
        status: "connected",
        messagesSent: 127,
        messagesDelivered: 119,
        messagesRead: 89,
        messagesReplied: 23
      };
      
      return res.json(integration);
    } catch (error) {
      console.error("Error fetching WhatsApp integration:", error);
      return res.status(500).json({ message: "Failed to fetch WhatsApp integration" });
    }
  });

  app.post("/api/whatsapp-integration/setup", async (req: Request, res: Response) => {
    try {
      const { campaignId, accessToken, phoneNumberId } = req.body;
      
      // Mock setup process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return res.json({ 
        success: true, 
        message: "WhatsApp Business API connected successfully" 
      });
    } catch (error) {
      console.error("Error setting up WhatsApp:", error);
      return res.status(500).json({ message: "Failed to setup WhatsApp integration" });
    }
  });

  app.post("/api/whatsapp/send-bulk", async (req: Request, res: Response) => {
    try {
      const { campaignId, message, mediaUrl, scheduledAt } = req.body;
      
      // Mock bulk sending
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      return res.json({ 
        success: true, 
        sentCount: 47,
        message: "Bulk WhatsApp messages sent successfully" 
      });
    } catch (error) {
      console.error("Error sending bulk WhatsApp messages:", error);
      return res.status(500).json({ message: "Failed to send WhatsApp messages" });
    }
  });

  // Scheduling system endpoints
  app.get("/api/scheduled-messages/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      
      // Mock scheduled messages
      const scheduledMessages = [
        {
          id: 1,
          contactId: 1,
          contactName: "John Smith",
          contactEmail: "john@example.com",
          subject: "Follow-up on our conversation",
          message: "Hi John, following up on our discussion about improving your workflow...",
          messageType: "email",
          scheduledAt: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
          status: "scheduled",
          priority: "high",
          recurrence: { type: "none", interval: 1 }
        },
        {
          id: 2,
          contactId: 2,
          contactName: "Sarah Johnson",
          contactEmail: "sarah@company.com",
          subject: "",
          message: "Hi Sarah! Hope you're having a great week. Quick question about your automation needs...",
          messageType: "whatsapp",
          scheduledAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
          status: "scheduled",
          priority: "medium",
          recurrence: { type: "weekly", interval: 1 }
        }
      ];
      
      return res.json(scheduledMessages);
    } catch (error) {
      console.error("Error fetching scheduled messages:", error);
      return res.status(500).json({ message: "Failed to fetch scheduled messages" });
    }
  });

  app.post("/api/scheduled-messages", async (req: Request, res: Response) => {
    try {
      const { campaignId, contactId, subject, message, messageType, scheduledAt, priority, recurrence } = req.body;
      
      const newSchedule = {
        id: Date.now(),
        campaignId: parseInt(campaignId),
        contactId: parseInt(contactId),
        contactName: "New Contact",
        contactEmail: "contact@example.com",
        subject,
        message,
        messageType,
        scheduledAt,
        status: "scheduled",
        priority,
        recurrence
      };
      
      return res.status(201).json(newSchedule);
    } catch (error) {
      console.error("Error creating scheduled message:", error);
      return res.status(500).json({ message: "Failed to create scheduled message" });
    }
  });

  app.patch("/api/scheduled-messages/:id/cancel", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      return res.json({ 
        success: true, 
        message: "Scheduled message cancelled successfully" 
      });
    } catch (error) {
      console.error("Error cancelling scheduled message:", error);
      return res.status(500).json({ message: "Failed to cancel scheduled message" });
    }
  });

  // Calendar events endpoints
  app.get("/api/calendar-events/:campaignId", async (req: Request, res: Response) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      
      // Mock calendar events
      const events = [
        {
          id: 1,
          type: "email",
          title: "Follow-up Email to John Smith",
          contactName: "John Smith",
          contactId: 1,
          scheduledAt: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
          status: "scheduled",
          priority: "high",
          description: "Follow-up on demo discussion",
          duration: 30
        },
        {
          id: 2,
          type: "whatsapp",
          title: "WhatsApp Check-in",
          contactName: "Sarah Johnson",
          contactId: 2,
          scheduledAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
          status: "scheduled",
          priority: "medium",
          description: "Weekly check-in message",
          duration: 15
        },
        {
          id: 3,
          type: "meeting",
          title: "Product Demo",
          contactName: "Mike Wilson",
          contactId: 3,
          scheduledAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
          status: "scheduled",
          priority: "high",
          description: "30-minute product demonstration",
          duration: 30
        }
      ];
      
      return res.json(events);
    } catch (error) {
      console.error("Error fetching calendar events:", error);
      return res.status(500).json({ message: "Failed to fetch calendar events" });
    }
  });

  // CRM integration endpoints
  app.get("/api/crm-integrations/:userId", async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      
      const integrations = [
        {
          id: 1,
          crmType: "salesforce",
          status: "connected",
          lastSyncAt: new Date().toISOString(),
          syncedContacts: 1247,
          syncedLeads: 89,
          syncedOpportunities: 23
        }
      ];
      
      return res.json(integrations);
    } catch (error) {
      console.error("Error fetching CRM integrations:", error);
      return res.status(500).json({ message: "Failed to fetch CRM integrations" });
    }
  });

  app.post("/api/crm-integrations", async (req: Request, res: Response) => {
    try {
      const { crmType, apiKey, domain } = req.body;
      
      // Mock CRM connection process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return res.json({ 
        success: true, 
        message: `${crmType} CRM connected successfully` 
      });
    } catch (error) {
      console.error("Error connecting CRM:", error);
      return res.status(500).json({ message: "Failed to connect CRM" });
    }
  });

  app.post("/api/crm-integrations/:id/sync", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      // Mock sync process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      return res.json({ 
        success: true, 
        message: "CRM sync completed successfully" 
      });
    } catch (error) {
      console.error("Error syncing CRM:", error);
      return res.status(500).json({ message: "Failed to sync CRM" });
    }
  });

  // Account management endpoints
  app.get("/api/team-members/:userId", async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      
      const teamMembers = [
        {
          id: 1,
          fullName: "Alice Johnson",
          email: "alice@company.com",
          tier: "T2",
          isActive: true,
          lastLoginAt: new Date().toISOString()
        },
        {
          id: 2,
          fullName: "Bob Smith",
          email: "bob@company.com", 
          tier: "T1",
          isActive: true,
          lastLoginAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
        }
      ];
      
      return res.json(teamMembers);
    } catch (error) {
      console.error("Error fetching team members:", error);
      return res.status(500).json({ message: "Failed to fetch team members" });
    }
  });

  app.post("/api/account/upgrade", async (req: Request, res: Response) => {
    try {
      const { targetTier, billingInfo } = req.body;
      
      // Mock upgrade process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return res.json({ 
        success: true, 
        message: `Account upgraded to ${targetTier} successfully` 
      });
    } catch (error) {
      console.error("Error upgrading account:", error);
      return res.status(500).json({ message: "Failed to upgrade account" });
    }
  });

  app.post("/api/team/add-member", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      
      return res.json({ 
        success: true, 
        message: `Invitation sent to ${email}` 
      });
    } catch (error) {
      console.error("Error adding team member:", error);
      return res.status(500).json({ message: "Failed to add team member" });
    }
  });

  app.post("/api/team/promote", async (req: Request, res: Response) => {
    try {
      const { userId, newTier } = req.body;
      
      return res.json({ 
        success: true, 
        message: `User promoted to ${newTier} successfully` 
      });
    } catch (error) {
      console.error("Error promoting user:", error);
      return res.status(500).json({ message: "Failed to promote user" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}

// Function to send verified emails that were previously drafted
async function sendVerifiedEmails(
  campaignId: number,
  contacts: Contact[],
  template: any,
  settings: any
) {
  console.log(`Sending verified emails to ${contacts.length} contacts with ${settings.sendDelay}s delay`);
  
  let sentCount = 0;
  let failedCount = 0;
  
  for (const contact of contacts) {
    try {
      // Only process contacts that are in 'drafted' status
      if (contact.status !== 'drafted') {
        continue;
      }
      
      // Create personalized email
      const personalizedEmail = EmailService.createPersonalizedEmail(
        { subject: template.subject, body: template.body },
        contact
      );
      
      // Send the email
      const result = await EmailService.sendEmail(contact, personalizedEmail);
      
      if (result.success) {
        await storage.updateContactStatus(contact.id, 'sent');
        sentCount++;
        
        await storage.createLog({
          campaignId,
          contactId: contact.id,
          action: "email_sent",
          status: "success",
          message: `Sent verified email to ${contact.fullName}`,
          details: { messageId: result.messageId }
        });
      } else {
        await storage.updateContactStatus(contact.id, 'failed');
        failedCount++;
        
        await storage.createLog({
          campaignId,
          contactId: contact.id,
          action: "email_send_failed",
          status: "error",
          message: `Failed to send verified email to ${contact.fullName}: ${result.error}`,
          details: { error: result.error }
        });
      }
      
      // Add delay between sends to avoid rate limiting
      if (settings.sendDelay > 0) {
        await new Promise(resolve => setTimeout(resolve, settings.sendDelay * 1000));
      }
    } catch (error) {
      console.error(`Error sending email to contact ${contact.id}:`, error);
      failedCount++;
      
      await storage.updateContactStatus(contact.id, 'failed');
      
      await storage.createLog({
        campaignId,
        contactId: contact.id,
        action: "email_send_failed",
        status: "error",
        message: `Error sending email to ${contact.fullName}: ${error.message}`,
        details: { error: error.message }
      });
    }
  }
  
  // Create final log for completion
  await storage.createLog({
    campaignId,
    action: "sending_verified_completed",
    status: "success",
    message: `Completed sending ${sentCount} verified emails (${failedCount} failed)`,
    details: { 
      sentCount,
      failedCount,
      totalProcessed: contacts.length
    }
  });
  
  return { sentCount, failedCount };
}

// Helper function to process automation in the background
async function processAutomation(
  campaignId: number, 
  contacts: Contact[], 
  template: any, 
  settings: any
) {
  // Process contacts in sequence with delay between each
  const pendingContacts = contacts.filter(c => c.status === 'pending');
  
  console.log(`Starting automation for ${pendingContacts.length} contacts with ${settings.sendDelay}s delay`);
  
  // Always draft emails first to enable human verification
  const requiresHumanVerification = true;
  
  for (const contact of pendingContacts) {
    try {
      // Skip contacts that are already processed if skipDuplicates is enabled
      if (settings.skipDuplicates && contact.status !== 'pending') {
        await storage.createLog({
          campaignId,
          contactId: contact.id,
          action: "contact_skipped",
          status: "info",
          message: `Skipped ${contact.fullName} (already processed)`,
          details: { reason: "duplicate" }
        });
        continue;
      }
      
      // Create personalized email
      const personalizedEmail = EmailService.createPersonalizedEmail(
        { subject: template.subject, body: template.body },
        contact
      );
      
      // First, create a draft for all emails (this is for human verification)
      const draftResult = await EmailService.draftEmail(contact, personalizedEmail);
      
      if (draftResult.success) {
        await storage.updateContactStatus(contact.id, 'drafted');
        
        await storage.createLog({
          campaignId,
          contactId: contact.id,
          action: "email_drafted",
          status: "success",
          message: `Drafted email to ${contact.fullName}`,
          details: { 
            messageId: draftResult.messageId,
            previewSubject: personalizedEmail.subject,
            previewBody: personalizedEmail.body.substring(0, 100) + '...'
          }
        });
      } else {
        await storage.updateContactStatus(contact.id, 'failed');
        
        await storage.createLog({
          campaignId,
          contactId: contact.id,
          action: "email_draft_failed",
          status: "error",
          message: `Failed to draft email to ${contact.fullName}: ${draftResult.error}`,
          details: { error: draftResult.error }
        });
        continue; // Skip to next contact if drafting fails
      }
      
      // Only send immediately if not requiring human verification and draftOnly is false
      if (!requiresHumanVerification && !settings.draftOnly) {
        // Send email directly
        const sendResult = await EmailService.sendEmail(contact, personalizedEmail);
        
        if (sendResult.success) {
          await storage.updateContactStatus(contact.id, 'sent');
          
          await storage.createLog({
            campaignId,
            contactId: contact.id,
            action: "email_sent",
            status: "success",
            message: `Sent email to ${contact.fullName}`,
            details: { messageId: sendResult.messageId }
          });
        } else {
          await storage.updateContactStatus(contact.id, 'failed');
          
          await storage.createLog({
            campaignId,
            contactId: contact.id,
            action: "email_send_failed",
            status: "error",
            message: `Failed to send email to ${contact.fullName}: ${sendResult.error}`,
            details: { error: sendResult.error }
          });
        }
      }
      
      // Wait for the specified delay before next contact
      await new Promise(resolve => setTimeout(resolve, settings.sendDelay * 1000));
      
    } catch (error) {
      console.error(`Error processing contact ${contact.id}:`, error);
      
      await storage.updateContactStatus(contact.id, 'failed');
      
      await storage.createLog({
        campaignId,
        contactId: contact.id,
        action: "process_failed",
        status: "error",
        message: `Error processing ${contact.fullName}: ${error}`,
        details: { error: String(error) }
      });
    }
  }
  
  // Create a log for completed automation
  await storage.createLog({
    campaignId,
    action: "automation_completed",
    status: "success",
    message: `Completed automation for ${pendingContacts.length} contacts`,
    details: { contactCount: pendingContacts.length }
  });
  
  console.log(`Automation completed for campaign ${campaignId}`);
}
