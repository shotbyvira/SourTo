import { db } from './db';
import { eq, desc } from 'drizzle-orm';
import {
  users, type User, type InsertUser,
  campaigns, type Campaign, type InsertCampaign,
  templates, type Template, type InsertTemplate,
  contacts, type Contact, type InsertContact,
  automationSettings, type AutomationSetting, type InsertAutomationSetting,
  logs, type Log, type InsertLog
} from "@shared/schema";
import { IStorage } from './storage';

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Campaign operations
  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db.insert(campaigns).values(campaign).returning();
    return newCampaign;
  }

  async getCampaignById(id: number): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign;
  }

  async getCampaignsByUserId(userId: number): Promise<Campaign[]> {
    return await db.select().from(campaigns).where(eq(campaigns.userId, userId));
  }

  async updateCampaignName(id: number, name: string): Promise<Campaign | undefined> {
    const [updatedCampaign] = await db
      .update(campaigns)
      .set({ name })
      .where(eq(campaigns.id, id))
      .returning();
    return updatedCampaign;
  }

  // Template operations
  async createTemplate(template: InsertTemplate): Promise<Template> {
    const [newTemplate] = await db.insert(templates).values(template).returning();
    return newTemplate;
  }

  async getTemplateById(id: number): Promise<Template | undefined> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    return template;
  }

  async getTemplatesByCampaignId(campaignId: number): Promise<Template[]> {
    return await db.select().from(templates).where(eq(templates.campaignId, campaignId));
  }

  async updateTemplate(id: number, templateUpdate: Partial<InsertTemplate>): Promise<Template | undefined> {
    const [updatedTemplate] = await db
      .update(templates)
      .set(templateUpdate)
      .where(eq(templates.id, id))
      .returning();
    return updatedTemplate;
  }

  // Contact operations
  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db.insert(contacts).values(contact).returning();
    return newContact;
  }

  async getContactById(id: number): Promise<Contact | undefined> {
    const [contact] = await db.select().from(contacts).where(eq(contacts.id, id));
    return contact;
  }

  async getContactsByCampaignId(campaignId: number): Promise<Contact[]> {
    return await db.select().from(contacts).where(eq(contacts.campaignId, campaignId));
  }

  async updateContactStatus(id: number, status: string): Promise<Contact | undefined> {
    const [updatedContact] = await db
      .update(contacts)
      .set({ status })
      .where(eq(contacts.id, id))
      .returning();
    return updatedContact;
  }

  async updateContactParsedInfo(id: number, info: Pick<Contact, 'honorific' | 'firstName' | 'middleName' | 'lastName'>): Promise<Contact | undefined> {
    const [updatedContact] = await db
      .update(contacts)
      .set(info)
      .where(eq(contacts.id, id))
      .returning();
    return updatedContact;
  }

  async bulkCreateContacts(contactsToCreate: InsertContact[]): Promise<Contact[]> {
    if (contactsToCreate.length === 0) return [];
    return await db.insert(contacts).values(contactsToCreate).returning();
  }

  // Automation settings operations
  async createAutomationSettings(settings: InsertAutomationSetting): Promise<AutomationSetting> {
    const [newSettings] = await db
      .insert(automationSettings)
      .values(settings)
      .returning();
    return newSettings;
  }

  async getAutomationSettingsByCampaignId(campaignId: number): Promise<AutomationSetting | undefined> {
    const [settings] = await db
      .select()
      .from(automationSettings)
      .where(eq(automationSettings.campaignId, campaignId));
    return settings;
  }

  async updateAutomationSettings(id: number, settingsUpdate: Partial<InsertAutomationSetting>): Promise<AutomationSetting | undefined> {
    const [updatedSettings] = await db
      .update(automationSettings)
      .set(settingsUpdate)
      .where(eq(automationSettings.id, id))
      .returning();
    return updatedSettings;
  }

  // Logs operations
  async createLog(log: InsertLog): Promise<Log> {
    const [newLog] = await db.insert(logs).values(log).returning();
    return newLog;
  }

  async getLogsByCampaignId(campaignId: number): Promise<Log[]> {
    return await db
      .select()
      .from(logs)
      .where(eq(logs.campaignId, campaignId))
      .orderBy(desc(logs.createdAt));
  }

  async getRecentLogsByCampaignId(campaignId: number, limit: number): Promise<Log[]> {
    return await db
      .select()
      .from(logs)
      .where(eq(logs.campaignId, campaignId))
      .orderBy(desc(logs.createdAt))
      .limit(limit);
  }

  // Stats operations
  async getContactStatsByCampaignId(campaignId: number): Promise<{
    total: number;
    sent: number;
    drafted: number;
    failed: number;
    pending: number;
  }> {
    const allContacts = await this.getContactsByCampaignId(campaignId);
    
    return {
      total: allContacts.length,
      sent: allContacts.filter(contact => contact.status === 'sent').length,
      drafted: allContacts.filter(contact => contact.status === 'drafted').length,
      failed: allContacts.filter(contact => contact.status === 'failed').length,
      pending: allContacts.filter(contact => contact.status === 'pending').length,
    };
  }
}