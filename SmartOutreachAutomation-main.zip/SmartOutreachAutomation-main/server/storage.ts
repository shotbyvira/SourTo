import {
  users, type User, type InsertUser,
  campaigns, type Campaign, type InsertCampaign,
  templates, type Template, type InsertTemplate,
  contacts, type Contact, type InsertContact,
  automationSettings, type AutomationSetting, type InsertAutomationSetting,
  logs, type Log, type InsertLog
} from "@shared/schema";
import { DatabaseStorage } from "./databaseStorage";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Campaign operations
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  getCampaignById(id: number): Promise<Campaign | undefined>;
  getCampaignsByUserId(userId: number): Promise<Campaign[]>;
  updateCampaignName(id: number, name: string): Promise<Campaign | undefined>;

  // Template operations
  createTemplate(template: InsertTemplate): Promise<Template>;
  getTemplateById(id: number): Promise<Template | undefined>;
  getTemplatesByCampaignId(campaignId: number): Promise<Template[]>;
  updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template | undefined>;

  // Contact operations
  createContact(contact: InsertContact): Promise<Contact>;
  getContactById(id: number): Promise<Contact | undefined>;
  getContactsByCampaignId(campaignId: number): Promise<Contact[]>;
  updateContactStatus(id: number, status: string): Promise<Contact | undefined>;
  updateContactParsedInfo(id: number, info: Pick<Contact, 'honorific' | 'firstName' | 'middleName' | 'lastName'>): Promise<Contact | undefined>;
  bulkCreateContacts(contacts: InsertContact[]): Promise<Contact[]>;

  // Automation settings operations
  createAutomationSettings(settings: InsertAutomationSetting): Promise<AutomationSetting>;
  getAutomationSettingsByCampaignId(campaignId: number): Promise<AutomationSetting | undefined>;
  updateAutomationSettings(id: number, settings: Partial<InsertAutomationSetting>): Promise<AutomationSetting | undefined>;

  // Logs operations
  createLog(log: InsertLog): Promise<Log>;
  getLogsByCampaignId(campaignId: number): Promise<Log[]>;
  getRecentLogsByCampaignId(campaignId: number, limit: number): Promise<Log[]>;

  // Stats operations
  getContactStatsByCampaignId(campaignId: number): Promise<{
    total: number;
    sent: number;
    drafted: number;
    failed: number;
    pending: number;
  }>;
}

// Create a test user on startup
async function createInitialUser() {
  try {
    const existingUser = await storage.getUserByUsername("test@example.com");
    if (!existingUser) {
      await storage.createUser({
        username: "test@example.com",
        password: "password"
      });
      console.log("Created initial test user");
    }
  } catch (error) {
    console.error("Error creating initial user:", error);
  }
}

// Export the database storage instance
export const storage = new DatabaseStorage();

// Initialize with test user
createInitialUser().catch(console.error);
