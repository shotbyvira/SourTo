# Smart Outreach - Complete APK Build Walkthrough

## Step-by-Step Android APK Building Process

### Prerequisites Setup

#### 1. Install Java Development Kit (JDK)
```bash
# Download and install JDK 11 or higher
# Windows: Download from Oracle or use chocolatey
choco install openjdk11

# macOS: Use Homebrew
brew install openjdk@11

# Linux: Use package manager
sudo apt install openjdk-11-jdk
```

#### 2. Install Android Studio
- Download from: https://developer.android.com/studio
- Install with default settings
- Launch and complete the setup wizard
- This automatically installs Android SDK and build tools

#### 3. Set Environment Variables
```bash
# Add to your shell profile (.bashrc, .zshrc, etc.)
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### Project Preparation

#### 4. Build the Web Application
```bash
# In your project root directory
npm install
npm run build

# This creates the 'dist' folder with your web assets
```

#### 5. Sync Capacitor Project
```bash
# Sync web assets to Android project
npx cap sync android

# This copies your dist folder to android/app/src/main/assets/public
```

### Android Studio Build Process

#### 6. Open Project in Android Studio
```bash
# This opens Android Studio with your project
npx cap open android
```

#### 7. Configure Build Settings
In Android Studio:

**a. Set up Gradle sync:**
- Wait for "Gradle sync" to complete (bottom status bar)
- If prompted, accept license agreements

**b. Configure app signing:**
- Go to `Build > Generate Signed Bundle / APK`
- Choose "APK" for direct installation or "Android App Bundle" for Play Store
- Create or select a keystore file

**c. Build variants:**
- In Build Variants panel (View > Tool Windows > Build Variants)
- Select "release" for production APK

#### 8. Generate Keystore (First Time Only)
```bash
# Create a keystore for signing your APK
keytool -genkey -v -keystore my-release-key.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias

# You'll be prompted for:
# - Keystore password
# - Key alias password  
# - Your name and organization details
```

#### 9. Build the APK
**Option A: Through Android Studio GUI**
1. Click `Build > Generate Signed Bundle / APK`
2. Select "APK"
3. Choose your keystore file
4. Enter keystore and key passwords
5. Select "release" build type
6. Check "V1 (Jar Signature)" and "V2 (Full APK Signature)"
7. Click "Finish"

**Option B: Command Line Build**
```bash
cd android
./gradlew assembleRelease

# APK will be generated at:
# android/app/build/outputs/apk/release/app-release.apk
```

### Testing and Installation

#### 10. Install APK on Device
```bash
# Connect Android device via USB with USB debugging enabled
adb install android/app/build/outputs/apk/release/app-release.apk

# Or drag and drop APK file to device
```

#### 11. Test on Emulator
```bash
# Create and start Android emulator
npx cap run android

# This builds and installs on emulator automatically
```

### Build Optimization

#### 12. Optimize APK Size
In `android/app/build.gradle`:
```gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

#### 13. Configure App Icons and Splash Screen
```bash
# Generate app icons
npx capacitor-assets generate

# Or manually place icons in:
# android/app/src/main/res/mipmap-*/ic_launcher.png
```

### Troubleshooting Common Issues

#### Build Failures
```bash
# Clean and rebuild
cd android
./gradlew clean
./gradlew assembleRelease
```

#### Permission Issues
Add to `android/app/src/main/AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

#### Network Security
Add to `android/app/src/main/res/xml/network_security_config.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="true">localhost</domain>
    </domain-config>
</network-security-config>
```

### Production Deployment

#### 14. Play Store Upload
1. Create Google Play Console account
2. Create new app listing
3. Upload Android App Bundle (.aab file)
4. Complete store listing with screenshots and descriptions
5. Submit for review

#### 15. Enterprise Distribution
```bash
# For internal distribution, share APK file directly
# Or use Mobile Device Management (MDM) systems
# Or enterprise app stores like Samsung Knox
```

### Automated Build Script

#### 16. Create Build Script
```bash
#!/bin/bash
# build-apk.sh

echo "Building Smart Outreach APK..."

# Build web assets
npm run build

# Sync with Capacitor
npx cap sync android

# Build APK
cd android
./gradlew assembleRelease

echo "APK built successfully!"
echo "Location: android/app/build/outputs/apk/release/app-release.apk"
```

Make executable and run:
```bash
chmod +x build-apk.sh
./build-apk.sh
```

## Build Output

Your final APK will be located at:
```
android/app/build/outputs/apk/release/app-release.apk
```

File size: Approximately 15-25 MB
Compatible with: Android 7.0+ (API level 24+)
Architecture: Universal (ARM, ARM64, x86)

## Next Steps After Building

1. **Test thoroughly** on multiple devices and Android versions
2. **Submit to Play Store** or distribute internally
3. **Set up CI/CD** for automated builds
4. **Monitor crash reports** with Firebase Crashlytics
5. **Plan updates** and version management strategy

Your Smart Outreach platform is now ready for mobile deployment with all enterprise features intact!