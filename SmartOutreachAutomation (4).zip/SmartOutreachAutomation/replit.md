# Smart Outreach Automation Tool

## Project Overview
A comprehensive Smart Outreach Automation Tool that integrates with Google Sheets to personalize and schedule emails with advanced name parsing capabilities, team collaboration features, and robust activity tracking.

## Recent Changes (January 2025)
- ✅ Implemented automatic column mapping for Google Sheets imports
- ✅ Added duplicate contact checking and prevention system
- ✅ Created human verification layer separating email drafting from sending
- ✅ Built message preview functionality with full email review
- ✅ Added export report features with CSV and Google Sheets integration
- ✅ Implemented team activity dashboard with user tracking
- ✅ Enhanced database schema with team management and audit logging
- ✅ Created comprehensive documentation and team collaboration features
- ✅ **NEW: AI-Powered Optimization Hub** with smart subject line generation and performance analytics
- ✅ **NEW: Advanced Analytics Dashboard** with real-time metrics and sentiment tracking
- ✅ **NEW: Automated Follow-up Sequences** with multi-step campaigns and smart templates
- ✅ **NEW: Firebase Authentication** with Google OAuth and enterprise security
- ✅ **NEW: Hierarchical Account System** (T1/T2/T3 user tiers with team management)
- ✅ **NEW: CRM Integration Platform** for Salesforce, HubSpot, Pipedrive, Zoho, Monday.com
- ✅ **NEW: WhatsApp Business API Integration** with bulk messaging and status tracking
- ✅ **NEW: Custom Scheduling System** with timezone support and recurring messages
- ✅ **NEW: Interactive Calendar View** with month/week/day views and event management
- ✅ **NEW: Animated Progress Components** with real-time status updates and smooth animations
- ✅ **NEW: Android APK Conversion** using Capacitor with native mobile features
- 🚧 **IN PROGRESS: Multi-Database Support** and advanced reporting capabilities

## User Preferences
- Focus on building production-ready features with real-world applicability
- Prioritize user experience and ease of use for non-technical team members
- Implement comprehensive documentation and team collaboration features
- Maintain separation between drafting and sending emails for human oversight

## Project Architecture

### Backend (Node.js + Express + PostgreSQL)
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Local authentication with session management
- **API Routes**: RESTful endpoints for all operations
- **Services**: Modular services for email, Google Sheets, and name parsing

### Frontend (React + TypeScript + Vite)
- **UI Framework**: shadcn/ui components with Tailwind CSS
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation

### Database Schema
```sql
-- Core Tables
users (id, username, password, email, fullName, role, teamId, isActive, lastLoginAt, createdAt)
teams (id, name, description, createdAt)
campaigns (id, name, userId, createdAt)
templates (id, campaignId, subject, body, type, createdAt)
contacts (id, campaignId, fullName, email, phoneNumber, companyName, honorific, firstName, middleName, lastName, status, createdAt)
automation_settings (id, campaignId, sendDelay, batchSize, draftOnly, skipDuplicates, updateSheet, createdAt)
logs (id, campaignId, contactId, userId, action, status, message, details, createdAt)
team_reports (id, teamId, campaignId, generatedBy, reportType, reportData, exportedToSheets, sheetsUrl, createdAt)
```

## Core Features

### 1. Google Sheets Integration
- **Automatic Column Mapping**: Intelligent detection of column headers (Name, Email, Phone, Company)
- **Duplicate Prevention**: Prevents importing contacts with existing email addresses
- **Real-time Import**: Live feedback during contact import process
- **Export Capabilities**: Export campaign results back to Google Sheets

### 2. Contact Management
- **Smart Name Parsing**: Automatic parsing of full names into components (honorific, first, middle, last)
- **Contact Validation**: Email and phone number validation
- **Status Tracking**: Pending, drafted, sent, failed status management
- **Bulk Operations**: Import and process multiple contacts simultaneously

### 3. Template System
- **Dynamic Placeholders**: Support for personalized tags (<First Name>, <Company>, etc.)
- **Template Editor**: Rich text editor with placeholder insertion
- **Preview System**: Real-time preview of personalized messages
- **Multiple Types**: Support for email and WhatsApp templates

### 4. Automation Engine
- **Human Verification Layer**: All emails are drafted first, requiring manual approval
- **Batch Processing**: Configurable batch sizes and delays between sends
- **Error Handling**: Comprehensive error tracking and retry mechanisms
- **Progress Tracking**: Real-time automation progress monitoring

### 5. Team Collaboration
- **User Management**: Role-based access (admin, manager, member)
- **Activity Tracking**: Complete audit log of all team member actions
- **Team Dashboard**: Overview of team performance and activity
- **Report Generation**: Automated reports with export capabilities

### 6. Reporting & Analytics
- **Campaign Statistics**: Total contacts, sent emails, draft counts, failure rates
- **Team Performance**: Individual and team-wide performance metrics
- **Export Options**: CSV downloads and Google Sheets integration
- **Activity Logs**: Detailed timeline of all campaign activities

## API Endpoints

### Campaign Management
- `POST /api/campaigns` - Create new campaign
- `GET /api/campaigns/user/:userId` - Get user campaigns
- `GET /api/campaigns/:id` - Get campaign details
- `PATCH /api/campaigns/:id` - Update campaign

### Contact Management
- `POST /api/import/google-sheets` - Import contacts from Google Sheets
- `GET /api/contacts/campaign/:campaignId` - Get campaign contacts
- `POST /api/name-parser` - Parse full names

### Template Management
- `POST /api/templates` - Create template
- `GET /api/templates/campaign/:campaignId` - Get campaign templates
- `PATCH /api/templates/:id` - Update template

### Automation
- `POST /api/automation/start` - Start automation (drafting phase)
- `POST /api/automation/send-verified` - Send verified drafts
- `GET /api/automation-settings/campaign/:campaignId` - Get settings

### Team & Reporting
- `GET /api/team-activity/:campaignId` - Get team activity
- `GET /api/team-members/:campaignId` - Get team members
- `POST /api/export-to-sheets` - Export to Google Sheets

### Analytics
- `GET /api/stats/campaign/:campaignId` - Get campaign statistics
- `GET /api/logs/campaign/:campaignId` - Get activity logs

## Component Architecture

### Main Components
- **Dashboard**: Central hub for campaign management
- **CampaignHeader**: Campaign name and basic information
- **GoogleSheetsConnector**: Import contacts with automatic mapping
- **ContactPreview**: Display imported contacts
- **TemplateEditor**: Create and edit message templates
- **AutomationControls**: Start and manage automation
- **MessagePreview**: Review drafted messages before sending
- **TeamActivityDashboard**: Track team member activities
- **ProgressTracking**: Monitor campaign progress
- **AutomationStats**: Display campaign statistics

### Utility Libraries
- **nameParser**: Parse full names into components
- **placeholderReplacer**: Replace template placeholders with contact data
- **queryClient**: Handle API requests and caching

## Security Features
- Session-based authentication
- Role-based access control
- SQL injection prevention with Drizzle ORM
- Input validation with Zod schemas
- CSRF protection
- Rate limiting for API endpoints

## Android APK Features

### **Mobile-Native Capabilities**
- **Capacitor Framework**: Web-to-native conversion with native API access
- **Mobile Navigation**: Responsive hamburger menu and bottom tab navigation
- **Touch Optimization**: Large tap targets and gesture-friendly interface
- **Offline Support**: Local storage and sync capabilities
- **Push Notifications**: Real-time campaign updates and reminders
- **Camera Integration**: Profile photo capture and media attachments
- **File System Access**: Export reports and manage attachments

### **Build Configuration**
- **App ID**: com.smartoutreach.app
- **Platform**: Android 7.0+ (API 24+)
- **Architecture**: ARM64-v8a, ARMv7, x86_64
- **Bundle Type**: Android App Bundle (AAB) for Play Store
- **Security**: HTTPS enforcement, certificate pinning, biometric authentication

### **Deployment Options**
- **Direct APK**: Install via file transfer
- **Google Play Store**: Enterprise distribution
- **MDM Systems**: Corporate deployment
- **Build Commands**: `npx cap sync && npx cap open android`

## Future Enhancements
- iOS app conversion using Capacitor
- Advanced offline synchronization
- Biometric authentication integration
- Voice-to-text message composition
- Advanced push notification scheduling
- Integration with native contacts and calendar
- Augmented reality business card scanning
- Machine learning for optimal engagement timing

## Development Guidelines
- Follow TypeScript best practices
- Use Drizzle ORM for all database operations
- Implement comprehensive error handling
- Maintain separation of concerns
- Write descriptive commit messages
- Test all API endpoints thoroughly
- Follow accessibility guidelines for UI components

## Deployment Notes
- Requires PostgreSQL database
- Environment variables needed: DATABASE_URL, SESSION_SECRET
- Google Sheets API credentials required for full functionality
- Node.js 18+ recommended
- Production deployment supports auto-scaling

## Technical Decisions
- **Database**: PostgreSQL chosen for robust relational data management
- **ORM**: Drizzle for type-safe database operations
- **Authentication**: Session-based for simplicity and security
- **State Management**: TanStack Query for efficient server state management
- **UI Library**: shadcn/ui for consistent, accessible components
- **Styling**: Tailwind CSS for rapid development and customization

## Documentation
This application provides comprehensive team documentation features:
- Team members can sign in and view their activity history
- Complete audit trail of who sent messages to which contacts
- Export functionality to share reports with team and stakeholders
- Real-time activity tracking and collaboration features
- Role-based permissions for different team access levels