import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

// Components
import { CampaignHeader } from '@/components/campaign-header';
import { GoogleSheetsConnector } from '@/components/google-sheets-connector';
import { ContactPreview } from '@/components/contact-preview';
import { AutomationStats } from '@/components/automation-stats';
import { TemplateEditor } from '@/components/template-editor';
import { AutomationControls } from '@/components/automation-controls';
import { ProgressTracking } from '@/components/progress-tracking';
import { MessagePreview } from '@/components/message-preview';
import { TeamActivityDashboard } from '@/components/team-activity-dashboard';
import { AIOptimizationPanel } from '@/components/ai-optimization-panel';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';
import { FollowUpSequences } from '@/components/follow-up-sequences';
import { WhatsAppIntegration } from '@/components/whatsapp-integration';
import { SchedulingSystem } from '@/components/scheduling-system';
import { CalendarView } from '@/components/calendar-view';
import { CampaignProgress } from '@/components/animated-progress';

export default function Dashboard() {
  const { toast } = useToast();
  const [activeTemplateId, setActiveTemplateId] = useState<number | undefined>(undefined);
  const [importedContacts, setImportedContacts] = useState<any[]>([]);
  
  // Create or get a campaign for the current user
  // For now we'll use a hardcoded userId of 1
  const createCampaignMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/campaigns', {
        name: 'Q3 Lead Generation',
        userId: 1
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "Campaign Created",
        description: "Your campaign has been created successfully."
      });
      // Refetch campaigns after creation
      await campaignsQuery.refetch();
    },
    onError: (error) => {
      toast({
        title: "Campaign Creation Failed",
        description: error.message || "Failed to create campaign",
        variant: "destructive"
      });
    }
  });

  // Fetch campaigns for the current user
  const campaignsQuery = useQuery({
    queryKey: ['/api/campaigns/user/1'],
  });

  // Handle importing contacts
  const handleImportSuccess = (contacts: any[]) => {
    setImportedContacts(contacts);
    // Update the preview
    if (activeCampaign?.id) {
      // Force a refetch of the contacts
      queryClient.invalidateQueries({ queryKey: [`/api/contacts/campaign/${activeCampaign.id}`] });
    }
  };

  // Save template and set as active
  const handleTemplateSave = (templateId: number) => {
    setActiveTemplateId(templateId);
  };

  // Create a campaign if none exists
  useEffect(() => {
    if (!campaignsQuery.isLoading && Array.isArray(campaignsQuery.data) && campaignsQuery.data.length === 0) {
      createCampaignMutation.mutate();
    }
  }, [campaignsQuery.isLoading, campaignsQuery.data]);

  // Get the active campaign
  const activeCampaign = Array.isArray(campaignsQuery.data) && campaignsQuery.data.length > 0 
    ? campaignsQuery.data[0] 
    : null;

  // Fetch templates for the active campaign
  const templatesQuery = useQuery({
    queryKey: [`/api/templates/campaign/${activeCampaign?.id}`],
    enabled: !!activeCampaign?.id,
  });

  // Get the initial template if any
  useEffect(() => {
    if (templatesQuery.data && Array.isArray(templatesQuery.data) && templatesQuery.data.length > 0) {
      setActiveTemplateId(templatesQuery.data[0].id);
    }
  }, [templatesQuery.data]);

  // Handle automation events
  const handleAutomationStart = () => {
    if (activeCampaign?.id) {
      // Invalidate stats and logs to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/stats/campaign/${activeCampaign.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/logs/campaign/${activeCampaign.id}`] });
    }
  };

  // If campaigns are still loading or no campaign exists yet, show loading state
  if (campaignsQuery.isLoading || !activeCampaign) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h1 className="text-2xl font-semibold text-slate-900 mb-4">Setting up your dashboard...</h1>
        <p className="text-slate-500 mb-8">We're getting everything ready for you.</p>
        <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="md:flex md:space-x-8">
      {/* Left column (Google Sheets Integration) */}
      <div className="md:w-1/3 space-y-6">
        <GoogleSheetsConnector 
          campaignId={activeCampaign.id}
          onImportSuccess={handleImportSuccess}
          isConnected={importedContacts.length > 0}
          connectedSheetName={importedContacts.length > 0 ? "Outreach Contacts" : ""}
        />
        
        <ContactPreview 
          campaignId={activeCampaign.id}
        />
        
        <AutomationStats 
          campaignId={activeCampaign.id}
        />
      </div>
      
      {/* Right column (Template Creation & Automation Controls) */}
      <div className="md:w-2/3 space-y-6 mt-6 md:mt-0">
        <CampaignHeader 
          campaignId={activeCampaign.id}
          initialName={activeCampaign.name}
        />
        
        <TemplateEditor 
          campaignId={activeCampaign.id}
          initialTemplate={
            Array.isArray(templatesQuery.data) && templatesQuery.data.length > 0
              ? templatesQuery.data[0]
              : undefined
          }
          onSave={handleTemplateSave}
        />
        
        <AutomationControls 
          campaignId={activeCampaign.id}
          templateId={activeTemplateId}
          onAutomationStart={handleAutomationStart}
        />
        
        <MessagePreview
          campaignId={activeCampaign.id}
          templateId={activeTemplateId}
        />
        
        <ProgressTracking 
          campaignId={activeCampaign.id}
        />
        
        <AIOptimizationPanel
          campaignId={activeCampaign.id}
          currentTemplate={
            Array.isArray(templatesQuery.data) && templatesQuery.data.length > 0
              ? templatesQuery.data[0]
              : undefined
          }
        />
        
        <FollowUpSequences
          campaignId={activeCampaign.id}
        />
        
        <AnalyticsDashboard
          campaignId={activeCampaign.id}
        />
        
        <WhatsAppIntegration
          campaignId={activeCampaign.id}
        />
        
        <SchedulingSystem
          campaignId={activeCampaign.id}
        />
        
        <CalendarView
          campaignId={activeCampaign.id}
        />
        
        <TeamActivityDashboard
          campaignId={activeCampaign.id}
          currentUserId={1}
        />
      </div>
    </div>
  );
}
