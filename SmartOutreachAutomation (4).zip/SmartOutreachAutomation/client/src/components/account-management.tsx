import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Users, Crown, Shield, Star, 
  UserPlus, Settings, CreditCard,
  ArrowUp, Mail, Phone, Check
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useFirebaseAuth } from '@/hooks/useFirebaseAuth';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { UserTier } from '@/lib/firebase';

export function AccountManagement() {
  const { userProfile, hasPermission, isTier } = useFirebaseAuth();
  const { toast } = useToast();
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [newMemberEmail, setNewMemberEmail] = useState('');

  // Fetch team members
  const { data: teamMembers = [], isLoading } = useQuery({
    queryKey: ['/api/team-members', userProfile?.uid],
    enabled: !!userProfile?.uid && hasPermission('canManageTeam')
  });

  // Upgrade account mutation
  const upgradeAccountMutation = useMutation({
    mutationFn: async (newTier: UserTier) => {
      return apiRequest('POST', '/api/account/upgrade', {
        targetTier: newTier,
        billingInfo: { plan: newTier === UserTier.T2 ? 'admin' : 'supervisor' }
      });
    },
    onSuccess: () => {
      toast({
        title: "Account Upgraded",
        description: "Your account has been successfully upgraded",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/team-members'] });
      setIsUpgrading(false);
    },
    onError: (error) => {
      toast({
        title: "Upgrade Failed",
        description: error.message || "Failed to upgrade account",
        variant: "destructive",
      });
    }
  });

  // Add team member mutation
  const addMemberMutation = useMutation({
    mutationFn: async (email: string) => {
      return apiRequest('POST', '/api/team/add-member', { email });
    },
    onSuccess: () => {
      toast({
        title: "Team Member Added",
        description: "New team member has been successfully added",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/team-members'] });
      setNewMemberEmail('');
    },
    onError: (error) => {
      toast({
        title: "Failed to Add Member",
        description: error.message || "Failed to add team member",
        variant: "destructive",
      });
    }
  });

  // Promote user mutation
  const promoteUserMutation = useMutation({
    mutationFn: async ({ userId, newTier }: { userId: string, newTier: UserTier }) => {
      return apiRequest('POST', '/api/team/promote', { userId, newTier });
    },
    onSuccess: () => {
      toast({
        title: "User Promoted",
        description: "User has been successfully promoted",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/team-members'] });
    }
  });

  const getTierIcon = (tier: UserTier) => {
    switch (tier) {
      case UserTier.T3: return <Crown className="h-4 w-4 text-purple-600" />;
      case UserTier.T2: return <Shield className="h-4 w-4 text-blue-600" />;
      default: return <Users className="h-4 w-4 text-green-600" />;
    }
  };

  const getTierName = (tier: UserTier) => {
    switch (tier) {
      case UserTier.T3: return 'Supervisor';
      case UserTier.T2: return 'Admin';
      default: return 'Member';
    }
  };

  const getTierColor = (tier: UserTier) => {
    switch (tier) {
      case UserTier.T3: return 'bg-purple-100 text-purple-800';
      case UserTier.T2: return 'bg-blue-100 text-blue-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  const getUpgradePrice = (tier: UserTier) => {
    switch (tier) {
      case UserTier.T2: return '$49/month';
      case UserTier.T3: return '$99/month';
      default: return 'Free';
    }
  };

  const handleUpgrade = (newTier: UserTier) => {
    upgradeAccountMutation.mutate(newTier);
  };

  const handleAddMember = () => {
    if (!newMemberEmail) {
      toast({
        title: "Email Required",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }
    addMemberMutation.mutate(newMemberEmail);
  };

  const canAddMembers = hasPermission('canManageTeam') && 
                       userProfile && 
                       (userProfile.teamMembers?.length || 0) < userProfile.maxTeamSize;

  return (
    <div className="space-y-6">
      {/* Account Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            {getTierIcon(userProfile?.tier || UserTier.T1)}
            <span className="ml-2">Account Status</span>
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <Badge className={`${getTierColor(userProfile?.tier || UserTier.T1)} mb-2`}>
                {getTierName(userProfile?.tier || UserTier.T1)}
              </Badge>
              <div className="text-sm text-slate-600">Current Plan</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-slate-900">
                {userProfile?.maxTeamSize || 0}
              </div>
              <div className="text-sm text-slate-600">Team Capacity</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {userProfile?.teamMembers?.length || 0}
              </div>
              <div className="text-sm text-slate-600">Active Members</div>
            </div>
          </div>
          
          {/* Upgrade Options */}
          {!isTier(UserTier.T3) && (
            <div className="mt-6 pt-6 border-t">
              <h4 className="font-medium mb-4">Upgrade Your Account</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {!isTier(UserTier.T2) && (
                  <Card className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <Shield className="h-5 w-5 text-blue-600" />
                          <span className="font-medium">Admin Account</span>
                        </div>
                        <Badge variant="outline" className="bg-blue-100 text-blue-800">
                          {getUpgradePrice(UserTier.T2)}
                        </Badge>
                      </div>
                      <ul className="text-sm text-slate-600 space-y-1 mb-4">
                        <li className="flex items-center">
                          <Check className="h-3 w-3 mr-2 text-green-500" />
                          Manage up to 5 team members
                        </li>
                        <li className="flex items-center">
                          <Check className="h-3 w-3 mr-2 text-green-500" />
                          Advanced analytics & reporting
                        </li>
                        <li className="flex items-center">
                          <Check className="h-3 w-3 mr-2 text-green-500" />
                          CRM integrations
                        </li>
                        <li className="flex items-center">
                          <Check className="h-3 w-3 mr-2 text-green-500" />
                          Export capabilities
                        </li>
                      </ul>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => handleUpgrade(UserTier.T2)}
                        disabled={upgradeAccountMutation.isPending}
                      >
                        <ArrowUp className="h-4 w-4 mr-1" />
                        Upgrade to Admin
                      </Button>
                    </CardContent>
                  </Card>
                )}
                
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <Crown className="h-5 w-5 text-purple-600" />
                        <span className="font-medium">Supervisor Account</span>
                      </div>
                      <Badge variant="outline" className="bg-purple-100 text-purple-800">
                        {getUpgradePrice(UserTier.T3)}
                      </Badge>
                    </div>
                    <ul className="text-sm text-slate-600 space-y-1 mb-4">
                      <li className="flex items-center">
                        <Check className="h-3 w-3 mr-2 text-green-500" />
                        Unlimited team members
                      </li>
                      <li className="flex items-center">
                        <Check className="h-3 w-3 mr-2 text-green-500" />
                        Manage multiple admin accounts
                      </li>
                      <li className="flex items-center">
                        <Check className="h-3 w-3 mr-2 text-green-500" />
                        White-label capabilities
                      </li>
                      <li className="flex items-center">
                        <Check className="h-3 w-3 mr-2 text-green-500" />
                        Priority support
                      </li>
                    </ul>
                    <Button 
                      size="sm" 
                      className="w-full"
                      onClick={() => handleUpgrade(UserTier.T3)}
                      disabled={upgradeAccountMutation.isPending}
                    >
                      <Crown className="h-4 w-4 mr-1" />
                      Upgrade to Supervisor
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Team Management */}
      {hasPermission('canManageTeam') && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Team Management
              </CardTitle>
              
              {canAddMembers && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <UserPlus className="h-4 w-4 mr-1" />
                      Add Member
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Team Member</DialogTitle>
                      <DialogDescription>
                        Invite a new member to your team. They'll receive an email invitation.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 mt-4">
                      <div>
                        <label className="text-sm font-medium">Email Address</label>
                        <Input
                          type="email"
                          value={newMemberEmail}
                          onChange={(e) => setNewMemberEmail(e.target.value)}
                          placeholder="Enter member's email..."
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline">Cancel</Button>
                        <Button 
                          onClick={handleAddMember}
                          disabled={addMemberMutation.isPending}
                        >
                          {addMemberMutation.isPending ? 'Adding...' : 'Send Invitation'}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </CardHeader>
          
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-slate-500">Loading team members...</div>
            ) : teamMembers.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900 mb-2">No Team Members</h3>
                <p className="text-slate-500 mb-4">Start building your team by adding members</p>
              </div>
            ) : (
              <div className="space-y-4">
                {teamMembers.map((member: any) => (
                  <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium">
                        {member.fullName?.charAt(0) || member.email?.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium">{member.fullName || member.email}</div>
                        <div className="text-sm text-slate-500">{member.email}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Badge className={getTierColor(member.tier)}>
                        {getTierName(member.tier)}
                      </Badge>
                      
                      {isTier(UserTier.T3) && member.tier !== UserTier.T3 && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => promoteUserMutation.mutate({ 
                            userId: member.id, 
                            newTier: member.tier === UserTier.T1 ? UserTier.T2 : UserTier.T3 
                          })}
                        >
                          <ArrowUp className="h-3 w-3 mr-1" />
                          Promote
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Account Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Star className="h-5 w-5 mr-2" />
            Account Features
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-medium">Permissions</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Create Campaigns</span>
                  <Badge variant={hasPermission('canCreateCampaigns') ? 'default' : 'secondary'}>
                    {hasPermission('canCreateCampaigns') ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Manage Team</span>
                  <Badge variant={hasPermission('canManageTeam') ? 'default' : 'secondary'}>
                    {hasPermission('canManageTeam') ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Export Data</span>
                  <Badge variant={hasPermission('canExportData') ? 'default' : 'secondary'}>
                    {hasPermission('canExportData') ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">CRM Integration</span>
                  <Badge variant={hasPermission('canIntegrateCRM') ? 'default' : 'secondary'}>
                    {hasPermission('canIntegrateCRM') ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium">Security</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Two-Factor Auth</span>
                  <Badge variant={userProfile?.mfaEnabled ? 'default' : 'secondary'}>
                    {userProfile?.mfaEnabled ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Account Status</span>
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    Active
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}