import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Eye, Mail, Printer, Download, Check, XCircle, 
  ChevronRight, ChevronLeft, ExternalLink, RefreshCw 
} from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { formatRelativeTime } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

interface MessagePreviewProps {
  campaignId: number;
  templateId?: number;
}

interface EmailPreview {
  subject: string;
  body: string;
  contactId: number;
  contactName: string;
  companyName?: string;
  messageId?: string;
}

export function MessagePreview({ campaignId, templateId }: MessagePreviewProps) {
  const { toast } = useToast();
  const [selectedPreviewIndex, setSelectedPreviewIndex] = useState(0);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [verificationMode, setVerificationMode] = useState(false);
  const [sending, setSending] = useState(false);
  
  // Fetch drafted messages
  const { data: logs = [], isLoading, refetch } = useQuery<any[]>({
    queryKey: [`/api/logs/campaign/${campaignId}`],
    enabled: !!campaignId,
    select: (data: any) => {
      // Filter for email_drafted actions and extract preview data
      return data.filter((log: any) => log.action === 'email_drafted' && 
        log.details && log.details.previewSubject && log.details.previewBody)
        .map((log: any) => ({
          subject: log.details.previewSubject,
          body: log.details.previewBody,
          contactId: log.contactId,
          contactName: log.message.replace('Drafted email to ', ''),
          companyName: log.details.companyName,
          messageId: log.details.messageId,
          timestamp: new Date(log.createdAt)
        }));
    }
  });
  
  // Fetch contact details
  const { data: contacts = [] } = useQuery<any[]>({
    queryKey: [`/api/contacts/campaign/${campaignId}`],
    enabled: !!campaignId
  });
  
  // Add more details to previews using contact data
  const enrichedPreviews = logs.map((preview: any) => {
    const contact = contacts.find((c: any) => c.id === preview.contactId);
    return {
      ...preview,
      companyName: contact?.companyName || preview.companyName || 'Unknown Company',
    };
  });
  
  const currentPreview = enrichedPreviews[selectedPreviewIndex] || null;
  
  const handleNextPreview = () => {
    if (selectedPreviewIndex < enrichedPreviews.length - 1) {
      setSelectedPreviewIndex(selectedPreviewIndex + 1);
    }
  };
  
  const handlePrevPreview = () => {
    if (selectedPreviewIndex > 0) {
      setSelectedPreviewIndex(selectedPreviewIndex - 1);
    }
  };
  
  const handleVerifyAll = () => {
    setVerificationMode(true);
  };
  
  const handleSendVerified = async () => {
    if (!campaignId || !templateId) {
      toast({
        title: "Missing Information",
        description: "Campaign or template information is missing",
        variant: "destructive",
      });
      return;
    }
    
    setSending(true);
    
    try {
      const response = await apiRequest('POST', '/api/automation/send-verified', {
        campaignId,
        templateId
      });
      
      const data = await response.json();
      
      toast({
        title: "Messages Sent",
        description: `Successfully sent ${data.sentCount} verified messages`,
        variant: "default",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/contacts/campaign/${campaignId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/logs/campaign/${campaignId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/stats/campaign/${campaignId}`] });
      
      setVerificationMode(false);
    } catch (error) {
      toast({
        title: "Error Sending Messages",
        description: "There was a problem sending the verified messages",
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };
  
  const handleExportReport = () => {
    if (enrichedPreviews.length === 0) {
      toast({
        title: "No Data to Export",
        description: "There are no drafted messages to include in the report",
        variant: "destructive",
      });
      return;
    }
    
    // Prepare CSV data
    const csvHeader = ['Contact', 'Company', 'Subject', 'Preview', 'Status', 'Timestamp'];
    const csvData = enrichedPreviews.map((preview: any) => [
      preview.contactName,
      preview.companyName,
      preview.subject,
      preview.body.replace(/(\r\n|\n|\r)/gm, " "), // Remove line breaks for CSV
      'Drafted',
      preview.timestamp.toLocaleString()
    ]);
    
    // Convert to CSV
    const csvContent = [
      csvHeader.join(','),
      ...csvData.map((row: any) => row.join(','))
    ].join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `campaign-${campaignId}-report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Report Exported",
      description: "Campaign report has been downloaded as CSV",
      variant: "default",
    });
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 flex justify-center items-center min-h-[200px]">
          <div className="flex flex-col items-center">
            <RefreshCw className="h-5 w-5 text-slate-400 animate-spin" />
            <p className="mt-2 text-sm text-slate-500">Loading message previews...</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (enrichedPreviews.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Message Previews</h2>
          <div className="flex flex-col items-center justify-center min-h-[150px] bg-slate-50 rounded-lg p-4">
            <Mail className="h-8 w-8 text-slate-300 mb-2" />
            <p className="text-center text-slate-500">No message drafts available. Start automation to see message previews.</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-slate-900">Message Previews</h2>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleExportReport}
              className="flex items-center"
            >
              <Download className="h-4 w-4 mr-1" />
              Export Report
            </Button>
            {!verificationMode && (
              <Button 
                variant="default" 
                size="sm" 
                onClick={handleVerifyAll}
                className="flex items-center"
              >
                <Check className="h-4 w-4 mr-1" />
                Verify &amp; Send
              </Button>
            )}
          </div>
        </div>
        
        {verificationMode ? (
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <h3 className="text-amber-800 font-medium mb-2">Human Verification Required</h3>
              <p className="text-amber-700 text-sm">
                Review the {enrichedPreviews.length} drafted messages before sending. Make sure all personalization and content looks correct.
              </p>
            </div>
            
            <div className="grid gap-4 max-h-[300px] overflow-y-auto">
              {enrichedPreviews.map((preview: any, index: number) => (
                <div key={index} className="border rounded-lg p-3 bg-white">
                  <div className="flex justify-between mb-2">
                    <div>
                      <span className="font-medium">{preview.contactName}</span>
                      <span className="text-slate-500 text-xs ml-2">({preview.companyName})</span>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          Preview
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl">
                        <DialogHeader>
                          <DialogTitle>Message Preview</DialogTitle>
                          <DialogDescription>
                            Reviewing message to {preview.contactName}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="bg-white border rounded-lg p-4 mt-4">
                          <div className="font-medium mb-2">Subject: {preview.subject}</div>
                          <div className="text-sm whitespace-pre-wrap border-t pt-3">
                            {preview.body}
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                  <div className="text-sm text-slate-700 truncate">
                    <span className="font-medium">Subject:</span> {preview.subject}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex justify-end space-x-2 pt-4 border-t">
              <Button 
                variant="outline" 
                onClick={() => setVerificationMode(false)}
                disabled={sending}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSendVerified} 
                disabled={sending}
              >
                {sending ? 'Sending...' : 'Confirm & Send All'}
              </Button>
            </div>
          </div>
        ) : (
          <>
            {currentPreview && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-slate-800">{currentPreview.contactName}</h3>
                    <p className="text-xs text-slate-500">
                      {currentPreview.companyName} • {formatRelativeTime(currentPreview.timestamp)}
                    </p>
                  </div>
                  <div className="flex space-x-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handlePrevPreview}
                      disabled={selectedPreviewIndex === 0}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-xs text-slate-500 flex items-center px-1">
                      {selectedPreviewIndex + 1} / {enrichedPreviews.length}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleNextPreview}
                      disabled={selectedPreviewIndex >= enrichedPreviews.length - 1}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="border rounded-lg">
                  <div className="border-b bg-slate-50 p-3">
                    <h4 className="font-medium">Subject: {currentPreview.subject}</h4>
                  </div>
                  <div className="p-4 text-sm text-slate-700 whitespace-pre-wrap max-h-[200px] overflow-y-auto">
                    {currentPreview.body}
                  </div>
                </div>
                
                <div className="flex justify-center">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setIsPreviewOpen(true)}
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Open Full Preview
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
      
      {isPreviewOpen && currentPreview && (
        <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Full Message Preview</DialogTitle>
              <DialogDescription>
                Preview of message to {currentPreview.contactName} at {currentPreview.companyName}
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="preview" className="mt-4">
              <TabsList>
                <TabsTrigger value="preview">Preview</TabsTrigger>
                <TabsTrigger value="html">HTML</TabsTrigger>
                <TabsTrigger value="text">Plain Text</TabsTrigger>
              </TabsList>
              <TabsContent value="preview" className="p-4 border rounded-lg mt-2">
                <div className="font-medium mb-2">Subject: {currentPreview.subject}</div>
                <div className="text-sm border-t pt-3 whitespace-pre-wrap">
                  {currentPreview.body}
                </div>
              </TabsContent>
              <TabsContent value="html" className="p-4 border rounded-lg mt-2 bg-slate-50 font-mono text-xs overflow-x-auto">
                {`<html>
  <head>
    <title>${currentPreview.subject}</title>
  </head>
  <body>
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      ${currentPreview.body.replace(/\n/g, '<br/>')}
    </div>
  </body>
</html>`}
              </TabsContent>
              <TabsContent value="text" className="p-4 border rounded-lg mt-2 bg-slate-50 font-mono text-xs whitespace-pre-wrap">
                {`Subject: ${currentPreview.subject}
                
${currentPreview.body}`}
              </TabsContent>
            </Tabs>
            
            <DialogFooter>
              <div className="flex space-x-2">
                <Button variant="outline" className="flex items-center" onClick={() => setIsPreviewOpen(false)}>
                  <XCircle className="h-4 w-4 mr-1" />
                  Close
                </Button>
                <Button variant="outline" className="flex items-center">
                  <Printer className="h-4 w-4 mr-1" />
                  Print
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
}