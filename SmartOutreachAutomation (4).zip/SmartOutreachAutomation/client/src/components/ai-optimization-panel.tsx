import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Sparkles, TrendingUp, Target, Clock, 
  Lightbulb, BarChart3, Zap, Award
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface AIOptimizationPanelProps {
  campaignId: number;
  currentTemplate?: {
    subject: string;
    body: string;
  };
  onOptimizationApply?: (optimization: any) => void;
}

export function AIOptimizationPanel({ 
  campaignId, 
  currentTemplate, 
  onOptimizationApply 
}: AIOptimizationPanelProps) {
  const { toast } = useToast();
  const [selectedOptimization, setSelectedOptimization] = useState<string | null>(null);

  // AI optimization suggestions mutation
  const optimizationMutation = useMutation({
    mutationFn: async (type: string) => {
      return apiRequest('POST', '/api/ai-optimize', {
        campaignId,
        optimizationType: type,
        currentTemplate
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "AI Optimization Complete",
        description: "Generated optimized suggestions for your campaign",
        variant: "default",
      });
      return data;
    },
    onError: (error) => {
      toast({
        title: "Optimization Failed",
        description: error.message || "Failed to generate AI optimizations",
        variant: "destructive",
      });
    }
  });

  const handleOptimize = async (type: string) => {
    const result = await optimizationMutation.mutateAsync(type);
    setSelectedOptimization(type);
    return result;
  };

  const optimizationTypes = [
    {
      id: 'subject-lines',
      title: 'Subject Line Optimization',
      icon: <Sparkles className="h-4 w-4" />,
      description: 'Generate high-converting subject lines based on industry best practices',
      color: 'bg-purple-100 text-purple-800',
      suggestions: [
        { text: "Increase revenue by 40% with our solution", score: 92, reason: "Direct benefit + specific metric" },
        { text: "Quick question about [Company]'s growth", score: 87, reason: "Personal + curiosity gap" },
        { text: "[First Name], 5 min to transform your workflow?", score: 85, reason: "Personalized + time-bound" }
      ]
    },
    {
      id: 'content-optimization',
      title: 'Content Enhancement',
      icon: <TrendingUp className="h-4 w-4" />,
      description: 'Optimize email body for higher engagement and response rates',
      color: 'bg-blue-100 text-blue-800',
      suggestions: [
        { improvement: "Add social proof", impact: "25% higher response rate", example: "Join 500+ companies like [Similar Company]" },
        { improvement: "Include specific value proposition", impact: "40% more meetings booked", example: "Save 10 hours per week on manual processes" },
        { improvement: "Stronger call-to-action", impact: "60% more clicks", example: "Book a 15-min demo this week" }
      ]
    },
    {
      id: 'timing-optimization',
      title: 'Send Time Intelligence',
      icon: <Clock className="h-4 w-4" />,
      description: 'Optimize send times based on recipient behavior and industry data',
      color: 'bg-green-100 text-green-800',
      insights: [
        { time: "Tuesday 10:00 AM", probability: "23% higher open rate", reason: "Peak B2B engagement time" },
        { time: "Thursday 2:00 PM", probability: "18% more responses", reason: "Post-lunch decision making" },
        { time: "Friday 11:00 AM", probability: "15% better engagement", reason: "Week-end planning window" }
      ]
    },
    {
      id: 'personalization',
      title: 'Advanced Personalization',
      icon: <Target className="h-4 w-4" />,
      description: 'Generate personalized content based on company and contact data',
      color: 'bg-orange-100 text-orange-800',
      examples: [
        { company: "TechCorp", personalization: "Noticed your recent Series B funding - congratulations!" },
        { company: "StartupXYZ", personalization: "Your product launch last month caught our attention" },
        { company: "Enterprise Inc", personalization: "Following your expansion into European markets" }
      ]
    }
  ];

  const handleApplyOptimization = (optimization: any) => {
    if (onOptimizationApply) {
      onOptimizationApply(optimization);
    }
    toast({
      title: "Optimization Applied",
      description: "Your template has been updated with AI suggestions",
      variant: "default",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Zap className="h-5 w-5 mr-2 text-yellow-500" />
          AI Optimization Hub
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="benchmarks">Benchmarks</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {optimizationTypes.map((type) => (
                <Card key={type.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        {type.icon}
                        <h4 className="font-medium text-sm">{type.title}</h4>
                      </div>
                      <Badge variant="outline" className={type.color}>
                        AI-Powered
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-600 mb-3">{type.description}</p>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="w-full"
                      onClick={() => handleOptimize(type.id)}
                      disabled={optimizationMutation.isPending}
                    >
                      {optimizationMutation.isPending ? 'Optimizing...' : 'Generate Ideas'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="suggestions" className="space-y-4">
            <div className="space-y-4">
              {optimizationTypes[0].suggestions?.map((suggestion, index) => (
                <div key={index} className="border rounded-lg p-4 bg-gradient-to-r from-purple-50 to-blue-50">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Award className="h-4 w-4 text-purple-600" />
                      <span className="font-medium text-sm">Subject Line Option {index + 1}</span>
                    </div>
                    <Badge variant="default" className="bg-purple-100 text-purple-800">
                      Score: {suggestion.score}%
                    </Badge>
                  </div>
                  <p className="text-sm font-medium mb-1">"{suggestion.text}"</p>
                  <p className="text-xs text-slate-600 mb-3">{suggestion.reason}</p>
                  <Button 
                    size="sm" 
                    onClick={() => handleApplyOptimization({ type: 'subject', content: suggestion.text })}
                  >
                    Apply This Subject
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <BarChart3 className="h-8 w-8 mx-auto mb-2 text-green-600" />
                  <div className="text-2xl font-bold text-green-600">+23%</div>
                  <div className="text-xs text-slate-600">Predicted Open Rate Increase</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <TrendingUp className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                  <div className="text-2xl font-bold text-blue-600">+15%</div>
                  <div className="text-xs text-slate-600">Response Rate Improvement</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Target className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                  <div className="text-2xl font-bold text-purple-600">92%</div>
                  <div className="text-xs text-slate-600">Personalization Score</div>
                </CardContent>
              </Card>
            </div>
            
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4">
              <h4 className="font-medium mb-2 flex items-center">
                <Lightbulb className="h-4 w-4 mr-2 text-yellow-500" />
                AI Insights
              </h4>
              <ul className="space-y-2 text-sm text-slate-700">
                <li>• Your current subject line has a 67% spam filter pass rate</li>
                <li>• Adding company-specific details increases response by 40%</li>
                <li>• Tuesday mornings show 25% higher engagement for your industry</li>
                <li>• Shorter emails (under 150 words) perform 30% better</li>
              </ul>
            </div>
          </TabsContent>
          
          <TabsContent value="benchmarks" className="space-y-4">
            <div className="space-y-4">
              <h4 className="font-medium">Industry Benchmarks</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <h5 className="font-medium mb-2">SaaS Industry Average</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Open Rate:</span>
                        <span className="font-medium">21.5%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Response Rate:</span>
                        <span className="font-medium">8.2%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Click Rate:</span>
                        <span className="font-medium">3.7%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <h5 className="font-medium mb-2">Your Campaign Performance</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Open Rate:</span>
                        <span className="font-medium text-green-600">26.8% (+5.3%)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Response Rate:</span>
                        <span className="font-medium text-green-600">12.1% (+3.9%)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Click Rate:</span>
                        <span className="font-medium text-green-600">5.2% (+1.5%)</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}