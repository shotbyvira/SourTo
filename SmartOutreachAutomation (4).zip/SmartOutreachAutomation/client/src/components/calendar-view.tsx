import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, ChevronLeft, ChevronRight, 
  Mail, MessageCircle, Clock, Users,
  Plus, Filter, Eye
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface CalendarViewProps {
  campaignId: number;
}

interface CalendarEvent {
  id: number;
  type: 'email' | 'whatsapp' | 'follow-up' | 'meeting';
  title: string;
  contactName: string;
  contactId: number;
  scheduledAt: string;
  status: 'scheduled' | 'sent' | 'failed' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  description?: string;
  duration?: number; // in minutes
}

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function CalendarView({ campaignId }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day'>('month');
  const [filterType, setFilterType] = useState<'all' | 'email' | 'whatsapp' | 'follow-up' | 'meeting'>('all');

  // Fetch calendar events
  const { data: events = [], isLoading } = useQuery({
    queryKey: [`/api/calendar-events/${campaignId}`, currentDate.getFullYear(), currentDate.getMonth()],
    enabled: !!campaignId
  });

  const filteredEvents = events.filter((event: CalendarEvent) => 
    filterType === 'all' || event.type === filterType
  );

  // Navigation functions
  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(newDate.getMonth() - 1);
      } else {
        newDate.setMonth(newDate.getMonth() + 1);
      }
      return newDate;
    });
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      const days = direction === 'prev' ? -7 : 7;
      newDate.setDate(newDate.getDate() + days);
      return newDate;
    });
  };

  const navigateDay = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      const days = direction === 'prev' ? -1 : 1;
      newDate.setDate(newDate.getDate() + days);
      return newDate;
    });
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  // Get events for a specific date
  const getEventsForDate = (date: Date) => {
    return filteredEvents.filter((event: CalendarEvent) => {
      const eventDate = new Date(event.scheduledAt);
      return eventDate.toDateString() === date.toDateString();
    });
  };

  // Get calendar days for month view
  const getCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    const days = [];
    const current = new Date(startDate);
    
    for (let i = 0; i < 42; i++) {
      days.push(new Date(current));
      current.setDate(current.getDate() + 1);
    }
    
    return days;
  };

  // Get week days for week view
  const getWeekDays = () => {
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
    
    const days = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      days.push(day);
    }
    return days;
  };

  // Get event type icon
  const getEventIcon = (type: string) => {
    switch (type) {
      case 'email': return <Mail className="h-3 w-3" />;
      case 'whatsapp': return <MessageCircle className="h-3 w-3" />;
      case 'follow-up': return <Clock className="h-3 w-3" />;
      case 'meeting': return <Users className="h-3 w-3" />;
      default: return <Calendar className="h-3 w-3" />;
    }
  };

  // Get event type color
  const getEventColor = (type: string) => {
    switch (type) {
      case 'email': return 'bg-blue-500';
      case 'whatsapp': return 'bg-green-500';
      case 'follow-up': return 'bg-purple-500';
      case 'meeting': return 'bg-orange-500';
      default: return 'bg-slate-500';
    }
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'sent': return 'bg-green-100 text-green-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-slate-100 text-slate-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  // Format time
  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  // Month View Component
  const MonthView = () => {
    const calendarDays = getCalendarDays();
    const currentMonth = currentDate.getMonth();

    return (
      <div className="grid grid-cols-7 gap-1">
        {/* Day headers */}
        {DAYS.map(day => (
          <div key={day} className="p-2 text-center text-sm font-medium text-slate-600">
            {day}
          </div>
        ))}
        
        {/* Calendar days */}
        {calendarDays.map((day, index) => {
          const dayEvents = getEventsForDate(day);
          const isCurrentMonth = day.getMonth() === currentMonth;
          const isToday = day.toDateString() === new Date().toDateString();
          
          return (
            <div
              key={index}
              className={`min-h-[100px] p-1 border border-slate-200 ${
                isCurrentMonth ? 'bg-white' : 'bg-slate-50'
              } ${isToday ? 'ring-2 ring-blue-500' : ''}`}
            >
              <div className={`text-sm font-medium mb-1 ${
                isCurrentMonth ? 'text-slate-900' : 'text-slate-400'
              } ${isToday ? 'text-blue-600' : ''}`}>
                {day.getDate()}
              </div>
              
              <div className="space-y-1">
                {dayEvents.slice(0, 3).map((event: CalendarEvent) => (
                  <div
                    key={event.id}
                    className={`text-xs p-1 rounded cursor-pointer ${getEventColor(event.type)} text-white truncate`}
                    onClick={() => setSelectedEvent(event)}
                  >
                    <div className="flex items-center space-x-1">
                      {getEventIcon(event.type)}
                      <span>{formatTime(event.scheduledAt)}</span>
                    </div>
                    <div className="truncate">{event.title}</div>
                  </div>
                ))}
                {dayEvents.length > 3 && (
                  <div className="text-xs text-slate-500 text-center">
                    +{dayEvents.length - 3} more
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // Week View Component
  const WeekView = () => {
    const weekDays = getWeekDays();
    const hours = Array.from({ length: 24 }, (_, i) => i);

    return (
      <div className="flex flex-col">
        {/* Day headers */}
        <div className="grid grid-cols-8 gap-1 mb-2">
          <div className="p-2"></div> {/* Time column header */}
          {weekDays.map(day => (
            <div key={day.toISOString()} className="p-2 text-center">
              <div className="text-sm font-medium">{DAYS[day.getDay()]}</div>
              <div className={`text-lg ${
                day.toDateString() === new Date().toDateString() 
                  ? 'text-blue-600 font-bold' 
                  : 'text-slate-900'
              }`}>
                {day.getDate()}
              </div>
            </div>
          ))}
        </div>

        {/* Time grid */}
        <div className="flex-1 overflow-auto">
          <div className="grid grid-cols-8 gap-1">
            {/* Time column */}
            <div className="space-y-12">
              {hours.map(hour => (
                <div key={hour} className="text-xs text-slate-500 text-right pr-2">
                  {hour === 0 ? '12 AM' : hour < 12 ? `${hour} AM` : hour === 12 ? '12 PM' : `${hour - 12} PM`}
                </div>
              ))}
            </div>

            {/* Day columns */}
            {weekDays.map(day => {
              const dayEvents = getEventsForDate(day);
              return (
                <div key={day.toISOString()} className="relative border-l border-slate-200 min-h-[800px]">
                  {/* Hour lines */}
                  {hours.map(hour => (
                    <div key={hour} className="absolute w-full border-t border-slate-100" style={{ top: `${hour * 50}px` }} />
                  ))}
                  
                  {/* Events */}
                  {dayEvents.map((event: CalendarEvent) => {
                    const eventDate = new Date(event.scheduledAt);
                    const hour = eventDate.getHours();
                    const minute = eventDate.getMinutes();
                    const top = hour * 50 + (minute / 60) * 50;
                    const height = event.duration ? (event.duration / 60) * 50 : 25;
                    
                    return (
                      <div
                        key={event.id}
                        className={`absolute left-1 right-1 ${getEventColor(event.type)} text-white text-xs p-1 rounded cursor-pointer z-10`}
                        style={{ top: `${top}px`, height: `${height}px` }}
                        onClick={() => setSelectedEvent(event)}
                      >
                        <div className="flex items-center space-x-1">
                          {getEventIcon(event.type)}
                          <span>{formatTime(event.scheduledAt)}</span>
                        </div>
                        <div className="truncate font-medium">{event.title}</div>
                        <div className="truncate text-xs opacity-90">{event.contactName}</div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  // Day View Component
  const DayView = () => {
    const dayEvents = getEventsForDate(currentDate);
    const hours = Array.from({ length: 24 }, (_, i) => i);

    return (
      <div className="space-y-4">
        <div className="text-center">
          <h3 className="text-lg font-medium">
            {currentDate.toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </h3>
          <p className="text-sm text-slate-500">{dayEvents.length} scheduled communications</p>
        </div>

        <div className="flex">
          {/* Time column */}
          <div className="w-20 space-y-12">
            {hours.map(hour => (
              <div key={hour} className="text-xs text-slate-500 text-right pr-2 h-12 flex items-start pt-1">
                {hour === 0 ? '12 AM' : hour < 12 ? `${hour} AM` : hour === 12 ? '12 PM' : `${hour - 12} PM`}
              </div>
            ))}
          </div>

          {/* Events column */}
          <div className="flex-1 relative border-l border-slate-200">
            {/* Hour lines */}
            {hours.map(hour => (
              <div key={hour} className="absolute w-full border-t border-slate-100" style={{ top: `${hour * 48}px` }} />
            ))}
            
            {/* Events */}
            {dayEvents.map((event: CalendarEvent) => {
              const eventDate = new Date(event.scheduledAt);
              const hour = eventDate.getHours();
              const minute = eventDate.getMinutes();
              const top = hour * 48 + (minute / 60) * 48;
              const height = event.duration ? (event.duration / 60) * 48 : 24;
              
              return (
                <div
                  key={event.id}
                  className={`absolute left-2 right-2 ${getEventColor(event.type)} text-white p-2 rounded cursor-pointer z-10`}
                  style={{ top: `${top}px`, minHeight: `${height}px` }}
                  onClick={() => setSelectedEvent(event)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center space-x-1">
                      {getEventIcon(event.type)}
                      <span className="text-sm font-medium">{formatTime(event.scheduledAt)}</span>
                    </div>
                    <Badge className={getStatusColor(event.status)} variant="outline">
                      {event.status}
                    </Badge>
                  </div>
                  <div className="font-medium">{event.title}</div>
                  <div className="text-sm opacity-90">{event.contactName}</div>
                  {event.description && (
                    <div className="text-xs opacity-80 mt-1">{event.description}</div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Communication Calendar
            </CardTitle>
            
            <div className="flex items-center space-x-2">
              <Select value={filterType} onValueChange={(value: any) => setFilterType(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  <SelectItem value="follow-up">Follow-up</SelectItem>
                  <SelectItem value="meeting">Meeting</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="flex items-center border rounded-lg">
                <Button
                  variant="ghost"
                  size="sm"
                  className={viewMode === 'month' ? 'bg-blue-100 text-blue-900' : ''}
                  onClick={() => setViewMode('month')}
                >
                  Month
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={viewMode === 'week' ? 'bg-blue-100 text-blue-900' : ''}
                  onClick={() => setViewMode('week')}
                >
                  Week
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={viewMode === 'day' ? 'bg-blue-100 text-blue-900' : ''}
                  onClick={() => setViewMode('day')}
                >
                  Day
                </Button>
              </div>
            </div>
          </div>
          
          {/* Navigation */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (viewMode === 'month') navigateMonth('prev');
                  else if (viewMode === 'week') navigateWeek('prev');
                  else navigateDay('prev');
                }}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <h2 className="text-xl font-semibold">
                {viewMode === 'month' 
                  ? `${MONTHS[currentDate.getMonth()]} ${currentDate.getFullYear()}`
                  : viewMode === 'week'
                    ? `Week of ${currentDate.toLocaleDateString()}`
                    : currentDate.toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        month: 'long', 
                        day: 'numeric' 
                      })
                }
              </h2>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (viewMode === 'month') navigateMonth('next');
                  else if (viewMode === 'week') navigateWeek('next');
                  else navigateDay('next');
                }}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="text-center py-12 text-slate-500">Loading calendar...</div>
          ) : (
            <>
              {viewMode === 'month' && <MonthView />}
              {viewMode === 'week' && <WeekView />}
              {viewMode === 'day' && <DayView />}
            </>
          )}
        </CardContent>
      </Card>

      {/* Event Details Modal */}
      {selectedEvent && (
        <Dialog open={!!selectedEvent} onOpenChange={() => setSelectedEvent(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                {getEventIcon(selectedEvent.type)}
                <span>{selectedEvent.title}</span>
              </DialogTitle>
              <DialogDescription>
                Communication details for {selectedEvent.contactName}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-600">Type</label>
                  <div className="flex items-center space-x-2 mt-1">
                    {getEventIcon(selectedEvent.type)}
                    <span className="capitalize">{selectedEvent.type}</span>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-slate-600">Status</label>
                  <div className="mt-1">
                    <Badge className={getStatusColor(selectedEvent.status)}>
                      {selectedEvent.status}
                    </Badge>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-slate-600">Contact</label>
                  <div className="mt-1">{selectedEvent.contactName}</div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-slate-600">Scheduled Time</label>
                  <div className="mt-1">
                    {new Date(selectedEvent.scheduledAt).toLocaleString()}
                  </div>
                </div>
              </div>
              
              {selectedEvent.description && (
                <div>
                  <label className="text-sm font-medium text-slate-600">Description</label>
                  <div className="mt-1 text-sm text-slate-700">{selectedEvent.description}</div>
                </div>
              )}
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setSelectedEvent(null)}>
                  Close
                </Button>
                <Button>
                  <Eye className="h-4 w-4 mr-1" />
                  View Details
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}