import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, Clock, Mail, ArrowRight, 
  Play, Pause, Settings, Zap
} from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

interface FollowUpSequencesProps {
  campaignId: number;
}

interface FollowUpStep {
  id: number;
  delay: number; // days
  subject: string;
  body: string;
  isActive: boolean;
}

export function FollowUpSequences({ campaignId }: FollowUpSequencesProps) {
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);
  const [newStep, setNewStep] = useState<Partial<FollowUpStep>>({
    delay: 3,
    subject: '',
    body: '',
    isActive: true
  });

  // Fetch existing follow-up sequences
  const { data: sequences = [], isLoading } = useQuery({
    queryKey: [`/api/follow-up-sequences/${campaignId}`],
    enabled: !!campaignId
  });

  // Create new follow-up step
  const createStepMutation = useMutation({
    mutationFn: async (stepData: Partial<FollowUpStep>) => {
      return apiRequest('POST', '/api/follow-up-sequences', {
        campaignId,
        ...stepData
      });
    },
    onSuccess: () => {
      toast({
        title: "Follow-up Created",
        description: "New follow-up step added to sequence",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/follow-up-sequences/${campaignId}`] });
      setIsCreating(false);
      setNewStep({ delay: 3, subject: '', body: '', isActive: true });
    },
    onError: (error) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create follow-up step",
        variant: "destructive",
      });
    }
  });

  // Toggle sequence active status
  const toggleSequenceMutation = useMutation({
    mutationFn: async (sequenceId: number) => {
      return apiRequest('PATCH', `/api/follow-up-sequences/${sequenceId}/toggle`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/follow-up-sequences/${campaignId}`] });
    }
  });

  const handleCreateStep = () => {
    if (!newStep.subject || !newStep.body) {
      toast({
        title: "Missing Information",
        description: "Please provide both subject and body for the follow-up",
        variant: "destructive",
      });
      return;
    }
    createStepMutation.mutate(newStep);
  };

  const getDelayText = (days: number) => {
    if (days === 1) return "1 day";
    if (days < 7) return `${days} days`;
    if (days === 7) return "1 week";
    if (days < 30) return `${Math.floor(days / 7)} weeks`;
    return `${Math.floor(days / 30)} months`;
  };

  const smartTemplates = [
    {
      name: "Gentle Reminder",
      subject: "Following up on our conversation about [Company]",
      body: `Hi [First Name],

I hope this email finds you well. I wanted to follow up on my previous message about how we can help [Company] improve your workflow efficiency.

I understand you're probably busy, but I'd love to share a quick case study of how we helped a similar company in your industry save 15 hours per week.

Would you be open to a brief 10-minute call this week?

Best regards,
[Your Name]`
    },
    {
      name: "Value-Added Follow-up",
      subject: "Thought this might interest you, [First Name]",
      body: `Hi [First Name],

I came across this article about trends in your industry and thought it might be relevant for [Company]: [Article Link]

This reminded me of our previous conversation about optimizing your processes. We've actually helped several companies in similar situations achieve remarkable results.

If you're still interested in exploring how we can help [Company], I'd be happy to schedule a quick call at your convenience.

Best,
[Your Name]`
    },
    {
      name: "Break-up Email",
      subject: "Last attempt - should I close your file?",
      body: `Hi [First Name],

I've reached out a few times regarding how we can help [Company] streamline your operations, but I haven't heard back from you.

I completely understand that timing might not be right, or this might not be a priority for [Company] right now.

Rather than continue to fill your inbox, I'll assume this isn't a fit and remove you from my follow-up sequence.

If anything changes in the future, feel free to reach out.

Best of luck with everything!
[Your Name]`
    }
  ];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Clock className="h-5 w-5 mr-2" />
            Follow-up Sequences
          </CardTitle>
          <Dialog open={isCreating} onOpenChange={setIsCreating}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-1" />
                Add Step
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Follow-up Step</DialogTitle>
                <DialogDescription>
                  Add a new step to your automated follow-up sequence
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 mt-4">
                <div>
                  <label className="text-sm font-medium">Send after (days)</label>
                  <Input
                    type="number"
                    value={newStep.delay}
                    onChange={(e) => setNewStep({ ...newStep, delay: parseInt(e.target.value) })}
                    className="mt-1"
                    min="1"
                    max="365"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium">Subject Line</label>
                  <Input
                    value={newStep.subject}
                    onChange={(e) => setNewStep({ ...newStep, subject: e.target.value })}
                    placeholder="Enter email subject..."
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium">Email Body</label>
                  <Textarea
                    value={newStep.body}
                    onChange={(e) => setNewStep({ ...newStep, body: e.target.value })}
                    placeholder="Enter email content..."
                    className="mt-1 min-h-[150px]"
                  />
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-2">Smart Templates</h4>
                  <div className="grid grid-cols-1 gap-2">
                    {smartTemplates.map((template, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => setNewStep({
                          ...newStep,
                          subject: template.subject,
                          body: template.body
                        })}
                        className="justify-start h-auto p-2"
                      >
                        <div className="text-left">
                          <div className="font-medium">{template.name}</div>
                          <div className="text-xs text-slate-500 truncate">
                            {template.subject}
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setIsCreating(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCreateStep}
                    disabled={createStepMutation.isPending}
                  >
                    {createStepMutation.isPending ? 'Creating...' : 'Create Step'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8 text-slate-500">Loading sequences...</div>
        ) : sequences.length === 0 ? (
          <div className="text-center py-8">
            <Mail className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No Follow-up Sequences</h3>
            <p className="text-slate-500 mb-4">Create automated follow-up sequences to increase response rates</p>
            <Button onClick={() => setIsCreating(true)}>
              <Plus className="h-4 w-4 mr-1" />
              Create First Sequence
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="bg-green-100 text-green-800">
                  {sequences.filter((s: any) => s.isActive).length} Active
                </Badge>
                <Badge variant="outline" className="bg-slate-100 text-slate-800">
                  {sequences.length} Total Steps
                </Badge>
              </div>
              <div className="text-sm text-slate-500">
                Avg response rate: +24% with follow-ups
              </div>
            </div>
            
            <div className="space-y-3">
              {sequences.map((step: any, index: number) => (
                <div key={step.id} className="border rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-600 rounded-full text-sm font-medium">
                        {index + 1}
                      </div>
                      <div>
                        <div className="font-medium text-sm">Step {index + 1}</div>
                        <div className="text-xs text-slate-500">
                          Send after {getDelayText(step.delay)}
                        </div>
                      </div>
                      {index < sequences.length - 1 && (
                        <ArrowRight className="h-4 w-4 text-slate-400" />
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Badge 
                        variant={step.isActive ? "default" : "secondary"}
                        className={step.isActive ? "bg-green-100 text-green-800" : ""}
                      >
                        {step.isActive ? "Active" : "Paused"}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSequenceMutation.mutate(step.id)}
                      >
                        {step.isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <span className="text-xs font-medium text-slate-600">Subject:</span>
                      <div className="text-sm">{step.subject}</div>
                    </div>
                    <div>
                      <span className="text-xs font-medium text-slate-600">Preview:</span>
                      <div className="text-sm text-slate-600 truncate">
                        {step.body.substring(0, 100)}...
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-3 pt-3 border-t flex items-center justify-between text-xs text-slate-500">
                    <span>Last modified: 2 days ago</span>
                    <div className="flex items-center space-x-4">
                      <span>📧 Sent: 23 times</span>
                      <span>📈 Response rate: 18%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4 mt-6">
              <div className="flex items-start space-x-3">
                <Zap className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm mb-1">Smart Sequence Tips</h4>
                  <ul className="text-xs text-slate-600 space-y-1">
                    <li>• Wait 3-5 days between follow-ups for optimal response</li>
                    <li>• Provide value in each follow-up (articles, case studies, insights)</li>
                    <li>• Use different subject lines to avoid spam filters</li>
                    <li>• End with a "break-up" email after 3-4 attempts</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}