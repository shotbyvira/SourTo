import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Database, Link, Settings, Sync, 
  CheckCircle, AlertCircle, Plus
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useFirebaseAuth } from '@/hooks/useFirebaseAuth';
import { apiRequest, queryClient } from '@/lib/queryClient';

export function CrmIntegrations() {
  const { userProfile, hasPermission } = useFirebaseAuth();
  const { toast } = useToast();
  const [isConnecting, setIsConnecting] = useState(false);
  const [selectedCrm, setSelectedCrm] = useState('');
  const [crmCredentials, setCrmCredentials] = useState({
    apiKey: '',
    domain: '',
    clientId: '',
    clientSecret: ''
  });

  // Fetch existing CRM integrations
  const { data: integrations = [], isLoading } = useQuery({
    queryKey: ['/api/crm-integrations', userProfile?.uid],
    enabled: !!userProfile?.uid && hasPermission('canIntegrateCRM')
  });

  // Connect CRM mutation
  const connectCrmMutation = useMutation({
    mutationFn: async (crmData: any) => {
      return apiRequest('POST', '/api/crm-integrations', crmData);
    },
    onSuccess: () => {
      toast({
        title: "CRM Connected",
        description: "Your CRM has been successfully connected",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/crm-integrations'] });
      setIsConnecting(false);
      setSelectedCrm('');
      setCrmCredentials({ apiKey: '', domain: '', clientId: '', clientSecret: '' });
    },
    onError: (error) => {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect CRM",
        variant: "destructive",
      });
    }
  });

  // Sync CRM mutation
  const syncCrmMutation = useMutation({
    mutationFn: async (integrationId: number) => {
      return apiRequest('POST', `/api/crm-integrations/${integrationId}/sync`);
    },
    onSuccess: () => {
      toast({
        title: "Sync Complete",
        description: "CRM data has been synchronized",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/crm-integrations'] });
    }
  });

  const availableCrms = [
    {
      id: 'salesforce',
      name: 'Salesforce',
      icon: '⚡',
      description: 'Connect with Salesforce CRM',
      fields: ['domain', 'clientId', 'clientSecret'],
      popular: true
    },
    {
      id: 'hubspot',
      name: 'HubSpot',
      icon: '🟠',
      description: 'Integrate with HubSpot CRM',
      fields: ['apiKey'],
      popular: true
    },
    {
      id: 'pipedrive',
      name: 'Pipedrive',
      icon: '🔵',
      description: 'Connect with Pipedrive CRM',
      fields: ['apiKey', 'domain'],
      popular: true
    },
    {
      id: 'zoho',
      name: 'Zoho CRM',
      icon: '🟡',
      description: 'Integrate with Zoho CRM',
      fields: ['clientId', 'clientSecret', 'domain'],
      popular: false
    },
    {
      id: 'monday',
      name: 'Monday.com',
      icon: '🔴',
      description: 'Connect with Monday.com',
      fields: ['apiKey'],
      popular: false
    }
  ];

  const handleConnect = () => {
    if (!selectedCrm) {
      toast({
        title: "CRM Required",
        description: "Please select a CRM to connect",
        variant: "destructive",
      });
      return;
    }

    const selectedCrmData = availableCrms.find(crm => crm.id === selectedCrm);
    const missingFields = selectedCrmData?.fields.filter(field => 
      !crmCredentials[field as keyof typeof crmCredentials]
    );

    if (missingFields && missingFields.length > 0) {
      toast({
        title: "Missing Credentials",
        description: `Please provide: ${missingFields.join(', ')}`,
        variant: "destructive",
      });
      return;
    }

    connectCrmMutation.mutate({
      crmType: selectedCrm,
      ...crmCredentials
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-600" />;
      default: return <Database className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-100 text-green-800';
      case 'error': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  if (!hasPermission('canIntegrateCRM')) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Database className="h-12 w-12 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-900 mb-2">CRM Integration</h3>
          <p className="text-slate-500 mb-4">Upgrade to Admin or Supervisor account to access CRM integrations</p>
          <Button variant="outline">View Upgrade Options</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Database className="h-5 w-5 mr-2" />
              CRM Integrations
            </CardTitle>
            
            <Dialog open={isConnecting} onOpenChange={setIsConnecting}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-1" />
                  Connect CRM
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Connect CRM System</DialogTitle>
                  <DialogDescription>
                    Choose a CRM system to integrate with your outreach campaigns
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6 mt-4">
                  {/* CRM Selection */}
                  <div>
                    <label className="text-sm font-medium mb-3 block">Select CRM Platform</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {availableCrms.map((crm) => (
                        <div
                          key={crm.id}
                          className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                            selectedCrm === crm.id 
                              ? 'border-blue-500 bg-blue-50' 
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                          onClick={() => setSelectedCrm(crm.id)}
                        >
                          <div className="flex items-center space-x-3">
                            <div className="text-2xl">{crm.icon}</div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2">
                                <span className="font-medium">{crm.name}</span>
                                {crm.popular && (
                                  <Badge variant="outline" className="text-xs">Popular</Badge>
                                )}
                              </div>
                              <div className="text-xs text-slate-500">{crm.description}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Credentials Form */}
                  {selectedCrm && (
                    <div className="space-y-4">
                      <h4 className="font-medium">Connection Details</h4>
                      {availableCrms.find(crm => crm.id === selectedCrm)?.fields.map((field) => (
                        <div key={field}>
                          <label className="text-sm font-medium capitalize">
                            {field.replace(/([A-Z])/g, ' $1').trim()}
                          </label>
                          <Input
                            type={field.includes('secret') || field.includes('key') ? 'password' : 'text'}
                            value={crmCredentials[field as keyof typeof crmCredentials]}
                            onChange={(e) => setCrmCredentials(prev => ({
                              ...prev,
                              [field]: e.target.value
                            }))}
                            placeholder={`Enter your ${field}...`}
                            className="mt-1"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button variant="outline" onClick={() => setIsConnecting(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleConnect}
                      disabled={connectCrmMutation.isPending}
                    >
                      {connectCrmMutation.isPending ? 'Connecting...' : 'Connect CRM'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
      </Card>

      {/* Active Integrations */}
      <Card>
        <CardHeader>
          <CardTitle>Active Integrations</CardTitle>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-slate-500">Loading integrations...</div>
          ) : integrations.length === 0 ? (
            <div className="text-center py-8">
              <Database className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No CRM Integrations</h3>
              <p className="text-slate-500 mb-4">Connect your first CRM to sync contacts and leads</p>
              <Button onClick={() => setIsConnecting(true)}>
                <Plus className="h-4 w-4 mr-1" />
                Connect Your First CRM
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {integrations.map((integration: any) => (
                <div key={integration.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">
                        {availableCrms.find(crm => crm.id === integration.crmType)?.icon || '🔗'}
                      </div>
                      <div>
                        <div className="font-medium">
                          {availableCrms.find(crm => crm.id === integration.crmType)?.name || integration.crmType}
                        </div>
                        <div className="text-sm text-slate-500">
                          Last sync: {integration.lastSyncAt ? 
                            new Date(integration.lastSyncAt).toLocaleDateString() : 'Never'
                          }
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(integration.status)}>
                        {getStatusIcon(integration.status)}
                        <span className="ml-1 capitalize">{integration.status || 'Connected'}</span>
                      </Badge>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => syncCrmMutation.mutate(integration.id)}
                        disabled={syncCrmMutation.isPending}
                      >
                        <Sync className="h-3 w-3 mr-1" />
                        Sync Now
                      </Button>
                      
                      <Button size="sm" variant="ghost">
                        <Settings className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  {/* Integration Stats */}
                  <div className="mt-4 pt-4 border-t grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-lg font-semibold text-slate-900">
                        {integration.syncedContacts || 0}
                      </div>
                      <div className="text-xs text-slate-500">Synced Contacts</div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold text-slate-900">
                        {integration.syncedLeads || 0}
                      </div>
                      <div className="text-xs text-slate-500">Synced Leads</div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold text-slate-900">
                        {integration.syncedOpportunities || 0}
                      </div>
                      <div className="text-xs text-slate-500">Opportunities</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Integration Benefits */}
      <Card>
        <CardHeader>
          <CardTitle>Integration Benefits</CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Automated Sync</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                  Bi-directional contact synchronization
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                  Real-time lead status updates
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                  Automated campaign tracking
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium mb-3">Enhanced Reporting</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                  CRM pipeline integration
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                  Revenue attribution tracking
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                  Advanced analytics dashboards
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}