import React from 'react';
import { Link } from 'wouter';
import { Send } from 'lucide-react';

interface HeaderProps {
  userName?: string;
}

export function Header({ userName = "Guest User" }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <Send className="h-5 w-5 text-primary-600 mr-3" />
          <Link href="/">
            <span className="text-xl font-semibold text-slate-900 cursor-pointer">Smart Outreach Automation Tool</span>
          </Link>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            type="button" 
            className="flex items-center text-sm font-medium text-slate-700 hover:text-slate-900"
          >
            <span className="mr-1.5">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 005 10a6 6 0 0012 0c0-.35-.035-.691-.1-1.022A4.978 4.978 0 0012 11c-1.176 0-2.252-.414-3.096-1.1A3.015 3.015 0 0010 8V7z" clipRule="evenodd" />
              </svg>
            </span>
            <span>{userName}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
