/**
 * Name Parser Service - Parses full names into honorific, first, middle, and last names
 */

interface ParsedName {
  honorific?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
}

// Common honorifics to check for
const HONORIFICS = [
  "Mr", "Mr.", "Mrs", "Mrs.", "Ms", "Ms.", "Miss", "Dr", "Dr.",
  "Prof", "Prof.", "Sir", "Madam", "Lady", "Lord", "Rev", "Rev.",
  "Capt", "Capt.", "Major", "Col", "Col.", "Gen", "Gen."
];

export function parseName(fullName: string): ParsedName {
  if (!fullName || typeof fullName !== 'string') {
    return {};
  }

  // Trim extra whitespace and normalize multiple spaces
  const normalizedName = fullName.trim().replace(/\s+/g, ' ');
  
  // Initialize result
  const result: ParsedName = {};
  
  // Extract honorific
  const nameParts = normalizedName.split(' ');
  let startIndex = 0;
  
  // Check if the first part is an honorific
  if (nameParts.length > 0 && HONORIFICS.includes(nameParts[0])) {
    result.honorific = nameParts[0];
    startIndex = 1;
  }
  
  const remainingParts = nameParts.slice(startIndex);
  
  // If no parts left after honorific extraction, return
  if (remainingParts.length === 0) {
    return result;
  }
  
  // Extract first name
  result.firstName = remainingParts[0];
  
  // Handle different name patterns
  if (remainingParts.length === 1) {
    // Only a single name
    return result;
  } else if (remainingParts.length === 2) {
    // Likely first and last name
    result.lastName = remainingParts[1];
  } else {
    // Has middle name(s)
    result.lastName = remainingParts[remainingParts.length - 1];
    
    // Everything between first and last name is considered middle name
    const middleNames = remainingParts.slice(1, -1);
    if (middleNames.length > 0) {
      result.middleName = middleNames.join(' ');
    }
  }
  
  return result;
}

// Example usage:
// parseName("Mr. John A. Smith") => { honorific: "Mr.", firstName: "John", middleName: "A.", lastName: "Smith" }
// parseName("Jane Doe") => { firstName: "Jane", lastName: "Doe" }
